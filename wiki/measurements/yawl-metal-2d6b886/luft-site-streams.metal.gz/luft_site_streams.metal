#include <metal_stdlib>

using namespace metal;

struct StarFragmentSpecificationInput {
  // World position is a point-valued vector in the spatial coordinate kind, measured in cell units, and dimensionless.
  float3 world_position [[user(locn0)]];
  // World orientation is a difference-valued vector in the orientation vector kind, unitless and dimensionless.
  float3 mesh_normal [[user(locn1), flat]];
  // This numeric value has no quantity annotation.
  float4 current_clip [[user(locn2)]];
  // This numeric value has no quantity annotation.
  float4 previous_clip [[user(locn3)]];
  // Shadow coordinate is a point-valued vector in the normalized coordinate kind, unitless and dimensionless.
  float3 shadow_sample [[user(locn4)]];
  // This numeric value has no quantity annotation.
  float3 material_tone [[user(locn5), flat]];
  // The y lane holds surface relief as a non-negative absolute scalar in the proportion kind, unitless and dimensionless.
  // The z lane holds surface roughness as a non-negative absolute scalar in the proportion kind, unitless and dimensionless.
  // The w lane holds surface wear as a difference-valued scalar in the proportion kind, unitless and dimensionless.
  // The x lane has no quantity annotation.
  float4 material_surface [[user(locn6), flat]];
  // The y lane holds pattern courses as a non-negative absolute scalar in the sample count kind, unitless and dimensionless.
  // The z lane holds pattern aspect as a non-negative absolute scalar in the proportion kind, unitless and dimensionless.
  // The w lane holds mortar width as a non-negative absolute scalar in the proportion kind, unitless and dimensionless.
  // The x lane has no quantity annotation.
  float4 material_pattern [[user(locn7), flat]];
  // The xyz lanes hold surface tone as a non-negative absolute vector in the relative color signal kind, unitless and dimensionless.
  // The w lane holds tone variance as a non-negative absolute scalar in the proportion kind, unitless and dimensionless.
  float4 material_mortar [[user(locn8), flat]];
  // The xyz lanes hold surface tone as a non-negative absolute vector in the relative color signal kind, unitless and dimensionless.
  // The w lane holds surface emission as a non-negative absolute scalar in the relative color signal kind, unitless and dimensionless.
  float4 material_accent [[user(locn9), flat]];
  // The x lane holds block light proportion as a non-negative absolute scalar in the proportion kind, unitless and dimensionless.
  // The y lane holds block light proportion as a non-negative absolute scalar in the proportion kind, unitless and dimensionless.
  // The z lane holds block light proportion as a non-negative absolute scalar in the proportion kind, unitless and dimensionless.
  // The w lane holds sky light proportion as a non-negative absolute scalar in the proportion kind, unitless and dimensionless.
  float4 voxel_light [[user(locn10)]];
};

struct StarFragmentSpecificationOutput {
  // This numeric value has no quantity annotation.
  float4 color_output [[color(0)]];
  // This numeric value has no quantity annotation.
  float2 motion_output [[color(1)]];
};

struct CameraState {
  // The xyz lanes hold world position as a point-valued vector in the spatial coordinate kind, measured in cell units, and dimensionless.
  // The w lane has no quantity annotation.
  float4 camera_position;
  // The xyz lanes hold world direction as a difference-valued vector in the unit direction kind, unitless and dimensionless.
  // The w lane has no quantity annotation.
  float4 camera_right;
  // The xyz lanes hold world direction as a difference-valued vector in the unit direction kind, unitless and dimensionless.
  // The w lane has no quantity annotation.
  float4 camera_up;
  // The xyz lanes hold world direction as a difference-valued vector in the unit direction kind, unitless and dimensionless.
  // The w lane has no quantity annotation.
  float4 camera_forward;
  // This numeric value has no quantity annotation.
  float4 camera_projection;
  // The x lane holds bevel proportion as a non-negative absolute scalar in the proportion kind, unitless and dimensionless.
  // The y lane holds construction line strength as a non-negative absolute scalar in the proportion kind, unitless and dimensionless.
  // The w lane holds inspection ink strength as a non-negative absolute scalar in the proportion kind, unitless and dimensionless.
  // The z lane has no quantity annotation.
  float4 render_parameters;
  // The xyz lanes hold world position as a point-valued vector in the spatial coordinate kind, measured in cell units, and dimensionless.
  // The w lane has no quantity annotation.
  float4 previous_camera_position;
  // The xyz lanes hold world direction as a difference-valued vector in the unit direction kind, unitless and dimensionless.
  // The w lane has no quantity annotation.
  float4 previous_camera_right;
  // The xyz lanes hold world direction as a difference-valued vector in the unit direction kind, unitless and dimensionless.
  // The w lane has no quantity annotation.
  float4 previous_camera_up;
  // The xyz lanes hold world direction as a difference-valued vector in the unit direction kind, unitless and dimensionless.
  // The w lane has no quantity annotation.
  float4 previous_camera_forward;
  // This numeric value has no quantity annotation.
  float4 previous_camera_projection;
  // The xy lanes hold temporal jitter as a difference-valued vector in the normalized coordinate kind, unitless and dimensionless.
  // The zw lanes hold temporal jitter as a difference-valued vector in the normalized coordinate kind, unitless and dimensionless.
  float4 temporal_parameters;
  // The xy lanes hold texture coordinate as a point-valued vector in the normalized coordinate kind, unitless and dimensionless.
  // The zw lanes hold texel extent as a non-negative absolute vector in the normalized coordinate kind, unitless and dimensionless.
  float4 inspection_parameters;
  // The xyz lanes hold world position as a point-valued vector in the spatial coordinate kind, measured in cell units, and dimensionless.
  // The w lane holds gait phase as a difference-valued scalar in the angular measure kind, measured in radian units, and dimensionless.
  float4 character_parameters;
  // The xyz lanes hold world direction as a difference-valued vector in the unit direction kind, unitless and dimensionless.
  // The w lane has no quantity annotation.
  float4 sun_vector;
  // The xyz lanes hold scene radiance as a non-negative absolute vector in the relative color signal kind, unitless and dimensionless.
  // The w lane has no quantity annotation.
  float4 sun_color_vector;
  // The xyz lanes hold scene radiance as a non-negative absolute vector in the relative color signal kind, unitless and dimensionless.
  // The w lane holds exposure as a non-negative absolute scalar in the control signal kind, unitless and dimensionless.
  float4 sky_color_vector;
  // The xyz lanes hold scene radiance as a non-negative absolute vector in the relative color signal kind, unitless and dimensionless.
  // The w lane has no quantity annotation.
  float4 ground_color_vector;
  // This numeric value has no quantity annotation.
  float4 shadow_row_x;
  // This numeric value has no quantity annotation.
  float4 shadow_row_y;
  // This numeric value has no quantity annotation.
  float4 shadow_row_z;
  // This numeric value has no quantity annotation.
  float4 shadow_row_w;
  // The xy lanes hold texel extent as a non-negative absolute vector in the normalized coordinate kind, unitless and dimensionless.
  // The z lane holds shadow bias as a non-negative absolute scalar in the normalized coordinate kind, unitless and dimensionless.
  // The w lane holds shadow filter radius as a non-negative absolute scalar in the sample count kind, unitless and dimensionless.
  float4 shadow_control;
  // The xyz lanes hold world position as a point-valued vector in the spatial coordinate kind, measured in cell units, and dimensionless.
  // The w lane holds gait phase as a difference-valued scalar in the angular measure kind, measured in radian units, and dimensionless.
  float4 previous_character_parameters;
  // The xy lanes hold horizontal direction as a difference-valued vector in the unit direction kind, unitless and dimensionless.
  // The zw lanes hold horizontal direction as a difference-valued vector in the unit direction kind, unitless and dimensionless.
  float4 character_direction;
  // The xyz lanes hold scene radiance as a non-negative absolute vector in the relative color signal kind, unitless and dimensionless.
  // The w lane has no quantity annotation.
  float4 zenith_color_vector;
  // The xyz lanes hold scene radiance as a non-negative absolute vector in the relative color signal kind, unitless and dimensionless.
  // The w lane has no quantity annotation.
  float4 horizon_color_vector;
  // The xyz lanes hold scene radiance as a non-negative absolute vector in the relative color signal kind, unitless and dimensionless.
  // The w lane has no quantity annotation.
  float4 fog_color_vector;
  // This numeric value has no quantity annotation.
  float4 lens_parameters;
  // This numeric value has no quantity annotation.
  float4 atmosphere_parameters;
  // The xy lanes hold texel extent as a non-negative absolute vector in the normalized coordinate kind, unitless and dimensionless.
  // The zw lanes hold texel extent as a non-negative absolute vector in the normalized coordinate kind, unitless and dimensionless.
  float4 lens_extent;
  // The xyz lanes hold world direction as a difference-valued vector in the unit direction kind, unitless and dimensionless.
  // The w lane has no quantity annotation.
  float4 moon_vector;
  // The xyz lanes hold world direction as a difference-valued vector in the unit direction kind, unitless and dimensionless.
  // The w lane has no quantity annotation.
  float4 celestial_pole_vector;
  // This numeric value has no quantity annotation.
  float4 night_parameters;
};

fragment StarFragmentSpecificationOutput star_fragment_specification(StarFragmentSpecificationInput stage_in [[stage_in]],
    constant CameraState& camera_state [[buffer(2)]],
    depth2d<float> shadow_map [[texture(4)]],
    sampler shadow_sampler [[sampler(5)]]) {
  StarFragmentSpecificationOutput result = {};
  // This numeric value has no quantity annotation.
  float3 normal = normalize(stage_in.mesh_normal);
  // This numeric value has no quantity annotation.
  float3 world = stage_in.world_position;
  // This numeric value has no quantity annotation.
  float3 sun = camera_state.sun_vector.xyz;
  // This numeric value has no quantity annotation.
  float3 sun_color = camera_state.sun_color_vector.xyz;
  // This numeric value has no quantity annotation.
  float3 soft_shadow_visibility_1_local_1_shadow_sample = stage_in.shadow_sample;
  // This numeric value has no quantity annotation.
  float2 soft_shadow_visibility_1_local_2_uv = soft_shadow_visibility_1_local_1_shadow_sample.xy;
  // This numeric value has no quantity annotation.
  float soft_shadow_visibility_1_local_3_depth = soft_shadow_visibility_1_local_1_shadow_sample.z;
  // This numeric value has no quantity annotation.
  float soft_shadow_visibility_1_local_4_u = soft_shadow_visibility_1_local_2_uv.x;
  // This numeric value has no quantity annotation.
  float soft_shadow_visibility_1_local_5_v = soft_shadow_visibility_1_local_2_uv.y;
  // This numeric value has no quantity annotation.
  float soft_shadow_visibility_1_local_6_in_bounds = (((((step(0.0f, soft_shadow_visibility_1_local_4_u) * step(soft_shadow_visibility_1_local_4_u, 1.0f)) * step(0.0f, soft_shadow_visibility_1_local_5_v)) * step(soft_shadow_visibility_1_local_5_v, 1.0f)) * step(0.0f, soft_shadow_visibility_1_local_3_depth)) * step(soft_shadow_visibility_1_local_3_depth, 1.0f));
  // This numeric value has no quantity annotation.
  float2 soft_shadow_visibility_1_local_7_texel = camera_state.shadow_control.xy;
  // This numeric value has no quantity annotation.
  float3 receiver_depth_gradient_2_local_1_rx = camera_state.shadow_row_x.xyz;
  // This numeric value has no quantity annotation.
  float3 receiver_depth_gradient_2_local_2_ry = camera_state.shadow_row_y.xyz;
  // This numeric value has no quantity annotation.
  float3 receiver_depth_gradient_2_local_3_rz = camera_state.shadow_row_z.xyz;
  // This numeric value has no quantity annotation.
  float receiver_depth_gradient_2_local_4_along_z = dot(normal, receiver_depth_gradient_2_local_3_rz);
  // This numeric value has no quantity annotation.
  float receiver_depth_gradient_2_local_5_safe_z = min(receiver_depth_gradient_2_local_4_along_z, (-0.08f * sqrt(dot(receiver_depth_gradient_2_local_3_rz, receiver_depth_gradient_2_local_3_rz))));
  // This numeric value has no quantity annotation.
  float receiver_depth_gradient_2_local_6_scale = ((-2.0f * dot(receiver_depth_gradient_2_local_3_rz, receiver_depth_gradient_2_local_3_rz)) / receiver_depth_gradient_2_local_5_safe_z);
  // This numeric value has no quantity annotation.
  float2 receiver_depth_gradient_2_local_7_gradient = float2(((receiver_depth_gradient_2_local_6_scale * dot(normal, receiver_depth_gradient_2_local_1_rx)) / dot(receiver_depth_gradient_2_local_1_rx, receiver_depth_gradient_2_local_1_rx)), ((receiver_depth_gradient_2_local_6_scale * dot(normal, receiver_depth_gradient_2_local_2_ry)) / dot(receiver_depth_gradient_2_local_2_ry, receiver_depth_gradient_2_local_2_ry)));
  // This numeric value has no quantity annotation.
  float2 soft_shadow_visibility_1_local_8_gradient = clamp(receiver_depth_gradient_2_local_7_gradient, float2(-4.0f, -4.0f), float2(4.0f, 4.0f));
  // This numeric value has no quantity annotation.
  float soft_shadow_visibility_1_local_9_bias = ((camera_state.shadow_control.z + (abs(soft_shadow_visibility_1_local_8_gradient.x) * soft_shadow_visibility_1_local_7_texel.x)) + (abs(soft_shadow_visibility_1_local_8_gradient.y) * soft_shadow_visibility_1_local_7_texel.y));
  // This numeric value has no quantity annotation.
  float2 soft_shadow_visibility_1_local_10_step_uv = (soft_shadow_visibility_1_local_7_texel * camera_state.shadow_control.w);
  // This numeric value has no quantity annotation.
  float soft_shadow_visibility_1_local_11_sx = soft_shadow_visibility_1_local_10_step_uv.x;
  // This numeric value has no quantity annotation.
  float soft_shadow_visibility_1_local_12_sy = soft_shadow_visibility_1_local_10_step_uv.y;
  // This numeric value has no quantity annotation.
  float soft_shadow_visibility_1_local_13_gx = (soft_shadow_visibility_1_local_8_gradient.x * soft_shadow_visibility_1_local_11_sx);
  // This numeric value has no quantity annotation.
  float soft_shadow_visibility_1_local_14_gy = (soft_shadow_visibility_1_local_8_gradient.y * soft_shadow_visibility_1_local_12_sy);
  // This numeric value has no quantity annotation.
  float soft_shadow_visibility_1_local_15_reference = (soft_shadow_visibility_1_local_3_depth - soft_shadow_visibility_1_local_9_bias);
  // This numeric value has no quantity annotation.
  float soft_shadow_visibility_1_local_16_visibility = (((((((((shadow_map.sample_compare(shadow_sampler, soft_shadow_visibility_1_local_2_uv, soft_shadow_visibility_1_local_15_reference) + shadow_map.sample_compare(shadow_sampler, (soft_shadow_visibility_1_local_2_uv + float2(soft_shadow_visibility_1_local_11_sx, 0.0f)), (soft_shadow_visibility_1_local_15_reference + soft_shadow_visibility_1_local_13_gx))) + shadow_map.sample_compare(shadow_sampler, (soft_shadow_visibility_1_local_2_uv - float2(soft_shadow_visibility_1_local_11_sx, 0.0f)), (soft_shadow_visibility_1_local_15_reference - soft_shadow_visibility_1_local_13_gx))) + shadow_map.sample_compare(shadow_sampler, (soft_shadow_visibility_1_local_2_uv + float2(0.0f, soft_shadow_visibility_1_local_12_sy)), (soft_shadow_visibility_1_local_15_reference + soft_shadow_visibility_1_local_14_gy))) + shadow_map.sample_compare(shadow_sampler, (soft_shadow_visibility_1_local_2_uv - float2(0.0f, soft_shadow_visibility_1_local_12_sy)), (soft_shadow_visibility_1_local_15_reference - soft_shadow_visibility_1_local_14_gy))) + shadow_map.sample_compare(shadow_sampler, (soft_shadow_visibility_1_local_2_uv + float2(soft_shadow_visibility_1_local_11_sx, soft_shadow_visibility_1_local_12_sy)), (soft_shadow_visibility_1_local_15_reference + (soft_shadow_visibility_1_local_13_gx + soft_shadow_visibility_1_local_14_gy)))) + shadow_map.sample_compare(shadow_sampler, (soft_shadow_visibility_1_local_2_uv - float2(soft_shadow_visibility_1_local_11_sx, soft_shadow_visibility_1_local_12_sy)), (soft_shadow_visibility_1_local_15_reference - (soft_shadow_visibility_1_local_13_gx + soft_shadow_visibility_1_local_14_gy)))) + shadow_map.sample_compare(shadow_sampler, (soft_shadow_visibility_1_local_2_uv + float2(soft_shadow_visibility_1_local_11_sx, (-soft_shadow_visibility_1_local_12_sy))), (soft_shadow_visibility_1_local_15_reference + (soft_shadow_visibility_1_local_13_gx - soft_shadow_visibility_1_local_14_gy)))) + shadow_map.sample_compare(shadow_sampler, (soft_shadow_visibility_1_local_2_uv - float2(soft_shadow_visibility_1_local_11_sx, (-soft_shadow_visibility_1_local_12_sy))), (soft_shadow_visibility_1_local_15_reference - (soft_shadow_visibility_1_local_13_gx - soft_shadow_visibility_1_local_14_gy)))) / 9.0f);
  // This numeric value has no quantity annotation.
  float cloud_deck_visibility_4_local_1_sun_climb = max(0.15f, sun.xzy.y);
  // This numeric value has no quantity annotation.
  float cloud_deck_visibility_4_local_2_reach = (max(8.0f, (80.0f - (world.xzy - float3(camera_state.sun_color_vector.w, 0.0f, camera_state.sun_color_vector.w)).y)) / cloud_deck_visibility_4_local_1_sun_climb);
  // This numeric value has no quantity annotation.
  float3 cloud_deck_visibility_4_local_3_meeting = (((world.xzy - float3(camera_state.sun_color_vector.w, 0.0f, camera_state.sun_color_vector.w)) + (sun.xzy * cloud_deck_visibility_4_local_2_reach)) + float3((camera_state.atmosphere_parameters.x * 2.2f), 0.0f, (camera_state.atmosphere_parameters.x * 1.2f)));
  float4 fold_state_1 = float4((cloud_deck_visibility_4_local_3_meeting * 0.0044f), 0.0f);
  for (float fold_index_1 = 0.0f; fold_index_1 < 4.0f; fold_index_1 += 1.0f) {
    float3 sample_point = fold_state_1.xyz;
    float x = sample_point.x;
    float y = sample_point.y;
    float z = sample_point.z;
    float gain = pow(0.5f, (fold_index_1 + 1.0f));
    float3 lattice_noise_6_local_1_lattice = floor(sample_point);
    float3 lattice_noise_6_local_2_offset = fract(sample_point);
    float3 lattice_noise_6_local_3_weight = (lattice_noise_6_local_2_offset * (lattice_noise_6_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (lattice_noise_6_local_2_offset * 2.0f))));
    float lattice_noise_6_local_4_u = lattice_noise_6_local_3_weight.x;
    float lattice_noise_6_local_5_v = lattice_noise_6_local_3_weight.y;
    float lattice_noise_6_local_6_w = lattice_noise_6_local_3_weight.z;
    float3 lattice_hash_7_local_1_scattered = fract((lattice_noise_6_local_1_lattice * 0.1031f));
    float lattice_hash_7_local_2_shift = dot(lattice_hash_7_local_1_scattered, (lattice_hash_7_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
    float3 lattice_hash_7_local_3_folded = (lattice_hash_7_local_1_scattered + float3(lattice_hash_7_local_2_shift, lattice_hash_7_local_2_shift, lattice_hash_7_local_2_shift));
    float3 lattice_hash_8_local_1_scattered = fract(((lattice_noise_6_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
    float lattice_hash_8_local_2_shift = dot(lattice_hash_8_local_1_scattered, (lattice_hash_8_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
    float3 lattice_hash_8_local_3_folded = (lattice_hash_8_local_1_scattered + float3(lattice_hash_8_local_2_shift, lattice_hash_8_local_2_shift, lattice_hash_8_local_2_shift));
    float lattice_noise_6_local_7_near_low = mix(fract(((lattice_hash_7_local_3_folded.x + lattice_hash_7_local_3_folded.y) * lattice_hash_7_local_3_folded.z)), fract(((lattice_hash_8_local_3_folded.x + lattice_hash_8_local_3_folded.y) * lattice_hash_8_local_3_folded.z)), lattice_noise_6_local_4_u);
    float3 lattice_hash_9_local_1_scattered = fract(((lattice_noise_6_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
    float lattice_hash_9_local_2_shift = dot(lattice_hash_9_local_1_scattered, (lattice_hash_9_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
    float3 lattice_hash_9_local_3_folded = (lattice_hash_9_local_1_scattered + float3(lattice_hash_9_local_2_shift, lattice_hash_9_local_2_shift, lattice_hash_9_local_2_shift));
    float3 lattice_hash_10_local_1_scattered = fract(((lattice_noise_6_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
    float lattice_hash_10_local_2_shift = dot(lattice_hash_10_local_1_scattered, (lattice_hash_10_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
    float3 lattice_hash_10_local_3_folded = (lattice_hash_10_local_1_scattered + float3(lattice_hash_10_local_2_shift, lattice_hash_10_local_2_shift, lattice_hash_10_local_2_shift));
    float lattice_noise_6_local_8_near_high = mix(fract(((lattice_hash_9_local_3_folded.x + lattice_hash_9_local_3_folded.y) * lattice_hash_9_local_3_folded.z)), fract(((lattice_hash_10_local_3_folded.x + lattice_hash_10_local_3_folded.y) * lattice_hash_10_local_3_folded.z)), lattice_noise_6_local_4_u);
    float3 lattice_hash_11_local_1_scattered = fract(((lattice_noise_6_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
    float lattice_hash_11_local_2_shift = dot(lattice_hash_11_local_1_scattered, (lattice_hash_11_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
    float3 lattice_hash_11_local_3_folded = (lattice_hash_11_local_1_scattered + float3(lattice_hash_11_local_2_shift, lattice_hash_11_local_2_shift, lattice_hash_11_local_2_shift));
    float3 lattice_hash_12_local_1_scattered = fract(((lattice_noise_6_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
    float lattice_hash_12_local_2_shift = dot(lattice_hash_12_local_1_scattered, (lattice_hash_12_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
    float3 lattice_hash_12_local_3_folded = (lattice_hash_12_local_1_scattered + float3(lattice_hash_12_local_2_shift, lattice_hash_12_local_2_shift, lattice_hash_12_local_2_shift));
    float lattice_noise_6_local_9_far_low = mix(fract(((lattice_hash_11_local_3_folded.x + lattice_hash_11_local_3_folded.y) * lattice_hash_11_local_3_folded.z)), fract(((lattice_hash_12_local_3_folded.x + lattice_hash_12_local_3_folded.y) * lattice_hash_12_local_3_folded.z)), lattice_noise_6_local_4_u);
    float3 lattice_hash_13_local_1_scattered = fract(((lattice_noise_6_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
    float lattice_hash_13_local_2_shift = dot(lattice_hash_13_local_1_scattered, (lattice_hash_13_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
    float3 lattice_hash_13_local_3_folded = (lattice_hash_13_local_1_scattered + float3(lattice_hash_13_local_2_shift, lattice_hash_13_local_2_shift, lattice_hash_13_local_2_shift));
    float3 lattice_hash_14_local_1_scattered = fract(((lattice_noise_6_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
    float lattice_hash_14_local_2_shift = dot(lattice_hash_14_local_1_scattered, (lattice_hash_14_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
    float3 lattice_hash_14_local_3_folded = (lattice_hash_14_local_1_scattered + float3(lattice_hash_14_local_2_shift, lattice_hash_14_local_2_shift, lattice_hash_14_local_2_shift));
    float lattice_noise_6_local_10_far_high = mix(fract(((lattice_hash_13_local_3_folded.x + lattice_hash_13_local_3_folded.y) * lattice_hash_13_local_3_folded.z)), fract(((lattice_hash_14_local_3_folded.x + lattice_hash_14_local_3_folded.y) * lattice_hash_14_local_3_folded.z)), lattice_noise_6_local_4_u);
    float total = (fold_state_1.w + (mix(mix(lattice_noise_6_local_7_near_low, lattice_noise_6_local_8_near_high, lattice_noise_6_local_5_v), mix(lattice_noise_6_local_9_far_low, lattice_noise_6_local_10_far_high, lattice_noise_6_local_5_v), lattice_noise_6_local_6_w) * gain));
    float3 rotated = (float3(((0.78f * x) + (0.63f * z)), (y + 11.17f), ((-0.63f * x) + (0.78f * z))) * 2.11f);
    fold_state_1 = float4(rotated, total);
  }
  // This numeric value has no quantity annotation.
  float4 cloud_fractal_noise_5_local_1_accumulated = fold_state_1;
  // This numeric value has no quantity annotation.
  float cloud_deck_visibility_4_local_4_cover = (cloud_fractal_noise_5_local_1_accumulated.w * 1.067f);
  // This numeric value has no quantity annotation.
  float cloud_deck_visibility_4_local_5_coverage = mix(0.82f, 0.46f, clamp((camera_state.horizon_color_vector.w * 1.35f), 0.0f, 1.0f));
  // This numeric value has no quantity annotation.
  float visibility = (mix(1.0f, soft_shadow_visibility_1_local_16_visibility, soft_shadow_visibility_1_local_6_in_bounds) * (1.0f - (0.72f * smoothstep(cloud_deck_visibility_4_local_5_coverage, (cloud_deck_visibility_4_local_5_coverage + 0.2f), cloud_deck_visibility_4_local_4_cover))));
  // This numeric value has no quantity annotation.
  float relief = stage_in.material_surface.x;
  // This numeric value has no quantity annotation.
  float strength = stage_in.material_surface.y;
  // This numeric value has no quantity annotation.
  float roughness = stage_in.material_surface.z;
  // This numeric value has no quantity annotation.
  float wear = stage_in.material_surface.w;
  // This numeric value has no quantity annotation.
  float4 eye = camera_state.camera_position;
  // This numeric value has no quantity annotation.
  float3 forward = camera_state.camera_forward.xyz;
  // This numeric value has no quantity annotation.
  float divisor = camera_state.render_parameters.z;
  // This numeric value has no quantity annotation.
  float3 to_eye = (eye.xyz - world);
  // This numeric value has no quantity annotation.
  float distance = mix(20.0f, sqrt(dot(to_eye, to_eye)), divisor);
  // This numeric value has no quantity annotation.
  float pattern_fineness_15_local_1_shape = stage_in.material_pattern.x;
  // This numeric value has no quantity annotation.
  float fade = (1.0f - smoothstep(40.0f, 120.0f, (distance * (((pattern_fineness_15_local_1_shape > 4.5f) ? ((pattern_fineness_15_local_1_shape < 5.5f) ? ((0.5f * stage_in.material_pattern.y) * stage_in.material_pattern.z) : stage_in.material_pattern.y) : stage_in.material_pattern.y) / 4.0f))));
  // This numeric value has no quantity annotation.
  float nap_fade = (1.0f - smoothstep(12.0f, 40.0f, (distance / max(0.2f, abs(dot(normal, normalize(to_eye)))))));
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_1_shape = stage_in.material_pattern.x;
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_2_courses = max(1.0f, stage_in.material_pattern.y);
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_3_aspect = max(0.5f, stage_in.material_pattern.z);
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_4_mortar = (0.5f * stage_in.material_pattern.w);
  // This numeric value has no quantity annotation.
  float3 laid_pattern_16_local_5_an = abs(normal);
  // This numeric value has no quantity annotation.
  bool laid_pattern_16_local_6_top = (laid_pattern_16_local_5_an.z > 0.7f);
  // This numeric value has no quantity annotation.
  bool laid_pattern_16_local_7_x_facing = (laid_pattern_16_local_5_an.x > laid_pattern_16_local_5_an.y);
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_8_u = (laid_pattern_16_local_6_top ? world.x : (laid_pattern_16_local_7_x_facing ? world.y : world.x));
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_9_v = (laid_pattern_16_local_6_top ? world.y : world.z);
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_10_w = (laid_pattern_16_local_6_top ? world.z : (laid_pattern_16_local_7_x_facing ? world.x : world.y));
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_11_rowf = (laid_pattern_16_local_9_v * laid_pattern_16_local_2_courses);
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_12_row = floor(laid_pattern_16_local_11_rowf);
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_13_fv = fract(laid_pattern_16_local_11_rowf);
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_14_parity = (2.0f * fract((laid_pattern_16_local_12_row * 0.5f)));
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_15_shift = ((laid_pattern_16_local_1_shape < 1.5f) ? (0.5f * laid_pattern_16_local_14_parity) : ((laid_pattern_16_local_1_shape > 2.5f) ? ((laid_pattern_16_local_1_shape < 3.5f) ? (0.5f * laid_pattern_16_local_14_parity) : 0.0f) : 0.0f));
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_16_uf = (((laid_pattern_16_local_8_u * laid_pattern_16_local_2_courses) / laid_pattern_16_local_3_aspect) + laid_pattern_16_local_15_shift);
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_17_col = floor(laid_pattern_16_local_16_uf);
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_18_fu = fract(laid_pattern_16_local_16_uf);
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_19_du = (laid_pattern_16_local_3_aspect * min(laid_pattern_16_local_18_fu, (1.0f - laid_pattern_16_local_18_fu)));
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_20_dv = min(laid_pattern_16_local_13_fv, (1.0f - laid_pattern_16_local_13_fv));
  // This value is a difference-valued scalar, unitless and dimensionless.
  float laid_pattern_16_local_21_bevel = 0.08f;
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_22_joint = smoothstep(laid_pattern_16_local_4_mortar, (laid_pattern_16_local_4_mortar + laid_pattern_16_local_21_bevel), laid_pattern_16_local_19_du);
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_23_bed = smoothstep(laid_pattern_16_local_4_mortar, (laid_pattern_16_local_4_mortar + laid_pattern_16_local_21_bevel), laid_pattern_16_local_20_dv);
  // This numeric value has no quantity annotation.
  bool laid_pattern_16_local_24_shingle = (laid_pattern_16_local_1_shape > 2.5f);
  // This numeric value has no quantity annotation.
  bool laid_pattern_16_local_25_checker = (laid_pattern_16_local_1_shape > 3.5f);
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_26_mask = (laid_pattern_16_local_25_checker ? (laid_pattern_16_local_22_joint * laid_pattern_16_local_23_bed) : (laid_pattern_16_local_24_shingle ? (laid_pattern_16_local_22_joint * smoothstep(0.0f, (laid_pattern_16_local_4_mortar + laid_pattern_16_local_21_bevel), laid_pattern_16_local_13_fv)) : (laid_pattern_16_local_22_joint * laid_pattern_16_local_23_bed)));
  // This value is a difference-valued scalar, unitless and dimensionless.
  float laid_pattern_16_local_27_ramp = (laid_pattern_16_local_25_checker ? 1.0f : (laid_pattern_16_local_24_shingle ? (1.0f - (0.5f * laid_pattern_16_local_13_fv)) : 1.0f));
  // This numeric value has no quantity annotation.
  float3 paper_hash_17_local_1_scattered = fract((float3(laid_pattern_16_local_17_col, laid_pattern_16_local_12_row, floor((laid_pattern_16_local_10_w + 0.5f))) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_17_local_2_shift = dot(paper_hash_17_local_1_scattered, (paper_hash_17_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_17_local_3_folded = (paper_hash_17_local_1_scattered + float3(paper_hash_17_local_2_shift, paper_hash_17_local_2_shift, paper_hash_17_local_2_shift));
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_28_hash = fract(((paper_hash_17_local_3_folded.x + paper_hash_17_local_3_folded.y) * paper_hash_17_local_3_folded.z));
  // This numeric value has no quantity annotation.
  float laid_pattern_16_local_29_checked = (2.0f * fract(((laid_pattern_16_local_12_row + laid_pattern_16_local_17_col) * 0.5f)));
  // This numeric value has no quantity annotation.
  float face_laid_pattern_18_local_1_shape = stage_in.material_pattern.x;
  // This numeric value has no quantity annotation.
  float3 face_coordinates_19_local_1_an = abs(normal);
  // This numeric value has no quantity annotation.
  bool face_coordinates_19_local_2_top = (face_coordinates_19_local_1_an.z > 0.7f);
  // This numeric value has no quantity annotation.
  bool face_coordinates_19_local_3_x_facing = (face_coordinates_19_local_1_an.x > face_coordinates_19_local_1_an.y);
  // This numeric value has no quantity annotation.
  float3 face_laid_pattern_18_local_2_face = float3((face_coordinates_19_local_2_top ? world.x : (face_coordinates_19_local_3_x_facing ? world.y : world.x)), (face_coordinates_19_local_2_top ? world.y : world.z), (face_coordinates_19_local_2_top ? world.z : (face_coordinates_19_local_3_x_facing ? world.x : world.y)));
  // This numeric value has no quantity annotation.
  bool face_laid_pattern_18_local_3_top = (abs(normal.z) > 0.7f);
  // This numeric value has no quantity annotation.
  float mineral_pattern_20_local_1_phase = (dot(world, float3(7.0f, 4.0f, 5.0f)) + (1.8f * sin(dot(world, float3(1.3f, 2.1f, 0.7f)))));
  // This numeric value has no quantity annotation.
  float3 paper_hash_21_local_1_scattered = fract((floor((world * (4.75f * stage_in.material_pattern.y))) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_21_local_2_shift = dot(paper_hash_21_local_1_scattered, (paper_hash_21_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_21_local_3_folded = (paper_hash_21_local_1_scattered + float3(paper_hash_21_local_2_shift, paper_hash_21_local_2_shift, paper_hash_21_local_2_shift));
  // This numeric value has no quantity annotation.
  float mineral_pattern_20_local_2_ink = ((stage_in.material_pattern.x < 14.5f) ? smoothstep(0.88f, 0.99f, sin(mineral_pattern_20_local_1_phase)) : step(0.85f, fract(((paper_hash_21_local_3_folded.x + paper_hash_21_local_3_folded.y) * paper_hash_21_local_3_folded.z))));
  // This numeric value has no quantity annotation.
  float2 motif_face_22_local_1_uv = fract(face_laid_pattern_18_local_2_face.xy);
  // This numeric value has no quantity annotation.
  float2 motif_face_22_local_2_q = (motif_face_22_local_1_uv - float2(0.5f, 0.5f));
  // This numeric value has no quantity annotation.
  float motif_face_22_local_3_x = motif_face_22_local_2_q.x;
  // This numeric value has no quantity annotation.
  float motif_face_22_local_4_y = motif_face_22_local_2_q.y;
  // This numeric value has no quantity annotation.
  float motif_face_22_local_5_edge = max(abs(motif_face_22_local_3_x), abs(motif_face_22_local_4_y));
  // This numeric value has no quantity annotation.
  float motif_face_22_local_6_frame = smoothstep(0.34f, 0.4f, motif_face_22_local_5_edge);
  // This numeric value has no quantity annotation.
  float motif_face_22_local_7_r2 = dot(motif_face_22_local_2_q, motif_face_22_local_2_q);
  // This numeric value has no quantity annotation.
  float let_23_1_row = floor((motif_face_22_local_1_uv.y * 12.0f));
  // This numeric value has no quantity annotation.
  float let_23_2_ink = ((((1.0f - motif_face_22_local_6_frame) * (face_laid_pattern_18_local_3_top ? 0.0f : 1.0f)) * step(0.35f, fract((motif_face_22_local_1_uv.y * 12.0f)))) * step(0.3f, fract(((motif_face_22_local_1_uv.x * 9.0f) + (let_23_1_row * 0.37f)))));
  // This numeric value has no quantity annotation.
  float let_24_1_hub = (1.0f - smoothstep(0.012f, 0.025f, motif_face_22_local_7_r2));
  // This numeric value has no quantity annotation.
  float let_24_2_rim = smoothstep(0.14f, 0.18f, motif_face_22_local_7_r2);
  // This numeric value has no quantity annotation.
  float let_24_3_spoke = (1.0f - smoothstep(0.035f, 0.065f, min(abs(motif_face_22_local_3_x), abs(motif_face_22_local_4_y))));
  // This numeric value has no quantity annotation.
  float let_24_4_metal = ((1.0f - smoothstep(0.18f, 0.2f, motif_face_22_local_7_r2)) * max(let_24_1_hub, max(let_24_2_rim, let_24_3_spoke)));
  // This numeric value has no quantity annotation.
  float let_25_1_diamond = (abs(motif_face_22_local_3_x) + abs(motif_face_22_local_4_y));
  // This numeric value has no quantity annotation.
  float let_25_2_ink = (smoothstep(0.18f, 0.23f, let_25_1_diamond) * (1.0f - smoothstep(0.34f, 0.39f, let_25_1_diamond)));
  // This numeric value has no quantity annotation.
  float let_26_1_band = (1.0f - smoothstep(0.035f, 0.065f, abs((abs(motif_face_22_local_3_x) - 0.25f))));
  // This numeric value has no quantity annotation.
  float board_face_27_local_1_rowf = (face_laid_pattern_18_local_2_face.y * 4.0f);
  // This numeric value has no quantity annotation.
  float board_face_27_local_2_fv = fract(board_face_27_local_1_rowf);
  // This numeric value has no quantity annotation.
  float board_face_27_local_3_groove = (1.0f - smoothstep(0.03f, (0.03f + 0.03f), min(board_face_27_local_2_fv, (1.0f - board_face_27_local_2_fv))));
  // This numeric value has no quantity annotation.
  float3 paper_hash_29_local_1_scattered = fract((float3(floor(board_face_27_local_1_rowf), floor((face_laid_pattern_18_local_2_face.z + 0.5f)), 3.0f) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_29_local_2_shift = dot(paper_hash_29_local_1_scattered, (paper_hash_29_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_29_local_3_folded = (paper_hash_29_local_1_scattered + float3(paper_hash_29_local_2_shift, paper_hash_29_local_2_shift, paper_hash_29_local_2_shift));
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_1_rows = max(1.0f, stage_in.material_pattern.y);
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_2_books = (shelf_face_30_local_1_rows * max(0.5f, stage_in.material_pattern.z));
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_3_board = stage_in.material_pattern.w;
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_4_u = face_laid_pattern_18_local_2_face.x;
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_5_depth = floor((face_laid_pattern_18_local_2_face.z + 0.5f));
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_6_rowf = (face_laid_pattern_18_local_2_face.y * shelf_face_30_local_1_rows);
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_7_row = floor(shelf_face_30_local_6_rowf);
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_8_fv = fract(shelf_face_30_local_6_rowf);
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_9_cell_u = fract(shelf_face_30_local_4_u);
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_10_upright = (1.0f - smoothstep(0.03f, (0.03f + 0.015f), min(shelf_face_30_local_9_cell_u, (1.0f - shelf_face_30_local_9_cell_u))));
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_11_shelf = max((1.0f - smoothstep(shelf_face_30_local_3_board, (shelf_face_30_local_3_board + 0.04f), shelf_face_30_local_8_fv)), (1.0f - smoothstep((0.4f * shelf_face_30_local_3_board), ((0.4f * shelf_face_30_local_3_board) + 0.04f), (1.0f - shelf_face_30_local_8_fv))));
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_12_frame = max(shelf_face_30_local_10_upright, shelf_face_30_local_11_shelf);
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_13_slotf = (shelf_face_30_local_4_u * shelf_face_30_local_2_books);
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_14_slot = floor(shelf_face_30_local_13_slotf);
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_15_fs = fract(shelf_face_30_local_13_slotf);
  // This numeric value has no quantity annotation.
  float3 paper_hash_34_local_1_scattered = fract((float3(shelf_face_30_local_14_slot, shelf_face_30_local_7_row, (shelf_face_30_local_5_depth + 17.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_34_local_2_shift = dot(paper_hash_34_local_1_scattered, (paper_hash_34_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_34_local_3_folded = (paper_hash_34_local_1_scattered + float3(paper_hash_34_local_2_shift, paper_hash_34_local_2_shift, paper_hash_34_local_2_shift));
  // This value is a difference-valued scalar, unitless and dimensionless.
  float shelf_face_30_local_16_pair = ((fract(((paper_hash_34_local_3_folded.x + paper_hash_34_local_3_folded.y) * paper_hash_34_local_3_folded.z)) < 0.35f) ? 2.0f : 1.0f);
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_17_sub = floor((shelf_face_30_local_15_fs * shelf_face_30_local_16_pair));
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_18_fb = fract((shelf_face_30_local_15_fs * shelf_face_30_local_16_pair));
  // This numeric value has no quantity annotation.
  float3 paper_hash_35_local_1_scattered = fract((float3(((shelf_face_30_local_14_slot * 2.0f) + shelf_face_30_local_17_sub), shelf_face_30_local_7_row, shelf_face_30_local_5_depth) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_35_local_2_shift = dot(paper_hash_35_local_1_scattered, (paper_hash_35_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_35_local_3_folded = (paper_hash_35_local_1_scattered + float3(paper_hash_35_local_2_shift, paper_hash_35_local_2_shift, paper_hash_35_local_2_shift));
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_19_id = fract(((paper_hash_35_local_3_folded.x + paper_hash_35_local_3_folded.y) * paper_hash_35_local_3_folded.z));
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_20_clear = ((shelf_face_30_local_8_fv - shelf_face_30_local_3_board) / (1.0f - (1.4f * shelf_face_30_local_3_board)));
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_21_crown = (0.55f + (0.4f * fract((shelf_face_30_local_19_id * 13.7f))));
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_22_above = smoothstep((shelf_face_30_local_21_crown - 0.02f), (shelf_face_30_local_21_crown + 0.02f), shelf_face_30_local_20_clear);
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_23_seam = (1.0f - smoothstep(0.004f, (0.004f + 0.004f), (min(shelf_face_30_local_18_fb, (1.0f - shelf_face_30_local_18_fb)) / (shelf_face_30_local_2_books * shelf_face_30_local_16_pair))));
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_24_recess = ((1.0f - shelf_face_30_local_12_frame) * max(shelf_face_30_local_22_above, shelf_face_30_local_23_seam));
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_25_across = ((2.0f * shelf_face_30_local_18_fb) - 1.0f);
  // This numeric value has no quantity annotation.
  float shelf_face_30_local_26_spine = (0.55f + (0.2f * (1.0f - (shelf_face_30_local_25_across * shelf_face_30_local_25_across))));
  // This value is a difference-valued scalar, unitless and dimensionless.
  float shelf_face_30_local_27_gilt = ((abs((shelf_face_30_local_20_clear - (0.82f * shelf_face_30_local_21_crown))) < 0.025f) ? ((fract((shelf_face_30_local_19_id * 5.3f)) > 0.4f) ? 1.0f : 0.0f) : 0.0f);
  // This numeric value has no quantity annotation.
  float window_face_37_local_1_panes = max(1.0f, stage_in.material_pattern.y);
  // This numeric value has no quantity annotation.
  float window_face_37_local_2_width = stage_in.material_pattern.w;
  // This numeric value has no quantity annotation.
  float cell_edge_distance_38_local_1_fu = fract(face_laid_pattern_18_local_2_face.x);
  // This numeric value has no quantity annotation.
  float cell_edge_distance_38_local_2_fv = fract(face_laid_pattern_18_local_2_face.y);
  // This numeric value has no quantity annotation.
  float window_face_37_local_3_edge = min(min(cell_edge_distance_38_local_1_fu, (1.0f - cell_edge_distance_38_local_1_fu)), min(cell_edge_distance_38_local_2_fv, (1.0f - cell_edge_distance_38_local_2_fv)));
  // This numeric value has no quantity annotation.
  float window_face_37_local_4_frame = (1.0f - smoothstep(window_face_37_local_2_width, (window_face_37_local_2_width + 0.012f), window_face_37_local_3_edge));
  // This numeric value has no quantity annotation.
  float window_face_37_local_5_groove = (window_face_37_local_4_frame * (1.0f - smoothstep(0.01f, (0.01f + 0.008f), abs((window_face_37_local_3_edge - (0.5f * window_face_37_local_2_width))))));
  // This numeric value has no quantity annotation.
  float window_face_37_local_6_pu = fract((face_laid_pattern_18_local_2_face.x * window_face_37_local_1_panes));
  // This numeric value has no quantity annotation.
  float window_face_37_local_7_pv = fract((face_laid_pattern_18_local_2_face.y * window_face_37_local_1_panes));
  // This numeric value has no quantity annotation.
  float window_face_37_local_8_mullion = (1.0f - smoothstep(0.02f, (0.02f + 0.01f), (min(min(window_face_37_local_6_pu, (1.0f - window_face_37_local_6_pu)), min(window_face_37_local_7_pv, (1.0f - window_face_37_local_7_pv))) / window_face_37_local_1_panes)));
  // This numeric value has no quantity annotation.
  float window_face_37_local_9_bar = max(window_face_37_local_4_frame, window_face_37_local_8_mullion);
  // This numeric value has no quantity annotation.
  float3 paper_hash_42_local_1_scattered = fract((float3(floor((face_laid_pattern_18_local_2_face.x * window_face_37_local_1_panes)), floor((face_laid_pattern_18_local_2_face.y * window_face_37_local_1_panes)), (floor((face_laid_pattern_18_local_2_face.z + 0.5f)) + 5.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_42_local_2_shift = dot(paper_hash_42_local_1_scattered, (paper_hash_42_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_42_local_3_folded = (paper_hash_42_local_1_scattered + float3(paper_hash_42_local_2_shift, paper_hash_42_local_2_shift, paper_hash_42_local_2_shift));
  // This numeric value has no quantity annotation.
  float window_face_37_local_10_lamp = fract(((paper_hash_42_local_3_folded.x + paper_hash_42_local_3_folded.y) * paper_hash_42_local_3_folded.z));
  // This numeric value has no quantity annotation.
  float window_face_37_local_11_light = clamp(((0.3f + (0.5f * (1.0f - window_face_37_local_7_pv))) + (0.4f * (window_face_37_local_10_lamp - 0.5f))), 0.0f, 1.0f);
  // This numeric value has no quantity annotation.
  float timbered_face_43_local_1_width = (0.5f * stage_in.material_pattern.w);
  // This numeric value has no quantity annotation.
  float timbered_face_43_local_2_fu = fract(face_laid_pattern_18_local_2_face.x);
  // This numeric value has no quantity annotation.
  float timbered_face_43_local_3_fv = fract(face_laid_pattern_18_local_2_face.y);
  // This numeric value has no quantity annotation.
  float cell_edge_distance_44_local_1_fu = fract(face_laid_pattern_18_local_2_face.x);
  // This numeric value has no quantity annotation.
  float cell_edge_distance_44_local_2_fv = fract(face_laid_pattern_18_local_2_face.y);
  // This numeric value has no quantity annotation.
  float timbered_face_43_local_4_post = (1.0f - smoothstep(timbered_face_43_local_1_width, (timbered_face_43_local_1_width + 0.015f), min(min(cell_edge_distance_44_local_1_fu, (1.0f - cell_edge_distance_44_local_1_fu)), min(cell_edge_distance_44_local_2_fv, (1.0f - cell_edge_distance_44_local_2_fv)))));
  // This numeric value has no quantity annotation.
  float timbered_face_43_local_5_parity = fract((0.5f * (floor(face_laid_pattern_18_local_2_face.x) + floor(face_laid_pattern_18_local_2_face.y))));
  // This numeric value has no quantity annotation.
  float timbered_face_43_local_6_diagonal = ((timbered_face_43_local_5_parity > 0.25f) ? abs((timbered_face_43_local_2_fu - timbered_face_43_local_3_fv)) : abs(((timbered_face_43_local_2_fu + timbered_face_43_local_3_fv) - 1.0f)));
  // This numeric value has no quantity annotation.
  float timbered_face_43_local_7_brace = (1.0f - smoothstep(timbered_face_43_local_1_width, (timbered_face_43_local_1_width + 0.015f), (0.7071f * timbered_face_43_local_6_diagonal)));
  // This numeric value has no quantity annotation.
  float timbered_face_43_local_8_frame = max(timbered_face_43_local_4_post, timbered_face_43_local_7_brace);
  // This numeric value has no quantity annotation.
  float3 paper_noise_47_local_1_lattice = floor((face_laid_pattern_18_local_2_face * 7.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_47_local_2_offset = fract((face_laid_pattern_18_local_2_face * 7.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_47_local_3_weight = (paper_noise_47_local_2_offset * (paper_noise_47_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_47_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_47_local_4_u = paper_noise_47_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_47_local_5_v = paper_noise_47_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_47_local_6_w = paper_noise_47_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_48_local_1_scattered = fract((paper_noise_47_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_48_local_2_shift = dot(paper_hash_48_local_1_scattered, (paper_hash_48_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_48_local_3_folded = (paper_hash_48_local_1_scattered + float3(paper_hash_48_local_2_shift, paper_hash_48_local_2_shift, paper_hash_48_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_49_local_1_scattered = fract(((paper_noise_47_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_49_local_2_shift = dot(paper_hash_49_local_1_scattered, (paper_hash_49_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_49_local_3_folded = (paper_hash_49_local_1_scattered + float3(paper_hash_49_local_2_shift, paper_hash_49_local_2_shift, paper_hash_49_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_47_local_7_near_low = mix(fract(((paper_hash_48_local_3_folded.x + paper_hash_48_local_3_folded.y) * paper_hash_48_local_3_folded.z)), fract(((paper_hash_49_local_3_folded.x + paper_hash_49_local_3_folded.y) * paper_hash_49_local_3_folded.z)), paper_noise_47_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_50_local_1_scattered = fract(((paper_noise_47_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_50_local_2_shift = dot(paper_hash_50_local_1_scattered, (paper_hash_50_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_50_local_3_folded = (paper_hash_50_local_1_scattered + float3(paper_hash_50_local_2_shift, paper_hash_50_local_2_shift, paper_hash_50_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_51_local_1_scattered = fract(((paper_noise_47_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_51_local_2_shift = dot(paper_hash_51_local_1_scattered, (paper_hash_51_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_51_local_3_folded = (paper_hash_51_local_1_scattered + float3(paper_hash_51_local_2_shift, paper_hash_51_local_2_shift, paper_hash_51_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_47_local_8_near_high = mix(fract(((paper_hash_50_local_3_folded.x + paper_hash_50_local_3_folded.y) * paper_hash_50_local_3_folded.z)), fract(((paper_hash_51_local_3_folded.x + paper_hash_51_local_3_folded.y) * paper_hash_51_local_3_folded.z)), paper_noise_47_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_52_local_1_scattered = fract(((paper_noise_47_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_52_local_2_shift = dot(paper_hash_52_local_1_scattered, (paper_hash_52_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_52_local_3_folded = (paper_hash_52_local_1_scattered + float3(paper_hash_52_local_2_shift, paper_hash_52_local_2_shift, paper_hash_52_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_53_local_1_scattered = fract(((paper_noise_47_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_53_local_2_shift = dot(paper_hash_53_local_1_scattered, (paper_hash_53_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_53_local_3_folded = (paper_hash_53_local_1_scattered + float3(paper_hash_53_local_2_shift, paper_hash_53_local_2_shift, paper_hash_53_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_47_local_9_far_low = mix(fract(((paper_hash_52_local_3_folded.x + paper_hash_52_local_3_folded.y) * paper_hash_52_local_3_folded.z)), fract(((paper_hash_53_local_3_folded.x + paper_hash_53_local_3_folded.y) * paper_hash_53_local_3_folded.z)), paper_noise_47_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_54_local_1_scattered = fract(((paper_noise_47_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_54_local_2_shift = dot(paper_hash_54_local_1_scattered, (paper_hash_54_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_54_local_3_folded = (paper_hash_54_local_1_scattered + float3(paper_hash_54_local_2_shift, paper_hash_54_local_2_shift, paper_hash_54_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_55_local_1_scattered = fract(((paper_noise_47_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_55_local_2_shift = dot(paper_hash_55_local_1_scattered, (paper_hash_55_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_55_local_3_folded = (paper_hash_55_local_1_scattered + float3(paper_hash_55_local_2_shift, paper_hash_55_local_2_shift, paper_hash_55_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_47_local_10_far_high = mix(fract(((paper_hash_54_local_3_folded.x + paper_hash_54_local_3_folded.y) * paper_hash_54_local_3_folded.z)), fract(((paper_hash_55_local_3_folded.x + paper_hash_55_local_3_folded.y) * paper_hash_55_local_3_folded.z)), paper_noise_47_local_4_u);
  // This numeric value has no quantity annotation.
  float panel_face_56_local_1_width = stage_in.material_pattern.w;
  // This numeric value has no quantity annotation.
  float cell_edge_distance_57_local_1_fu = fract(face_laid_pattern_18_local_2_face.x);
  // This numeric value has no quantity annotation.
  float cell_edge_distance_57_local_2_fv = fract(face_laid_pattern_18_local_2_face.y);
  // This numeric value has no quantity annotation.
  float panel_face_56_local_2_edge = min(min(cell_edge_distance_57_local_1_fu, (1.0f - cell_edge_distance_57_local_1_fu)), min(cell_edge_distance_57_local_2_fv, (1.0f - cell_edge_distance_57_local_2_fv)));
  // This numeric value has no quantity annotation.
  float panel_face_56_local_3_frame = (1.0f - smoothstep(panel_face_56_local_1_width, (panel_face_56_local_1_width + 0.03f), panel_face_56_local_2_edge));
  // This numeric value has no quantity annotation.
  float panel_face_56_local_4_bevel = smoothstep(panel_face_56_local_1_width, (panel_face_56_local_1_width + 0.12f), panel_face_56_local_2_edge);
  // This numeric value has no quantity annotation.
  float3 paper_hash_59_local_1_scattered = fract((float3(floor(face_laid_pattern_18_local_2_face.x), floor(face_laid_pattern_18_local_2_face.y), floor((face_laid_pattern_18_local_2_face.z + 0.5f))) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_59_local_2_shift = dot(paper_hash_59_local_1_scattered, (paper_hash_59_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_59_local_3_folded = (paper_hash_59_local_1_scattered + float3(paper_hash_59_local_2_shift, paper_hash_59_local_2_shift, paper_hash_59_local_2_shift));
  // This numeric value has no quantity annotation.
  float4 laid = ((laid_pattern_16_local_1_shape < 0.5f) ? float4(1.0f, 0.5f, 1.0f, 0.0f) : ((laid_pattern_16_local_1_shape > 4.5f) ? ((face_laid_pattern_18_local_1_shape > 8.5f) ? ((face_laid_pattern_18_local_1_shape > 13.5f) ? float4(1.0f, mineral_pattern_20_local_2_ink, 0.0f, 0.0f) : ((face_laid_pattern_18_local_1_shape < 9.5f) ? float4((0.4f + (0.5f * motif_face_22_local_6_frame)), let_23_2_ink, motif_face_22_local_6_frame, 0.0f) : ((face_laid_pattern_18_local_1_shape < 10.5f) ? float4((0.35f + (0.55f * let_24_4_metal)), let_24_4_metal, 0.0f, 0.0f) : ((face_laid_pattern_18_local_1_shape < 11.5f) ? float4(0.85f, let_25_2_ink, smoothstep(0.43f, 0.47f, abs(motif_face_22_local_3_x)), 0.0f) : ((face_laid_pattern_18_local_1_shape < 12.5f) ? float4((0.9f - (let_26_1_band * 0.25f)), 0.0f, let_26_1_band, 0.0f) : float4((0.35f + (0.6f * motif_face_22_local_6_frame)), (face_laid_pattern_18_local_3_top ? (1.0f - motif_face_22_local_6_frame) : 0.0f), (face_laid_pattern_18_local_3_top ? motif_face_22_local_6_frame : 1.0f), 0.0f)))))) : (face_laid_pattern_18_local_3_top ? ((face_laid_pattern_18_local_1_shape < 5.5f) ? float4((1.0f - (0.7f * board_face_27_local_3_groove)), fract(((paper_hash_29_local_3_folded.x + paper_hash_29_local_3_folded.y) * paper_hash_29_local_3_folded.z)), 0.0f, (0.6f * board_face_27_local_3_groove)) : ((face_laid_pattern_18_local_1_shape < 7.5f) ? float4(1.0f, 0.5f, 1.0f, 0.0f) : float4(0.8f, 0.5f, 0.0f, 0.0f))) : ((face_laid_pattern_18_local_1_shape < 5.5f) ? float4(mix(mix(shelf_face_30_local_26_spine, 0.05f, shelf_face_30_local_24_recess), 1.0f, shelf_face_30_local_12_frame), (shelf_face_30_local_19_id + shelf_face_30_local_27_gilt), shelf_face_30_local_12_frame, shelf_face_30_local_24_recess) : ((face_laid_pattern_18_local_1_shape < 6.5f) ? float4(mix(0.2f, mix(mix(0.85f, 1.0f, window_face_37_local_4_frame), 0.45f, window_face_37_local_5_groove), window_face_37_local_9_bar), window_face_37_local_11_light, window_face_37_local_9_bar, window_face_37_local_5_groove) : ((face_laid_pattern_18_local_1_shape < 7.5f) ? float4(mix((0.35f + (0.2f * mix(mix(paper_noise_47_local_7_near_low, paper_noise_47_local_8_near_high, paper_noise_47_local_5_v), mix(paper_noise_47_local_9_far_low, paper_noise_47_local_10_far_high, paper_noise_47_local_5_v), paper_noise_47_local_6_w))), 0.95f, timbered_face_43_local_8_frame), 0.5f, timbered_face_43_local_8_frame, 0.0f) : float4(mix(mix(0.55f, 0.85f, panel_face_56_local_4_bevel), 0.95f, panel_face_56_local_3_frame), fract(((paper_hash_59_local_3_folded.x + paper_hash_59_local_3_folded.y) * paper_hash_59_local_3_folded.z)), panel_face_56_local_3_frame, 0.0f)))))) : float4(laid_pattern_16_local_26_mask, laid_pattern_16_local_28_hash, laid_pattern_16_local_27_ramp, laid_pattern_16_local_29_checked)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_62_local_1_lattice = floor((world * 4.7f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_62_local_2_offset = fract((world * 4.7f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_62_local_3_weight = (paper_noise_62_local_2_offset * (paper_noise_62_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_62_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_62_local_4_u = paper_noise_62_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_62_local_5_v = paper_noise_62_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_62_local_6_w = paper_noise_62_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_63_local_1_scattered = fract((paper_noise_62_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_63_local_2_shift = dot(paper_hash_63_local_1_scattered, (paper_hash_63_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_63_local_3_folded = (paper_hash_63_local_1_scattered + float3(paper_hash_63_local_2_shift, paper_hash_63_local_2_shift, paper_hash_63_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_64_local_1_scattered = fract(((paper_noise_62_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_64_local_2_shift = dot(paper_hash_64_local_1_scattered, (paper_hash_64_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_64_local_3_folded = (paper_hash_64_local_1_scattered + float3(paper_hash_64_local_2_shift, paper_hash_64_local_2_shift, paper_hash_64_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_62_local_7_near_low = mix(fract(((paper_hash_63_local_3_folded.x + paper_hash_63_local_3_folded.y) * paper_hash_63_local_3_folded.z)), fract(((paper_hash_64_local_3_folded.x + paper_hash_64_local_3_folded.y) * paper_hash_64_local_3_folded.z)), paper_noise_62_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_65_local_1_scattered = fract(((paper_noise_62_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_65_local_2_shift = dot(paper_hash_65_local_1_scattered, (paper_hash_65_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_65_local_3_folded = (paper_hash_65_local_1_scattered + float3(paper_hash_65_local_2_shift, paper_hash_65_local_2_shift, paper_hash_65_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_66_local_1_scattered = fract(((paper_noise_62_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_66_local_2_shift = dot(paper_hash_66_local_1_scattered, (paper_hash_66_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_66_local_3_folded = (paper_hash_66_local_1_scattered + float3(paper_hash_66_local_2_shift, paper_hash_66_local_2_shift, paper_hash_66_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_62_local_8_near_high = mix(fract(((paper_hash_65_local_3_folded.x + paper_hash_65_local_3_folded.y) * paper_hash_65_local_3_folded.z)), fract(((paper_hash_66_local_3_folded.x + paper_hash_66_local_3_folded.y) * paper_hash_66_local_3_folded.z)), paper_noise_62_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_67_local_1_scattered = fract(((paper_noise_62_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_67_local_2_shift = dot(paper_hash_67_local_1_scattered, (paper_hash_67_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_67_local_3_folded = (paper_hash_67_local_1_scattered + float3(paper_hash_67_local_2_shift, paper_hash_67_local_2_shift, paper_hash_67_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_68_local_1_scattered = fract(((paper_noise_62_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_68_local_2_shift = dot(paper_hash_68_local_1_scattered, (paper_hash_68_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_68_local_3_folded = (paper_hash_68_local_1_scattered + float3(paper_hash_68_local_2_shift, paper_hash_68_local_2_shift, paper_hash_68_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_62_local_9_far_low = mix(fract(((paper_hash_67_local_3_folded.x + paper_hash_67_local_3_folded.y) * paper_hash_67_local_3_folded.z)), fract(((paper_hash_68_local_3_folded.x + paper_hash_68_local_3_folded.y) * paper_hash_68_local_3_folded.z)), paper_noise_62_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_69_local_1_scattered = fract(((paper_noise_62_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_69_local_2_shift = dot(paper_hash_69_local_1_scattered, (paper_hash_69_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_69_local_3_folded = (paper_hash_69_local_1_scattered + float3(paper_hash_69_local_2_shift, paper_hash_69_local_2_shift, paper_hash_69_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_70_local_1_scattered = fract(((paper_noise_62_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_70_local_2_shift = dot(paper_hash_70_local_1_scattered, (paper_hash_70_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_70_local_3_folded = (paper_hash_70_local_1_scattered + float3(paper_hash_70_local_2_shift, paper_hash_70_local_2_shift, paper_hash_70_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_62_local_10_far_high = mix(fract(((paper_hash_69_local_3_folded.x + paper_hash_69_local_3_folded.y) * paper_hash_69_local_3_folded.z)), fract(((paper_hash_70_local_3_folded.x + paper_hash_70_local_3_folded.y) * paper_hash_70_local_3_folded.z)), paper_noise_62_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_71_local_1_lattice = floor((world * 13.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_71_local_2_offset = fract((world * 13.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_71_local_3_weight = (paper_noise_71_local_2_offset * (paper_noise_71_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_71_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_71_local_4_u = paper_noise_71_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_71_local_5_v = paper_noise_71_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_71_local_6_w = paper_noise_71_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_72_local_1_scattered = fract((paper_noise_71_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_72_local_2_shift = dot(paper_hash_72_local_1_scattered, (paper_hash_72_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_72_local_3_folded = (paper_hash_72_local_1_scattered + float3(paper_hash_72_local_2_shift, paper_hash_72_local_2_shift, paper_hash_72_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_73_local_1_scattered = fract(((paper_noise_71_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_73_local_2_shift = dot(paper_hash_73_local_1_scattered, (paper_hash_73_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_73_local_3_folded = (paper_hash_73_local_1_scattered + float3(paper_hash_73_local_2_shift, paper_hash_73_local_2_shift, paper_hash_73_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_71_local_7_near_low = mix(fract(((paper_hash_72_local_3_folded.x + paper_hash_72_local_3_folded.y) * paper_hash_72_local_3_folded.z)), fract(((paper_hash_73_local_3_folded.x + paper_hash_73_local_3_folded.y) * paper_hash_73_local_3_folded.z)), paper_noise_71_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_74_local_1_scattered = fract(((paper_noise_71_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_74_local_2_shift = dot(paper_hash_74_local_1_scattered, (paper_hash_74_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_74_local_3_folded = (paper_hash_74_local_1_scattered + float3(paper_hash_74_local_2_shift, paper_hash_74_local_2_shift, paper_hash_74_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_75_local_1_scattered = fract(((paper_noise_71_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_75_local_2_shift = dot(paper_hash_75_local_1_scattered, (paper_hash_75_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_75_local_3_folded = (paper_hash_75_local_1_scattered + float3(paper_hash_75_local_2_shift, paper_hash_75_local_2_shift, paper_hash_75_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_71_local_8_near_high = mix(fract(((paper_hash_74_local_3_folded.x + paper_hash_74_local_3_folded.y) * paper_hash_74_local_3_folded.z)), fract(((paper_hash_75_local_3_folded.x + paper_hash_75_local_3_folded.y) * paper_hash_75_local_3_folded.z)), paper_noise_71_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_76_local_1_scattered = fract(((paper_noise_71_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_76_local_2_shift = dot(paper_hash_76_local_1_scattered, (paper_hash_76_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_76_local_3_folded = (paper_hash_76_local_1_scattered + float3(paper_hash_76_local_2_shift, paper_hash_76_local_2_shift, paper_hash_76_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_77_local_1_scattered = fract(((paper_noise_71_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_77_local_2_shift = dot(paper_hash_77_local_1_scattered, (paper_hash_77_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_77_local_3_folded = (paper_hash_77_local_1_scattered + float3(paper_hash_77_local_2_shift, paper_hash_77_local_2_shift, paper_hash_77_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_71_local_9_far_low = mix(fract(((paper_hash_76_local_3_folded.x + paper_hash_76_local_3_folded.y) * paper_hash_76_local_3_folded.z)), fract(((paper_hash_77_local_3_folded.x + paper_hash_77_local_3_folded.y) * paper_hash_77_local_3_folded.z)), paper_noise_71_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_78_local_1_scattered = fract(((paper_noise_71_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_78_local_2_shift = dot(paper_hash_78_local_1_scattered, (paper_hash_78_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_78_local_3_folded = (paper_hash_78_local_1_scattered + float3(paper_hash_78_local_2_shift, paper_hash_78_local_2_shift, paper_hash_78_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_79_local_1_scattered = fract(((paper_noise_71_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_79_local_2_shift = dot(paper_hash_79_local_1_scattered, (paper_hash_79_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_79_local_3_folded = (paper_hash_79_local_1_scattered + float3(paper_hash_79_local_2_shift, paper_hash_79_local_2_shift, paper_hash_79_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_71_local_10_far_high = mix(fract(((paper_hash_78_local_3_folded.x + paper_hash_78_local_3_folded.y) * paper_hash_78_local_3_folded.z)), fract(((paper_hash_79_local_3_folded.x + paper_hash_79_local_3_folded.y) * paper_hash_79_local_3_folded.z)), paper_noise_71_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_81_local_1_lattice = floor((world * 1.9f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_81_local_2_offset = fract((world * 1.9f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_81_local_3_weight = (paper_noise_81_local_2_offset * (paper_noise_81_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_81_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_81_local_4_u = paper_noise_81_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_81_local_5_v = paper_noise_81_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_81_local_6_w = paper_noise_81_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_82_local_1_scattered = fract((paper_noise_81_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_82_local_2_shift = dot(paper_hash_82_local_1_scattered, (paper_hash_82_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_82_local_3_folded = (paper_hash_82_local_1_scattered + float3(paper_hash_82_local_2_shift, paper_hash_82_local_2_shift, paper_hash_82_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_83_local_1_scattered = fract(((paper_noise_81_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_83_local_2_shift = dot(paper_hash_83_local_1_scattered, (paper_hash_83_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_83_local_3_folded = (paper_hash_83_local_1_scattered + float3(paper_hash_83_local_2_shift, paper_hash_83_local_2_shift, paper_hash_83_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_81_local_7_near_low = mix(fract(((paper_hash_82_local_3_folded.x + paper_hash_82_local_3_folded.y) * paper_hash_82_local_3_folded.z)), fract(((paper_hash_83_local_3_folded.x + paper_hash_83_local_3_folded.y) * paper_hash_83_local_3_folded.z)), paper_noise_81_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_84_local_1_scattered = fract(((paper_noise_81_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_84_local_2_shift = dot(paper_hash_84_local_1_scattered, (paper_hash_84_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_84_local_3_folded = (paper_hash_84_local_1_scattered + float3(paper_hash_84_local_2_shift, paper_hash_84_local_2_shift, paper_hash_84_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_85_local_1_scattered = fract(((paper_noise_81_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_85_local_2_shift = dot(paper_hash_85_local_1_scattered, (paper_hash_85_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_85_local_3_folded = (paper_hash_85_local_1_scattered + float3(paper_hash_85_local_2_shift, paper_hash_85_local_2_shift, paper_hash_85_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_81_local_8_near_high = mix(fract(((paper_hash_84_local_3_folded.x + paper_hash_84_local_3_folded.y) * paper_hash_84_local_3_folded.z)), fract(((paper_hash_85_local_3_folded.x + paper_hash_85_local_3_folded.y) * paper_hash_85_local_3_folded.z)), paper_noise_81_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_86_local_1_scattered = fract(((paper_noise_81_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_86_local_2_shift = dot(paper_hash_86_local_1_scattered, (paper_hash_86_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_86_local_3_folded = (paper_hash_86_local_1_scattered + float3(paper_hash_86_local_2_shift, paper_hash_86_local_2_shift, paper_hash_86_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_87_local_1_scattered = fract(((paper_noise_81_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_87_local_2_shift = dot(paper_hash_87_local_1_scattered, (paper_hash_87_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_87_local_3_folded = (paper_hash_87_local_1_scattered + float3(paper_hash_87_local_2_shift, paper_hash_87_local_2_shift, paper_hash_87_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_81_local_9_far_low = mix(fract(((paper_hash_86_local_3_folded.x + paper_hash_86_local_3_folded.y) * paper_hash_86_local_3_folded.z)), fract(((paper_hash_87_local_3_folded.x + paper_hash_87_local_3_folded.y) * paper_hash_87_local_3_folded.z)), paper_noise_81_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_88_local_1_scattered = fract(((paper_noise_81_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_88_local_2_shift = dot(paper_hash_88_local_1_scattered, (paper_hash_88_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_88_local_3_folded = (paper_hash_88_local_1_scattered + float3(paper_hash_88_local_2_shift, paper_hash_88_local_2_shift, paper_hash_88_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_89_local_1_scattered = fract(((paper_noise_81_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_89_local_2_shift = dot(paper_hash_89_local_1_scattered, (paper_hash_89_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_89_local_3_folded = (paper_hash_89_local_1_scattered + float3(paper_hash_89_local_2_shift, paper_hash_89_local_2_shift, paper_hash_89_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_81_local_10_far_high = mix(fract(((paper_hash_88_local_3_folded.x + paper_hash_88_local_3_folded.y) * paper_hash_88_local_3_folded.z)), fract(((paper_hash_89_local_3_folded.x + paper_hash_89_local_3_folded.y) * paper_hash_89_local_3_folded.z)), paper_noise_81_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_90_local_1_lattice = floor((world * 0.7f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_90_local_2_offset = fract((world * 0.7f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_90_local_3_weight = (paper_noise_90_local_2_offset * (paper_noise_90_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_90_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_90_local_4_u = paper_noise_90_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_90_local_5_v = paper_noise_90_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_90_local_6_w = paper_noise_90_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_91_local_1_scattered = fract((paper_noise_90_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_91_local_2_shift = dot(paper_hash_91_local_1_scattered, (paper_hash_91_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_91_local_3_folded = (paper_hash_91_local_1_scattered + float3(paper_hash_91_local_2_shift, paper_hash_91_local_2_shift, paper_hash_91_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_92_local_1_scattered = fract(((paper_noise_90_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_92_local_2_shift = dot(paper_hash_92_local_1_scattered, (paper_hash_92_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_92_local_3_folded = (paper_hash_92_local_1_scattered + float3(paper_hash_92_local_2_shift, paper_hash_92_local_2_shift, paper_hash_92_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_90_local_7_near_low = mix(fract(((paper_hash_91_local_3_folded.x + paper_hash_91_local_3_folded.y) * paper_hash_91_local_3_folded.z)), fract(((paper_hash_92_local_3_folded.x + paper_hash_92_local_3_folded.y) * paper_hash_92_local_3_folded.z)), paper_noise_90_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_93_local_1_scattered = fract(((paper_noise_90_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_93_local_2_shift = dot(paper_hash_93_local_1_scattered, (paper_hash_93_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_93_local_3_folded = (paper_hash_93_local_1_scattered + float3(paper_hash_93_local_2_shift, paper_hash_93_local_2_shift, paper_hash_93_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_94_local_1_scattered = fract(((paper_noise_90_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_94_local_2_shift = dot(paper_hash_94_local_1_scattered, (paper_hash_94_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_94_local_3_folded = (paper_hash_94_local_1_scattered + float3(paper_hash_94_local_2_shift, paper_hash_94_local_2_shift, paper_hash_94_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_90_local_8_near_high = mix(fract(((paper_hash_93_local_3_folded.x + paper_hash_93_local_3_folded.y) * paper_hash_93_local_3_folded.z)), fract(((paper_hash_94_local_3_folded.x + paper_hash_94_local_3_folded.y) * paper_hash_94_local_3_folded.z)), paper_noise_90_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_95_local_1_scattered = fract(((paper_noise_90_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_95_local_2_shift = dot(paper_hash_95_local_1_scattered, (paper_hash_95_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_95_local_3_folded = (paper_hash_95_local_1_scattered + float3(paper_hash_95_local_2_shift, paper_hash_95_local_2_shift, paper_hash_95_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_96_local_1_scattered = fract(((paper_noise_90_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_96_local_2_shift = dot(paper_hash_96_local_1_scattered, (paper_hash_96_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_96_local_3_folded = (paper_hash_96_local_1_scattered + float3(paper_hash_96_local_2_shift, paper_hash_96_local_2_shift, paper_hash_96_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_90_local_9_far_low = mix(fract(((paper_hash_95_local_3_folded.x + paper_hash_95_local_3_folded.y) * paper_hash_95_local_3_folded.z)), fract(((paper_hash_96_local_3_folded.x + paper_hash_96_local_3_folded.y) * paper_hash_96_local_3_folded.z)), paper_noise_90_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_97_local_1_scattered = fract(((paper_noise_90_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_97_local_2_shift = dot(paper_hash_97_local_1_scattered, (paper_hash_97_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_97_local_3_folded = (paper_hash_97_local_1_scattered + float3(paper_hash_97_local_2_shift, paper_hash_97_local_2_shift, paper_hash_97_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_98_local_1_scattered = fract(((paper_noise_90_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_98_local_2_shift = dot(paper_hash_98_local_1_scattered, (paper_hash_98_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_98_local_3_folded = (paper_hash_98_local_1_scattered + float3(paper_hash_98_local_2_shift, paper_hash_98_local_2_shift, paper_hash_98_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_90_local_10_far_high = mix(fract(((paper_hash_97_local_3_folded.x + paper_hash_97_local_3_folded.y) * paper_hash_97_local_3_folded.z)), fract(((paper_hash_98_local_3_folded.x + paper_hash_98_local_3_folded.y) * paper_hash_98_local_3_folded.z)), paper_noise_90_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_99_local_1_lattice = floor((world * 7.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_99_local_2_offset = fract((world * 7.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_99_local_3_weight = (paper_noise_99_local_2_offset * (paper_noise_99_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_99_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_99_local_4_u = paper_noise_99_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_99_local_5_v = paper_noise_99_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_99_local_6_w = paper_noise_99_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_100_local_1_scattered = fract((paper_noise_99_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_100_local_2_shift = dot(paper_hash_100_local_1_scattered, (paper_hash_100_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_100_local_3_folded = (paper_hash_100_local_1_scattered + float3(paper_hash_100_local_2_shift, paper_hash_100_local_2_shift, paper_hash_100_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_101_local_1_scattered = fract(((paper_noise_99_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_101_local_2_shift = dot(paper_hash_101_local_1_scattered, (paper_hash_101_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_101_local_3_folded = (paper_hash_101_local_1_scattered + float3(paper_hash_101_local_2_shift, paper_hash_101_local_2_shift, paper_hash_101_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_99_local_7_near_low = mix(fract(((paper_hash_100_local_3_folded.x + paper_hash_100_local_3_folded.y) * paper_hash_100_local_3_folded.z)), fract(((paper_hash_101_local_3_folded.x + paper_hash_101_local_3_folded.y) * paper_hash_101_local_3_folded.z)), paper_noise_99_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_102_local_1_scattered = fract(((paper_noise_99_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_102_local_2_shift = dot(paper_hash_102_local_1_scattered, (paper_hash_102_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_102_local_3_folded = (paper_hash_102_local_1_scattered + float3(paper_hash_102_local_2_shift, paper_hash_102_local_2_shift, paper_hash_102_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_103_local_1_scattered = fract(((paper_noise_99_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_103_local_2_shift = dot(paper_hash_103_local_1_scattered, (paper_hash_103_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_103_local_3_folded = (paper_hash_103_local_1_scattered + float3(paper_hash_103_local_2_shift, paper_hash_103_local_2_shift, paper_hash_103_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_99_local_8_near_high = mix(fract(((paper_hash_102_local_3_folded.x + paper_hash_102_local_3_folded.y) * paper_hash_102_local_3_folded.z)), fract(((paper_hash_103_local_3_folded.x + paper_hash_103_local_3_folded.y) * paper_hash_103_local_3_folded.z)), paper_noise_99_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_104_local_1_scattered = fract(((paper_noise_99_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_104_local_2_shift = dot(paper_hash_104_local_1_scattered, (paper_hash_104_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_104_local_3_folded = (paper_hash_104_local_1_scattered + float3(paper_hash_104_local_2_shift, paper_hash_104_local_2_shift, paper_hash_104_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_105_local_1_scattered = fract(((paper_noise_99_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_105_local_2_shift = dot(paper_hash_105_local_1_scattered, (paper_hash_105_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_105_local_3_folded = (paper_hash_105_local_1_scattered + float3(paper_hash_105_local_2_shift, paper_hash_105_local_2_shift, paper_hash_105_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_99_local_9_far_low = mix(fract(((paper_hash_104_local_3_folded.x + paper_hash_104_local_3_folded.y) * paper_hash_104_local_3_folded.z)), fract(((paper_hash_105_local_3_folded.x + paper_hash_105_local_3_folded.y) * paper_hash_105_local_3_folded.z)), paper_noise_99_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_106_local_1_scattered = fract(((paper_noise_99_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_106_local_2_shift = dot(paper_hash_106_local_1_scattered, (paper_hash_106_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_106_local_3_folded = (paper_hash_106_local_1_scattered + float3(paper_hash_106_local_2_shift, paper_hash_106_local_2_shift, paper_hash_106_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_107_local_1_scattered = fract(((paper_noise_99_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_107_local_2_shift = dot(paper_hash_107_local_1_scattered, (paper_hash_107_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_107_local_3_folded = (paper_hash_107_local_1_scattered + float3(paper_hash_107_local_2_shift, paper_hash_107_local_2_shift, paper_hash_107_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_99_local_10_far_high = mix(fract(((paper_hash_106_local_3_folded.x + paper_hash_106_local_3_folded.y) * paper_hash_106_local_3_folded.z)), fract(((paper_hash_107_local_3_folded.x + paper_hash_107_local_3_folded.y) * paper_hash_107_local_3_folded.z)), paper_noise_99_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_108_local_1_lattice = floor((world * 9.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_108_local_2_offset = fract((world * 9.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_108_local_3_weight = (paper_noise_108_local_2_offset * (paper_noise_108_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_108_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_108_local_4_u = paper_noise_108_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_108_local_5_v = paper_noise_108_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_108_local_6_w = paper_noise_108_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_109_local_1_scattered = fract((paper_noise_108_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_109_local_2_shift = dot(paper_hash_109_local_1_scattered, (paper_hash_109_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_109_local_3_folded = (paper_hash_109_local_1_scattered + float3(paper_hash_109_local_2_shift, paper_hash_109_local_2_shift, paper_hash_109_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_110_local_1_scattered = fract(((paper_noise_108_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_110_local_2_shift = dot(paper_hash_110_local_1_scattered, (paper_hash_110_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_110_local_3_folded = (paper_hash_110_local_1_scattered + float3(paper_hash_110_local_2_shift, paper_hash_110_local_2_shift, paper_hash_110_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_108_local_7_near_low = mix(fract(((paper_hash_109_local_3_folded.x + paper_hash_109_local_3_folded.y) * paper_hash_109_local_3_folded.z)), fract(((paper_hash_110_local_3_folded.x + paper_hash_110_local_3_folded.y) * paper_hash_110_local_3_folded.z)), paper_noise_108_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_111_local_1_scattered = fract(((paper_noise_108_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_111_local_2_shift = dot(paper_hash_111_local_1_scattered, (paper_hash_111_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_111_local_3_folded = (paper_hash_111_local_1_scattered + float3(paper_hash_111_local_2_shift, paper_hash_111_local_2_shift, paper_hash_111_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_112_local_1_scattered = fract(((paper_noise_108_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_112_local_2_shift = dot(paper_hash_112_local_1_scattered, (paper_hash_112_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_112_local_3_folded = (paper_hash_112_local_1_scattered + float3(paper_hash_112_local_2_shift, paper_hash_112_local_2_shift, paper_hash_112_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_108_local_8_near_high = mix(fract(((paper_hash_111_local_3_folded.x + paper_hash_111_local_3_folded.y) * paper_hash_111_local_3_folded.z)), fract(((paper_hash_112_local_3_folded.x + paper_hash_112_local_3_folded.y) * paper_hash_112_local_3_folded.z)), paper_noise_108_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_113_local_1_scattered = fract(((paper_noise_108_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_113_local_2_shift = dot(paper_hash_113_local_1_scattered, (paper_hash_113_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_113_local_3_folded = (paper_hash_113_local_1_scattered + float3(paper_hash_113_local_2_shift, paper_hash_113_local_2_shift, paper_hash_113_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_114_local_1_scattered = fract(((paper_noise_108_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_114_local_2_shift = dot(paper_hash_114_local_1_scattered, (paper_hash_114_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_114_local_3_folded = (paper_hash_114_local_1_scattered + float3(paper_hash_114_local_2_shift, paper_hash_114_local_2_shift, paper_hash_114_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_108_local_9_far_low = mix(fract(((paper_hash_113_local_3_folded.x + paper_hash_113_local_3_folded.y) * paper_hash_113_local_3_folded.z)), fract(((paper_hash_114_local_3_folded.x + paper_hash_114_local_3_folded.y) * paper_hash_114_local_3_folded.z)), paper_noise_108_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_115_local_1_scattered = fract(((paper_noise_108_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_115_local_2_shift = dot(paper_hash_115_local_1_scattered, (paper_hash_115_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_115_local_3_folded = (paper_hash_115_local_1_scattered + float3(paper_hash_115_local_2_shift, paper_hash_115_local_2_shift, paper_hash_115_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_116_local_1_scattered = fract(((paper_noise_108_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_116_local_2_shift = dot(paper_hash_116_local_1_scattered, (paper_hash_116_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_116_local_3_folded = (paper_hash_116_local_1_scattered + float3(paper_hash_116_local_2_shift, paper_hash_116_local_2_shift, paper_hash_116_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_108_local_10_far_high = mix(fract(((paper_hash_115_local_3_folded.x + paper_hash_115_local_3_folded.y) * paper_hash_115_local_3_folded.z)), fract(((paper_hash_116_local_3_folded.x + paper_hash_116_local_3_folded.y) * paper_hash_116_local_3_folded.z)), paper_noise_108_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_117_local_1_lattice = floor((world * 2.3f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_117_local_2_offset = fract((world * 2.3f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_117_local_3_weight = (paper_noise_117_local_2_offset * (paper_noise_117_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_117_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_117_local_4_u = paper_noise_117_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_117_local_5_v = paper_noise_117_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_117_local_6_w = paper_noise_117_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_118_local_1_scattered = fract((paper_noise_117_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_118_local_2_shift = dot(paper_hash_118_local_1_scattered, (paper_hash_118_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_118_local_3_folded = (paper_hash_118_local_1_scattered + float3(paper_hash_118_local_2_shift, paper_hash_118_local_2_shift, paper_hash_118_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_119_local_1_scattered = fract(((paper_noise_117_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_119_local_2_shift = dot(paper_hash_119_local_1_scattered, (paper_hash_119_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_119_local_3_folded = (paper_hash_119_local_1_scattered + float3(paper_hash_119_local_2_shift, paper_hash_119_local_2_shift, paper_hash_119_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_117_local_7_near_low = mix(fract(((paper_hash_118_local_3_folded.x + paper_hash_118_local_3_folded.y) * paper_hash_118_local_3_folded.z)), fract(((paper_hash_119_local_3_folded.x + paper_hash_119_local_3_folded.y) * paper_hash_119_local_3_folded.z)), paper_noise_117_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_120_local_1_scattered = fract(((paper_noise_117_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_120_local_2_shift = dot(paper_hash_120_local_1_scattered, (paper_hash_120_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_120_local_3_folded = (paper_hash_120_local_1_scattered + float3(paper_hash_120_local_2_shift, paper_hash_120_local_2_shift, paper_hash_120_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_121_local_1_scattered = fract(((paper_noise_117_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_121_local_2_shift = dot(paper_hash_121_local_1_scattered, (paper_hash_121_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_121_local_3_folded = (paper_hash_121_local_1_scattered + float3(paper_hash_121_local_2_shift, paper_hash_121_local_2_shift, paper_hash_121_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_117_local_8_near_high = mix(fract(((paper_hash_120_local_3_folded.x + paper_hash_120_local_3_folded.y) * paper_hash_120_local_3_folded.z)), fract(((paper_hash_121_local_3_folded.x + paper_hash_121_local_3_folded.y) * paper_hash_121_local_3_folded.z)), paper_noise_117_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_122_local_1_scattered = fract(((paper_noise_117_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_122_local_2_shift = dot(paper_hash_122_local_1_scattered, (paper_hash_122_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_122_local_3_folded = (paper_hash_122_local_1_scattered + float3(paper_hash_122_local_2_shift, paper_hash_122_local_2_shift, paper_hash_122_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_123_local_1_scattered = fract(((paper_noise_117_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_123_local_2_shift = dot(paper_hash_123_local_1_scattered, (paper_hash_123_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_123_local_3_folded = (paper_hash_123_local_1_scattered + float3(paper_hash_123_local_2_shift, paper_hash_123_local_2_shift, paper_hash_123_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_117_local_9_far_low = mix(fract(((paper_hash_122_local_3_folded.x + paper_hash_122_local_3_folded.y) * paper_hash_122_local_3_folded.z)), fract(((paper_hash_123_local_3_folded.x + paper_hash_123_local_3_folded.y) * paper_hash_123_local_3_folded.z)), paper_noise_117_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_124_local_1_scattered = fract(((paper_noise_117_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_124_local_2_shift = dot(paper_hash_124_local_1_scattered, (paper_hash_124_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_124_local_3_folded = (paper_hash_124_local_1_scattered + float3(paper_hash_124_local_2_shift, paper_hash_124_local_2_shift, paper_hash_124_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_125_local_1_scattered = fract(((paper_noise_117_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_125_local_2_shift = dot(paper_hash_125_local_1_scattered, (paper_hash_125_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_125_local_3_folded = (paper_hash_125_local_1_scattered + float3(paper_hash_125_local_2_shift, paper_hash_125_local_2_shift, paper_hash_125_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_117_local_10_far_high = mix(fract(((paper_hash_124_local_3_folded.x + paper_hash_124_local_3_folded.y) * paper_hash_124_local_3_folded.z)), fract(((paper_hash_125_local_3_folded.x + paper_hash_125_local_3_folded.y) * paper_hash_125_local_3_folded.z)), paper_noise_117_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_127_local_1_lattice = floor((world * float3(5.5f, 5.5f, 0.6f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_127_local_2_offset = fract((world * float3(5.5f, 5.5f, 0.6f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_127_local_3_weight = (paper_noise_127_local_2_offset * (paper_noise_127_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_127_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_127_local_4_u = paper_noise_127_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_127_local_5_v = paper_noise_127_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_127_local_6_w = paper_noise_127_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_128_local_1_scattered = fract((paper_noise_127_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_128_local_2_shift = dot(paper_hash_128_local_1_scattered, (paper_hash_128_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_128_local_3_folded = (paper_hash_128_local_1_scattered + float3(paper_hash_128_local_2_shift, paper_hash_128_local_2_shift, paper_hash_128_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_129_local_1_scattered = fract(((paper_noise_127_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_129_local_2_shift = dot(paper_hash_129_local_1_scattered, (paper_hash_129_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_129_local_3_folded = (paper_hash_129_local_1_scattered + float3(paper_hash_129_local_2_shift, paper_hash_129_local_2_shift, paper_hash_129_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_127_local_7_near_low = mix(fract(((paper_hash_128_local_3_folded.x + paper_hash_128_local_3_folded.y) * paper_hash_128_local_3_folded.z)), fract(((paper_hash_129_local_3_folded.x + paper_hash_129_local_3_folded.y) * paper_hash_129_local_3_folded.z)), paper_noise_127_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_130_local_1_scattered = fract(((paper_noise_127_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_130_local_2_shift = dot(paper_hash_130_local_1_scattered, (paper_hash_130_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_130_local_3_folded = (paper_hash_130_local_1_scattered + float3(paper_hash_130_local_2_shift, paper_hash_130_local_2_shift, paper_hash_130_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_131_local_1_scattered = fract(((paper_noise_127_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_131_local_2_shift = dot(paper_hash_131_local_1_scattered, (paper_hash_131_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_131_local_3_folded = (paper_hash_131_local_1_scattered + float3(paper_hash_131_local_2_shift, paper_hash_131_local_2_shift, paper_hash_131_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_127_local_8_near_high = mix(fract(((paper_hash_130_local_3_folded.x + paper_hash_130_local_3_folded.y) * paper_hash_130_local_3_folded.z)), fract(((paper_hash_131_local_3_folded.x + paper_hash_131_local_3_folded.y) * paper_hash_131_local_3_folded.z)), paper_noise_127_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_132_local_1_scattered = fract(((paper_noise_127_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_132_local_2_shift = dot(paper_hash_132_local_1_scattered, (paper_hash_132_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_132_local_3_folded = (paper_hash_132_local_1_scattered + float3(paper_hash_132_local_2_shift, paper_hash_132_local_2_shift, paper_hash_132_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_133_local_1_scattered = fract(((paper_noise_127_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_133_local_2_shift = dot(paper_hash_133_local_1_scattered, (paper_hash_133_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_133_local_3_folded = (paper_hash_133_local_1_scattered + float3(paper_hash_133_local_2_shift, paper_hash_133_local_2_shift, paper_hash_133_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_127_local_9_far_low = mix(fract(((paper_hash_132_local_3_folded.x + paper_hash_132_local_3_folded.y) * paper_hash_132_local_3_folded.z)), fract(((paper_hash_133_local_3_folded.x + paper_hash_133_local_3_folded.y) * paper_hash_133_local_3_folded.z)), paper_noise_127_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_134_local_1_scattered = fract(((paper_noise_127_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_134_local_2_shift = dot(paper_hash_134_local_1_scattered, (paper_hash_134_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_134_local_3_folded = (paper_hash_134_local_1_scattered + float3(paper_hash_134_local_2_shift, paper_hash_134_local_2_shift, paper_hash_134_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_135_local_1_scattered = fract(((paper_noise_127_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_135_local_2_shift = dot(paper_hash_135_local_1_scattered, (paper_hash_135_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_135_local_3_folded = (paper_hash_135_local_1_scattered + float3(paper_hash_135_local_2_shift, paper_hash_135_local_2_shift, paper_hash_135_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_127_local_10_far_high = mix(fract(((paper_hash_134_local_3_folded.x + paper_hash_134_local_3_folded.y) * paper_hash_134_local_3_folded.z)), fract(((paper_hash_135_local_3_folded.x + paper_hash_135_local_3_folded.y) * paper_hash_135_local_3_folded.z)), paper_noise_127_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_136_local_1_lattice = floor((world * 5.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_136_local_2_offset = fract((world * 5.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_136_local_3_weight = (paper_noise_136_local_2_offset * (paper_noise_136_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_136_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_136_local_4_u = paper_noise_136_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_136_local_5_v = paper_noise_136_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_136_local_6_w = paper_noise_136_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_137_local_1_scattered = fract((paper_noise_136_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_137_local_2_shift = dot(paper_hash_137_local_1_scattered, (paper_hash_137_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_137_local_3_folded = (paper_hash_137_local_1_scattered + float3(paper_hash_137_local_2_shift, paper_hash_137_local_2_shift, paper_hash_137_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_138_local_1_scattered = fract(((paper_noise_136_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_138_local_2_shift = dot(paper_hash_138_local_1_scattered, (paper_hash_138_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_138_local_3_folded = (paper_hash_138_local_1_scattered + float3(paper_hash_138_local_2_shift, paper_hash_138_local_2_shift, paper_hash_138_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_136_local_7_near_low = mix(fract(((paper_hash_137_local_3_folded.x + paper_hash_137_local_3_folded.y) * paper_hash_137_local_3_folded.z)), fract(((paper_hash_138_local_3_folded.x + paper_hash_138_local_3_folded.y) * paper_hash_138_local_3_folded.z)), paper_noise_136_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_139_local_1_scattered = fract(((paper_noise_136_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_139_local_2_shift = dot(paper_hash_139_local_1_scattered, (paper_hash_139_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_139_local_3_folded = (paper_hash_139_local_1_scattered + float3(paper_hash_139_local_2_shift, paper_hash_139_local_2_shift, paper_hash_139_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_140_local_1_scattered = fract(((paper_noise_136_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_140_local_2_shift = dot(paper_hash_140_local_1_scattered, (paper_hash_140_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_140_local_3_folded = (paper_hash_140_local_1_scattered + float3(paper_hash_140_local_2_shift, paper_hash_140_local_2_shift, paper_hash_140_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_136_local_8_near_high = mix(fract(((paper_hash_139_local_3_folded.x + paper_hash_139_local_3_folded.y) * paper_hash_139_local_3_folded.z)), fract(((paper_hash_140_local_3_folded.x + paper_hash_140_local_3_folded.y) * paper_hash_140_local_3_folded.z)), paper_noise_136_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_141_local_1_scattered = fract(((paper_noise_136_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_141_local_2_shift = dot(paper_hash_141_local_1_scattered, (paper_hash_141_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_141_local_3_folded = (paper_hash_141_local_1_scattered + float3(paper_hash_141_local_2_shift, paper_hash_141_local_2_shift, paper_hash_141_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_142_local_1_scattered = fract(((paper_noise_136_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_142_local_2_shift = dot(paper_hash_142_local_1_scattered, (paper_hash_142_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_142_local_3_folded = (paper_hash_142_local_1_scattered + float3(paper_hash_142_local_2_shift, paper_hash_142_local_2_shift, paper_hash_142_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_136_local_9_far_low = mix(fract(((paper_hash_141_local_3_folded.x + paper_hash_141_local_3_folded.y) * paper_hash_141_local_3_folded.z)), fract(((paper_hash_142_local_3_folded.x + paper_hash_142_local_3_folded.y) * paper_hash_142_local_3_folded.z)), paper_noise_136_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_143_local_1_scattered = fract(((paper_noise_136_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_143_local_2_shift = dot(paper_hash_143_local_1_scattered, (paper_hash_143_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_143_local_3_folded = (paper_hash_143_local_1_scattered + float3(paper_hash_143_local_2_shift, paper_hash_143_local_2_shift, paper_hash_143_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_144_local_1_scattered = fract(((paper_noise_136_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_144_local_2_shift = dot(paper_hash_144_local_1_scattered, (paper_hash_144_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_144_local_3_folded = (paper_hash_144_local_1_scattered + float3(paper_hash_144_local_2_shift, paper_hash_144_local_2_shift, paper_hash_144_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_136_local_10_far_high = mix(fract(((paper_hash_143_local_3_folded.x + paper_hash_143_local_3_folded.y) * paper_hash_143_local_3_folded.z)), fract(((paper_hash_144_local_3_folded.x + paper_hash_144_local_3_folded.y) * paper_hash_144_local_3_folded.z)), paper_noise_136_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_145_local_1_lattice = floor((world * 14.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_145_local_2_offset = fract((world * 14.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_145_local_3_weight = (paper_noise_145_local_2_offset * (paper_noise_145_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_145_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_145_local_4_u = paper_noise_145_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_145_local_5_v = paper_noise_145_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_145_local_6_w = paper_noise_145_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_146_local_1_scattered = fract((paper_noise_145_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_146_local_2_shift = dot(paper_hash_146_local_1_scattered, (paper_hash_146_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_146_local_3_folded = (paper_hash_146_local_1_scattered + float3(paper_hash_146_local_2_shift, paper_hash_146_local_2_shift, paper_hash_146_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_147_local_1_scattered = fract(((paper_noise_145_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_147_local_2_shift = dot(paper_hash_147_local_1_scattered, (paper_hash_147_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_147_local_3_folded = (paper_hash_147_local_1_scattered + float3(paper_hash_147_local_2_shift, paper_hash_147_local_2_shift, paper_hash_147_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_145_local_7_near_low = mix(fract(((paper_hash_146_local_3_folded.x + paper_hash_146_local_3_folded.y) * paper_hash_146_local_3_folded.z)), fract(((paper_hash_147_local_3_folded.x + paper_hash_147_local_3_folded.y) * paper_hash_147_local_3_folded.z)), paper_noise_145_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_148_local_1_scattered = fract(((paper_noise_145_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_148_local_2_shift = dot(paper_hash_148_local_1_scattered, (paper_hash_148_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_148_local_3_folded = (paper_hash_148_local_1_scattered + float3(paper_hash_148_local_2_shift, paper_hash_148_local_2_shift, paper_hash_148_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_149_local_1_scattered = fract(((paper_noise_145_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_149_local_2_shift = dot(paper_hash_149_local_1_scattered, (paper_hash_149_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_149_local_3_folded = (paper_hash_149_local_1_scattered + float3(paper_hash_149_local_2_shift, paper_hash_149_local_2_shift, paper_hash_149_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_145_local_8_near_high = mix(fract(((paper_hash_148_local_3_folded.x + paper_hash_148_local_3_folded.y) * paper_hash_148_local_3_folded.z)), fract(((paper_hash_149_local_3_folded.x + paper_hash_149_local_3_folded.y) * paper_hash_149_local_3_folded.z)), paper_noise_145_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_150_local_1_scattered = fract(((paper_noise_145_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_150_local_2_shift = dot(paper_hash_150_local_1_scattered, (paper_hash_150_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_150_local_3_folded = (paper_hash_150_local_1_scattered + float3(paper_hash_150_local_2_shift, paper_hash_150_local_2_shift, paper_hash_150_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_151_local_1_scattered = fract(((paper_noise_145_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_151_local_2_shift = dot(paper_hash_151_local_1_scattered, (paper_hash_151_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_151_local_3_folded = (paper_hash_151_local_1_scattered + float3(paper_hash_151_local_2_shift, paper_hash_151_local_2_shift, paper_hash_151_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_145_local_9_far_low = mix(fract(((paper_hash_150_local_3_folded.x + paper_hash_150_local_3_folded.y) * paper_hash_150_local_3_folded.z)), fract(((paper_hash_151_local_3_folded.x + paper_hash_151_local_3_folded.y) * paper_hash_151_local_3_folded.z)), paper_noise_145_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_152_local_1_scattered = fract(((paper_noise_145_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_152_local_2_shift = dot(paper_hash_152_local_1_scattered, (paper_hash_152_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_152_local_3_folded = (paper_hash_152_local_1_scattered + float3(paper_hash_152_local_2_shift, paper_hash_152_local_2_shift, paper_hash_152_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_153_local_1_scattered = fract(((paper_noise_145_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_153_local_2_shift = dot(paper_hash_153_local_1_scattered, (paper_hash_153_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_153_local_3_folded = (paper_hash_153_local_1_scattered + float3(paper_hash_153_local_2_shift, paper_hash_153_local_2_shift, paper_hash_153_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_145_local_10_far_high = mix(fract(((paper_hash_152_local_3_folded.x + paper_hash_152_local_3_folded.y) * paper_hash_152_local_3_folded.z)), fract(((paper_hash_153_local_3_folded.x + paper_hash_153_local_3_folded.y) * paper_hash_153_local_3_folded.z)), paper_noise_145_local_4_u);
  // This numeric value has no quantity annotation.
  float plank_height_154_local_1_u = fract(((world.x + world.y) * 4.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_155_local_1_lattice = floor((world * float3(1.0f, 1.0f, 9.0f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_155_local_2_offset = fract((world * float3(1.0f, 1.0f, 9.0f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_155_local_3_weight = (paper_noise_155_local_2_offset * (paper_noise_155_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_155_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_155_local_4_u = paper_noise_155_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_155_local_5_v = paper_noise_155_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_155_local_6_w = paper_noise_155_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_156_local_1_scattered = fract((paper_noise_155_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_156_local_2_shift = dot(paper_hash_156_local_1_scattered, (paper_hash_156_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_156_local_3_folded = (paper_hash_156_local_1_scattered + float3(paper_hash_156_local_2_shift, paper_hash_156_local_2_shift, paper_hash_156_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_157_local_1_scattered = fract(((paper_noise_155_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_157_local_2_shift = dot(paper_hash_157_local_1_scattered, (paper_hash_157_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_157_local_3_folded = (paper_hash_157_local_1_scattered + float3(paper_hash_157_local_2_shift, paper_hash_157_local_2_shift, paper_hash_157_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_155_local_7_near_low = mix(fract(((paper_hash_156_local_3_folded.x + paper_hash_156_local_3_folded.y) * paper_hash_156_local_3_folded.z)), fract(((paper_hash_157_local_3_folded.x + paper_hash_157_local_3_folded.y) * paper_hash_157_local_3_folded.z)), paper_noise_155_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_158_local_1_scattered = fract(((paper_noise_155_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_158_local_2_shift = dot(paper_hash_158_local_1_scattered, (paper_hash_158_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_158_local_3_folded = (paper_hash_158_local_1_scattered + float3(paper_hash_158_local_2_shift, paper_hash_158_local_2_shift, paper_hash_158_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_159_local_1_scattered = fract(((paper_noise_155_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_159_local_2_shift = dot(paper_hash_159_local_1_scattered, (paper_hash_159_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_159_local_3_folded = (paper_hash_159_local_1_scattered + float3(paper_hash_159_local_2_shift, paper_hash_159_local_2_shift, paper_hash_159_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_155_local_8_near_high = mix(fract(((paper_hash_158_local_3_folded.x + paper_hash_158_local_3_folded.y) * paper_hash_158_local_3_folded.z)), fract(((paper_hash_159_local_3_folded.x + paper_hash_159_local_3_folded.y) * paper_hash_159_local_3_folded.z)), paper_noise_155_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_160_local_1_scattered = fract(((paper_noise_155_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_160_local_2_shift = dot(paper_hash_160_local_1_scattered, (paper_hash_160_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_160_local_3_folded = (paper_hash_160_local_1_scattered + float3(paper_hash_160_local_2_shift, paper_hash_160_local_2_shift, paper_hash_160_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_161_local_1_scattered = fract(((paper_noise_155_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_161_local_2_shift = dot(paper_hash_161_local_1_scattered, (paper_hash_161_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_161_local_3_folded = (paper_hash_161_local_1_scattered + float3(paper_hash_161_local_2_shift, paper_hash_161_local_2_shift, paper_hash_161_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_155_local_9_far_low = mix(fract(((paper_hash_160_local_3_folded.x + paper_hash_160_local_3_folded.y) * paper_hash_160_local_3_folded.z)), fract(((paper_hash_161_local_3_folded.x + paper_hash_161_local_3_folded.y) * paper_hash_161_local_3_folded.z)), paper_noise_155_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_162_local_1_scattered = fract(((paper_noise_155_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_162_local_2_shift = dot(paper_hash_162_local_1_scattered, (paper_hash_162_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_162_local_3_folded = (paper_hash_162_local_1_scattered + float3(paper_hash_162_local_2_shift, paper_hash_162_local_2_shift, paper_hash_162_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_163_local_1_scattered = fract(((paper_noise_155_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_163_local_2_shift = dot(paper_hash_163_local_1_scattered, (paper_hash_163_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_163_local_3_folded = (paper_hash_163_local_1_scattered + float3(paper_hash_163_local_2_shift, paper_hash_163_local_2_shift, paper_hash_163_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_155_local_10_far_high = mix(fract(((paper_hash_162_local_3_folded.x + paper_hash_162_local_3_folded.y) * paper_hash_162_local_3_folded.z)), fract(((paper_hash_163_local_3_folded.x + paper_hash_163_local_3_folded.y) * paper_hash_163_local_3_folded.z)), paper_noise_155_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_164_local_1_lattice = floor((world * 1.3f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_164_local_2_offset = fract((world * 1.3f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_164_local_3_weight = (paper_noise_164_local_2_offset * (paper_noise_164_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_164_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_164_local_4_u = paper_noise_164_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_164_local_5_v = paper_noise_164_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_164_local_6_w = paper_noise_164_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_165_local_1_scattered = fract((paper_noise_164_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_165_local_2_shift = dot(paper_hash_165_local_1_scattered, (paper_hash_165_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_165_local_3_folded = (paper_hash_165_local_1_scattered + float3(paper_hash_165_local_2_shift, paper_hash_165_local_2_shift, paper_hash_165_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_166_local_1_scattered = fract(((paper_noise_164_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_166_local_2_shift = dot(paper_hash_166_local_1_scattered, (paper_hash_166_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_166_local_3_folded = (paper_hash_166_local_1_scattered + float3(paper_hash_166_local_2_shift, paper_hash_166_local_2_shift, paper_hash_166_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_164_local_7_near_low = mix(fract(((paper_hash_165_local_3_folded.x + paper_hash_165_local_3_folded.y) * paper_hash_165_local_3_folded.z)), fract(((paper_hash_166_local_3_folded.x + paper_hash_166_local_3_folded.y) * paper_hash_166_local_3_folded.z)), paper_noise_164_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_167_local_1_scattered = fract(((paper_noise_164_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_167_local_2_shift = dot(paper_hash_167_local_1_scattered, (paper_hash_167_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_167_local_3_folded = (paper_hash_167_local_1_scattered + float3(paper_hash_167_local_2_shift, paper_hash_167_local_2_shift, paper_hash_167_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_168_local_1_scattered = fract(((paper_noise_164_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_168_local_2_shift = dot(paper_hash_168_local_1_scattered, (paper_hash_168_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_168_local_3_folded = (paper_hash_168_local_1_scattered + float3(paper_hash_168_local_2_shift, paper_hash_168_local_2_shift, paper_hash_168_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_164_local_8_near_high = mix(fract(((paper_hash_167_local_3_folded.x + paper_hash_167_local_3_folded.y) * paper_hash_167_local_3_folded.z)), fract(((paper_hash_168_local_3_folded.x + paper_hash_168_local_3_folded.y) * paper_hash_168_local_3_folded.z)), paper_noise_164_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_169_local_1_scattered = fract(((paper_noise_164_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_169_local_2_shift = dot(paper_hash_169_local_1_scattered, (paper_hash_169_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_169_local_3_folded = (paper_hash_169_local_1_scattered + float3(paper_hash_169_local_2_shift, paper_hash_169_local_2_shift, paper_hash_169_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_170_local_1_scattered = fract(((paper_noise_164_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_170_local_2_shift = dot(paper_hash_170_local_1_scattered, (paper_hash_170_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_170_local_3_folded = (paper_hash_170_local_1_scattered + float3(paper_hash_170_local_2_shift, paper_hash_170_local_2_shift, paper_hash_170_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_164_local_9_far_low = mix(fract(((paper_hash_169_local_3_folded.x + paper_hash_169_local_3_folded.y) * paper_hash_169_local_3_folded.z)), fract(((paper_hash_170_local_3_folded.x + paper_hash_170_local_3_folded.y) * paper_hash_170_local_3_folded.z)), paper_noise_164_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_171_local_1_scattered = fract(((paper_noise_164_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_171_local_2_shift = dot(paper_hash_171_local_1_scattered, (paper_hash_171_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_171_local_3_folded = (paper_hash_171_local_1_scattered + float3(paper_hash_171_local_2_shift, paper_hash_171_local_2_shift, paper_hash_171_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_172_local_1_scattered = fract(((paper_noise_164_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_172_local_2_shift = dot(paper_hash_172_local_1_scattered, (paper_hash_172_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_172_local_3_folded = (paper_hash_172_local_1_scattered + float3(paper_hash_172_local_2_shift, paper_hash_172_local_2_shift, paper_hash_172_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_164_local_10_far_high = mix(fract(((paper_hash_171_local_3_folded.x + paper_hash_171_local_3_folded.y) * paper_hash_171_local_3_folded.z)), fract(((paper_hash_172_local_3_folded.x + paper_hash_172_local_3_folded.y) * paper_hash_172_local_3_folded.z)), paper_noise_164_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_173_local_1_lattice = floor((world * 4.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_173_local_2_offset = fract((world * 4.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_173_local_3_weight = (paper_noise_173_local_2_offset * (paper_noise_173_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_173_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_173_local_4_u = paper_noise_173_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_173_local_5_v = paper_noise_173_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_173_local_6_w = paper_noise_173_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_174_local_1_scattered = fract((paper_noise_173_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_174_local_2_shift = dot(paper_hash_174_local_1_scattered, (paper_hash_174_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_174_local_3_folded = (paper_hash_174_local_1_scattered + float3(paper_hash_174_local_2_shift, paper_hash_174_local_2_shift, paper_hash_174_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_175_local_1_scattered = fract(((paper_noise_173_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_175_local_2_shift = dot(paper_hash_175_local_1_scattered, (paper_hash_175_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_175_local_3_folded = (paper_hash_175_local_1_scattered + float3(paper_hash_175_local_2_shift, paper_hash_175_local_2_shift, paper_hash_175_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_173_local_7_near_low = mix(fract(((paper_hash_174_local_3_folded.x + paper_hash_174_local_3_folded.y) * paper_hash_174_local_3_folded.z)), fract(((paper_hash_175_local_3_folded.x + paper_hash_175_local_3_folded.y) * paper_hash_175_local_3_folded.z)), paper_noise_173_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_176_local_1_scattered = fract(((paper_noise_173_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_176_local_2_shift = dot(paper_hash_176_local_1_scattered, (paper_hash_176_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_176_local_3_folded = (paper_hash_176_local_1_scattered + float3(paper_hash_176_local_2_shift, paper_hash_176_local_2_shift, paper_hash_176_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_177_local_1_scattered = fract(((paper_noise_173_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_177_local_2_shift = dot(paper_hash_177_local_1_scattered, (paper_hash_177_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_177_local_3_folded = (paper_hash_177_local_1_scattered + float3(paper_hash_177_local_2_shift, paper_hash_177_local_2_shift, paper_hash_177_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_173_local_8_near_high = mix(fract(((paper_hash_176_local_3_folded.x + paper_hash_176_local_3_folded.y) * paper_hash_176_local_3_folded.z)), fract(((paper_hash_177_local_3_folded.x + paper_hash_177_local_3_folded.y) * paper_hash_177_local_3_folded.z)), paper_noise_173_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_178_local_1_scattered = fract(((paper_noise_173_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_178_local_2_shift = dot(paper_hash_178_local_1_scattered, (paper_hash_178_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_178_local_3_folded = (paper_hash_178_local_1_scattered + float3(paper_hash_178_local_2_shift, paper_hash_178_local_2_shift, paper_hash_178_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_179_local_1_scattered = fract(((paper_noise_173_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_179_local_2_shift = dot(paper_hash_179_local_1_scattered, (paper_hash_179_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_179_local_3_folded = (paper_hash_179_local_1_scattered + float3(paper_hash_179_local_2_shift, paper_hash_179_local_2_shift, paper_hash_179_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_173_local_9_far_low = mix(fract(((paper_hash_178_local_3_folded.x + paper_hash_178_local_3_folded.y) * paper_hash_178_local_3_folded.z)), fract(((paper_hash_179_local_3_folded.x + paper_hash_179_local_3_folded.y) * paper_hash_179_local_3_folded.z)), paper_noise_173_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_180_local_1_scattered = fract(((paper_noise_173_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_180_local_2_shift = dot(paper_hash_180_local_1_scattered, (paper_hash_180_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_180_local_3_folded = (paper_hash_180_local_1_scattered + float3(paper_hash_180_local_2_shift, paper_hash_180_local_2_shift, paper_hash_180_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_181_local_1_scattered = fract(((paper_noise_173_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_181_local_2_shift = dot(paper_hash_181_local_1_scattered, (paper_hash_181_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_181_local_3_folded = (paper_hash_181_local_1_scattered + float3(paper_hash_181_local_2_shift, paper_hash_181_local_2_shift, paper_hash_181_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_173_local_10_far_high = mix(fract(((paper_hash_180_local_3_folded.x + paper_hash_180_local_3_folded.y) * paper_hash_180_local_3_folded.z)), fract(((paper_hash_181_local_3_folded.x + paper_hash_181_local_3_folded.y) * paper_hash_181_local_3_folded.z)), paper_noise_173_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_182_local_1_lattice = floor((world * 2.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_182_local_2_offset = fract((world * 2.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_182_local_3_weight = (paper_noise_182_local_2_offset * (paper_noise_182_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_182_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_182_local_4_u = paper_noise_182_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_182_local_5_v = paper_noise_182_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_182_local_6_w = paper_noise_182_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_183_local_1_scattered = fract((paper_noise_182_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_183_local_2_shift = dot(paper_hash_183_local_1_scattered, (paper_hash_183_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_183_local_3_folded = (paper_hash_183_local_1_scattered + float3(paper_hash_183_local_2_shift, paper_hash_183_local_2_shift, paper_hash_183_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_184_local_1_scattered = fract(((paper_noise_182_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_184_local_2_shift = dot(paper_hash_184_local_1_scattered, (paper_hash_184_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_184_local_3_folded = (paper_hash_184_local_1_scattered + float3(paper_hash_184_local_2_shift, paper_hash_184_local_2_shift, paper_hash_184_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_182_local_7_near_low = mix(fract(((paper_hash_183_local_3_folded.x + paper_hash_183_local_3_folded.y) * paper_hash_183_local_3_folded.z)), fract(((paper_hash_184_local_3_folded.x + paper_hash_184_local_3_folded.y) * paper_hash_184_local_3_folded.z)), paper_noise_182_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_185_local_1_scattered = fract(((paper_noise_182_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_185_local_2_shift = dot(paper_hash_185_local_1_scattered, (paper_hash_185_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_185_local_3_folded = (paper_hash_185_local_1_scattered + float3(paper_hash_185_local_2_shift, paper_hash_185_local_2_shift, paper_hash_185_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_186_local_1_scattered = fract(((paper_noise_182_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_186_local_2_shift = dot(paper_hash_186_local_1_scattered, (paper_hash_186_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_186_local_3_folded = (paper_hash_186_local_1_scattered + float3(paper_hash_186_local_2_shift, paper_hash_186_local_2_shift, paper_hash_186_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_182_local_8_near_high = mix(fract(((paper_hash_185_local_3_folded.x + paper_hash_185_local_3_folded.y) * paper_hash_185_local_3_folded.z)), fract(((paper_hash_186_local_3_folded.x + paper_hash_186_local_3_folded.y) * paper_hash_186_local_3_folded.z)), paper_noise_182_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_187_local_1_scattered = fract(((paper_noise_182_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_187_local_2_shift = dot(paper_hash_187_local_1_scattered, (paper_hash_187_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_187_local_3_folded = (paper_hash_187_local_1_scattered + float3(paper_hash_187_local_2_shift, paper_hash_187_local_2_shift, paper_hash_187_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_188_local_1_scattered = fract(((paper_noise_182_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_188_local_2_shift = dot(paper_hash_188_local_1_scattered, (paper_hash_188_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_188_local_3_folded = (paper_hash_188_local_1_scattered + float3(paper_hash_188_local_2_shift, paper_hash_188_local_2_shift, paper_hash_188_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_182_local_9_far_low = mix(fract(((paper_hash_187_local_3_folded.x + paper_hash_187_local_3_folded.y) * paper_hash_187_local_3_folded.z)), fract(((paper_hash_188_local_3_folded.x + paper_hash_188_local_3_folded.y) * paper_hash_188_local_3_folded.z)), paper_noise_182_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_189_local_1_scattered = fract(((paper_noise_182_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_189_local_2_shift = dot(paper_hash_189_local_1_scattered, (paper_hash_189_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_189_local_3_folded = (paper_hash_189_local_1_scattered + float3(paper_hash_189_local_2_shift, paper_hash_189_local_2_shift, paper_hash_189_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_190_local_1_scattered = fract(((paper_noise_182_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_190_local_2_shift = dot(paper_hash_190_local_1_scattered, (paper_hash_190_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_190_local_3_folded = (paper_hash_190_local_1_scattered + float3(paper_hash_190_local_2_shift, paper_hash_190_local_2_shift, paper_hash_190_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_182_local_10_far_high = mix(fract(((paper_hash_189_local_3_folded.x + paper_hash_189_local_3_folded.y) * paper_hash_189_local_3_folded.z)), fract(((paper_hash_190_local_3_folded.x + paper_hash_190_local_3_folded.y) * paper_hash_190_local_3_folded.z)), paper_noise_182_local_4_u);
  // This numeric value has no quantity annotation.
  float3 cloth_height_191_local_1_q = ((world * 8.0f) + float3(0.5f, 0.5f, 0.5f));
  // This numeric value has no quantity annotation.
  float3 cloth_height_191_local_2_cell = floor(cloth_height_191_local_1_q);
  // This numeric value has no quantity annotation.
  float3 cloth_height_191_local_3_offset = fract(cloth_height_191_local_1_q);
  // This numeric value has no quantity annotation.
  float cloth_height_191_local_4_x = cloth_height_191_local_3_offset.x;
  // This numeric value has no quantity annotation.
  float cloth_height_191_local_5_y = cloth_height_191_local_3_offset.y;
  // This numeric value has no quantity annotation.
  float cloth_height_191_local_6_z = cloth_height_191_local_3_offset.z;
  // This numeric value has no quantity annotation.
  float cloth_height_191_local_7_over = (2.0f * fract((0.5f * ((cloth_height_191_local_2_cell.x + cloth_height_191_local_2_cell.y) + cloth_height_191_local_2_cell.z))));
  // This numeric value has no quantity annotation.
  float cloth_height_191_local_8_along_x = (((((4.0f * cloth_height_191_local_5_y) * (1.0f - cloth_height_191_local_5_y)) * ((4.0f * cloth_height_191_local_6_z) * (1.0f - cloth_height_191_local_6_z))) * (0.55f + (0.45f * ((4.0f * cloth_height_191_local_4_x) * (1.0f - cloth_height_191_local_4_x))))) * (0.7f + (0.3f * cloth_height_191_local_7_over)));
  // This numeric value has no quantity annotation.
  float cloth_height_191_local_9_along_y = (((((4.0f * cloth_height_191_local_4_x) * (1.0f - cloth_height_191_local_4_x)) * ((4.0f * cloth_height_191_local_6_z) * (1.0f - cloth_height_191_local_6_z))) * (0.55f + (0.45f * ((4.0f * cloth_height_191_local_5_y) * (1.0f - cloth_height_191_local_5_y))))) * (0.7f + (0.3f * (1.0f - cloth_height_191_local_7_over))));
  // This numeric value has no quantity annotation.
  float cloth_height_191_local_10_along_z = (((((4.0f * cloth_height_191_local_4_x) * (1.0f - cloth_height_191_local_4_x)) * ((4.0f * cloth_height_191_local_5_y) * (1.0f - cloth_height_191_local_5_y))) * (0.55f + (0.45f * ((4.0f * cloth_height_191_local_6_z) * (1.0f - cloth_height_191_local_6_z))))) * (0.7f + (0.3f * cloth_height_191_local_7_over)));
  // This numeric value has no quantity annotation.
  float fiber_height_204_local_1_u = (world.x + world.y);
  // This numeric value has no quantity annotation.
  float fiber_height_204_local_2_z = world.z;
  // This numeric value has no quantity annotation.
  float3 paper_noise_206_local_1_lattice = floor((world * float3(19.0f, 19.0f, 3.0f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_206_local_2_offset = fract((world * float3(19.0f, 19.0f, 3.0f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_206_local_3_weight = (paper_noise_206_local_2_offset * (paper_noise_206_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_206_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_206_local_4_u = paper_noise_206_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_206_local_5_v = paper_noise_206_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_206_local_6_w = paper_noise_206_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_207_local_1_scattered = fract((paper_noise_206_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_207_local_2_shift = dot(paper_hash_207_local_1_scattered, (paper_hash_207_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_207_local_3_folded = (paper_hash_207_local_1_scattered + float3(paper_hash_207_local_2_shift, paper_hash_207_local_2_shift, paper_hash_207_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_208_local_1_scattered = fract(((paper_noise_206_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_208_local_2_shift = dot(paper_hash_208_local_1_scattered, (paper_hash_208_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_208_local_3_folded = (paper_hash_208_local_1_scattered + float3(paper_hash_208_local_2_shift, paper_hash_208_local_2_shift, paper_hash_208_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_206_local_7_near_low = mix(fract(((paper_hash_207_local_3_folded.x + paper_hash_207_local_3_folded.y) * paper_hash_207_local_3_folded.z)), fract(((paper_hash_208_local_3_folded.x + paper_hash_208_local_3_folded.y) * paper_hash_208_local_3_folded.z)), paper_noise_206_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_209_local_1_scattered = fract(((paper_noise_206_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_209_local_2_shift = dot(paper_hash_209_local_1_scattered, (paper_hash_209_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_209_local_3_folded = (paper_hash_209_local_1_scattered + float3(paper_hash_209_local_2_shift, paper_hash_209_local_2_shift, paper_hash_209_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_210_local_1_scattered = fract(((paper_noise_206_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_210_local_2_shift = dot(paper_hash_210_local_1_scattered, (paper_hash_210_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_210_local_3_folded = (paper_hash_210_local_1_scattered + float3(paper_hash_210_local_2_shift, paper_hash_210_local_2_shift, paper_hash_210_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_206_local_8_near_high = mix(fract(((paper_hash_209_local_3_folded.x + paper_hash_209_local_3_folded.y) * paper_hash_209_local_3_folded.z)), fract(((paper_hash_210_local_3_folded.x + paper_hash_210_local_3_folded.y) * paper_hash_210_local_3_folded.z)), paper_noise_206_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_211_local_1_scattered = fract(((paper_noise_206_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_211_local_2_shift = dot(paper_hash_211_local_1_scattered, (paper_hash_211_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_211_local_3_folded = (paper_hash_211_local_1_scattered + float3(paper_hash_211_local_2_shift, paper_hash_211_local_2_shift, paper_hash_211_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_212_local_1_scattered = fract(((paper_noise_206_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_212_local_2_shift = dot(paper_hash_212_local_1_scattered, (paper_hash_212_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_212_local_3_folded = (paper_hash_212_local_1_scattered + float3(paper_hash_212_local_2_shift, paper_hash_212_local_2_shift, paper_hash_212_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_206_local_9_far_low = mix(fract(((paper_hash_211_local_3_folded.x + paper_hash_211_local_3_folded.y) * paper_hash_211_local_3_folded.z)), fract(((paper_hash_212_local_3_folded.x + paper_hash_212_local_3_folded.y) * paper_hash_212_local_3_folded.z)), paper_noise_206_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_213_local_1_scattered = fract(((paper_noise_206_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_213_local_2_shift = dot(paper_hash_213_local_1_scattered, (paper_hash_213_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_213_local_3_folded = (paper_hash_213_local_1_scattered + float3(paper_hash_213_local_2_shift, paper_hash_213_local_2_shift, paper_hash_213_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_214_local_1_scattered = fract(((paper_noise_206_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_214_local_2_shift = dot(paper_hash_214_local_1_scattered, (paper_hash_214_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_214_local_3_folded = (paper_hash_214_local_1_scattered + float3(paper_hash_214_local_2_shift, paper_hash_214_local_2_shift, paper_hash_214_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_206_local_10_far_high = mix(fract(((paper_hash_213_local_3_folded.x + paper_hash_213_local_3_folded.y) * paper_hash_213_local_3_folded.z)), fract(((paper_hash_214_local_3_folded.x + paper_hash_214_local_3_folded.y) * paper_hash_214_local_3_folded.z)), paper_noise_206_local_4_u);
  // This value is a difference-valued scalar, unitless and dimensionless.
  float surface_height_60_local_1_raw = ((relief < 0.5f) ? 0.5f : ((relief < 1.5f) ? ((0.6f * mix(mix(paper_noise_62_local_7_near_low, paper_noise_62_local_8_near_high, paper_noise_62_local_5_v), mix(paper_noise_62_local_9_far_low, paper_noise_62_local_10_far_high, paper_noise_62_local_5_v), paper_noise_62_local_6_w)) + (0.4f * mix(mix(paper_noise_71_local_7_near_low, paper_noise_71_local_8_near_high, paper_noise_71_local_5_v), mix(paper_noise_71_local_9_far_low, paper_noise_71_local_10_far_high, paper_noise_71_local_5_v), paper_noise_71_local_6_w))) : ((relief < 2.5f) ? (((0.55f * (1.0f - abs(((mix(mix(paper_noise_81_local_7_near_low, paper_noise_81_local_8_near_high, paper_noise_81_local_5_v), mix(paper_noise_81_local_9_far_low, paper_noise_81_local_10_far_high, paper_noise_81_local_5_v), paper_noise_81_local_6_w) * 2.0f) - 1.0f)))) + (0.3f * mix(mix(paper_noise_90_local_7_near_low, paper_noise_90_local_8_near_high, paper_noise_90_local_5_v), mix(paper_noise_90_local_9_far_low, paper_noise_90_local_10_far_high, paper_noise_90_local_5_v), paper_noise_90_local_6_w))) + (0.15f * mix(mix(paper_noise_99_local_7_near_low, paper_noise_99_local_8_near_high, paper_noise_99_local_5_v), mix(paper_noise_99_local_9_far_low, paper_noise_99_local_10_far_high, paper_noise_99_local_5_v), paper_noise_99_local_6_w))) : ((relief < 3.5f) ? ((0.7f * mix(mix(paper_noise_108_local_7_near_low, paper_noise_108_local_8_near_high, paper_noise_108_local_5_v), mix(paper_noise_108_local_9_far_low, paper_noise_108_local_10_far_high, paper_noise_108_local_5_v), paper_noise_108_local_6_w)) + (0.3f * mix(mix(paper_noise_117_local_7_near_low, paper_noise_117_local_8_near_high, paper_noise_117_local_5_v), mix(paper_noise_117_local_9_far_low, paper_noise_117_local_10_far_high, paper_noise_117_local_5_v), paper_noise_117_local_6_w))) : ((relief < 4.5f) ? (1.0f - abs(((mix(mix(paper_noise_127_local_7_near_low, paper_noise_127_local_8_near_high, paper_noise_127_local_5_v), mix(paper_noise_127_local_9_far_low, paper_noise_127_local_10_far_high, paper_noise_127_local_5_v), paper_noise_127_local_6_w) * 2.0f) - 1.0f))) : ((relief < 5.5f) ? ((0.65f * smoothstep(0.3f, 0.7f, mix(mix(paper_noise_136_local_7_near_low, paper_noise_136_local_8_near_high, paper_noise_136_local_5_v), mix(paper_noise_136_local_9_far_low, paper_noise_136_local_10_far_high, paper_noise_136_local_5_v), paper_noise_136_local_6_w))) + (0.35f * mix(mix(paper_noise_145_local_7_near_low, paper_noise_145_local_8_near_high, paper_noise_145_local_5_v), mix(paper_noise_145_local_9_far_low, paper_noise_145_local_10_far_high, paper_noise_145_local_5_v), paper_noise_145_local_6_w))) : ((relief < 6.5f) ? ((smoothstep(0.0f, 0.1f, plank_height_154_local_1_u) * (1.0f - smoothstep(0.9f, 1.0f, plank_height_154_local_1_u))) * (0.75f + (0.25f * mix(mix(paper_noise_155_local_7_near_low, paper_noise_155_local_8_near_high, paper_noise_155_local_5_v), mix(paper_noise_155_local_9_far_low, paper_noise_155_local_10_far_high, paper_noise_155_local_5_v), paper_noise_155_local_6_w)))) : ((relief < 7.5f) ? ((0.7f * mix(mix(paper_noise_164_local_7_near_low, paper_noise_164_local_8_near_high, paper_noise_164_local_5_v), mix(paper_noise_164_local_9_far_low, paper_noise_164_local_10_far_high, paper_noise_164_local_5_v), paper_noise_164_local_6_w)) + (0.3f * mix(mix(paper_noise_173_local_7_near_low, paper_noise_173_local_8_near_high, paper_noise_173_local_5_v), mix(paper_noise_173_local_9_far_low, paper_noise_173_local_10_far_high, paper_noise_173_local_5_v), paper_noise_173_local_6_w))) : ((relief < 8.5f) ? mix(mix(paper_noise_182_local_7_near_low, paper_noise_182_local_8_near_high, paper_noise_182_local_5_v), mix(paper_noise_182_local_9_far_low, paper_noise_182_local_10_far_high, paper_noise_182_local_5_v), paper_noise_182_local_6_w) : ((relief < 9.5f) ? (0.1f + (0.8f * max(cloth_height_191_local_8_along_x, max(cloth_height_191_local_9_along_y, cloth_height_191_local_10_along_z)))) : ((relief < 10.5f) ? ((0.7f * ((4.0f * fract(((fiber_height_204_local_1_u * 17.0f) + (fiber_height_204_local_2_z * 1.3f)))) * (1.0f - fract(((fiber_height_204_local_1_u * 17.0f) + (fiber_height_204_local_2_z * 1.3f)))))) + (0.3f * mix(mix(paper_noise_206_local_7_near_low, paper_noise_206_local_8_near_high, paper_noise_206_local_5_v), mix(paper_noise_206_local_9_far_low, paper_noise_206_local_10_far_high, paper_noise_206_local_5_v), paper_noise_206_local_6_w))) : ((relief < 11.5f) ? ((0.8f * ((4.0f * fract((fiber_height_204_local_1_u * 5.0f))) * (1.0f - fract((fiber_height_204_local_1_u * 5.0f))))) + (0.2f * step(0.85f, fract(((fiber_height_204_local_1_u * 13.0f) + (fiber_height_204_local_2_z * 7.0f)))))) : (0.45f + (0.1f * ((4.0f * fract((fiber_height_204_local_2_z * 24.0f))) * (1.0f - fract((fiber_height_204_local_2_z * 24.0f))))))))))))))))));
  // This numeric value has no quantity annotation.
  float surface_height_60_local_2_relief = ((relief > 8.5f) ? ((relief < 10.5f) ? mix(0.5f, surface_height_60_local_1_raw, nap_fade) : surface_height_60_local_1_raw) : surface_height_60_local_1_raw);
  // This numeric value has no quantity annotation.
  float surface_height_60_local_3_cut = ((laid.x * ((stage_in.material_pattern.x > 4.5f) ? 1.0f : laid.z)) * (0.75f + (0.25f * surface_height_60_local_2_relief)));
  // This numeric value has no quantity annotation.
  float height = ((stage_in.material_pattern.x < 0.5f) ? surface_height_60_local_2_relief : mix(surface_height_60_local_2_relief, surface_height_60_local_3_cut, fade));
  // This numeric value has no quantity annotation.
  float3 relief_normal_217_local_1_helper = ((abs(normal.z) < 0.9f) ? float3(0.0f, 0.0f, 1.0f) : float3(1.0f, 0.0f, 0.0f));
  // This numeric value has no quantity annotation.
  float3 relief_normal_217_local_2_tangent = normalize(((normal.yzx * relief_normal_217_local_1_helper.zxy) - (normal.zxy * relief_normal_217_local_1_helper.yzx)));
  // This numeric value has no quantity annotation.
  float3 relief_normal_217_local_3_bitangent = ((normal.yzx * relief_normal_217_local_2_tangent.zxy) - (normal.zxy * relief_normal_217_local_2_tangent.yzx));
  // This value is a difference-valued scalar, unitless and dimensionless.
  float relief_normal_217_local_4_step = 0.015f;
  // This numeric value has no quantity annotation.
  float3 relief_normal_217_local_5_along_point = (world + (relief_normal_217_local_2_tangent * relief_normal_217_local_4_step));
  // This numeric value has no quantity annotation.
  float3 relief_normal_217_local_6_across_point = (world + (relief_normal_217_local_3_bitangent * relief_normal_217_local_4_step));
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_1_shape = stage_in.material_pattern.x;
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_2_courses = max(1.0f, stage_in.material_pattern.y);
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_3_aspect = max(0.5f, stage_in.material_pattern.z);
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_4_mortar = (0.5f * stage_in.material_pattern.w);
  // This numeric value has no quantity annotation.
  float3 laid_pattern_220_local_5_an = abs(normal);
  // This numeric value has no quantity annotation.
  bool laid_pattern_220_local_6_top = (laid_pattern_220_local_5_an.z > 0.7f);
  // This numeric value has no quantity annotation.
  bool laid_pattern_220_local_7_x_facing = (laid_pattern_220_local_5_an.x > laid_pattern_220_local_5_an.y);
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_8_u = (laid_pattern_220_local_6_top ? relief_normal_217_local_5_along_point.x : (laid_pattern_220_local_7_x_facing ? relief_normal_217_local_5_along_point.y : relief_normal_217_local_5_along_point.x));
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_9_v = (laid_pattern_220_local_6_top ? relief_normal_217_local_5_along_point.y : relief_normal_217_local_5_along_point.z);
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_10_w = (laid_pattern_220_local_6_top ? relief_normal_217_local_5_along_point.z : (laid_pattern_220_local_7_x_facing ? relief_normal_217_local_5_along_point.x : relief_normal_217_local_5_along_point.y));
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_11_rowf = (laid_pattern_220_local_9_v * laid_pattern_220_local_2_courses);
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_12_row = floor(laid_pattern_220_local_11_rowf);
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_13_fv = fract(laid_pattern_220_local_11_rowf);
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_14_parity = (2.0f * fract((laid_pattern_220_local_12_row * 0.5f)));
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_15_shift = ((laid_pattern_220_local_1_shape < 1.5f) ? (0.5f * laid_pattern_220_local_14_parity) : ((laid_pattern_220_local_1_shape > 2.5f) ? ((laid_pattern_220_local_1_shape < 3.5f) ? (0.5f * laid_pattern_220_local_14_parity) : 0.0f) : 0.0f));
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_16_uf = (((laid_pattern_220_local_8_u * laid_pattern_220_local_2_courses) / laid_pattern_220_local_3_aspect) + laid_pattern_220_local_15_shift);
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_17_col = floor(laid_pattern_220_local_16_uf);
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_18_fu = fract(laid_pattern_220_local_16_uf);
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_19_du = (laid_pattern_220_local_3_aspect * min(laid_pattern_220_local_18_fu, (1.0f - laid_pattern_220_local_18_fu)));
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_20_dv = min(laid_pattern_220_local_13_fv, (1.0f - laid_pattern_220_local_13_fv));
  // This value is a difference-valued scalar, unitless and dimensionless.
  float laid_pattern_220_local_21_bevel = 0.08f;
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_22_joint = smoothstep(laid_pattern_220_local_4_mortar, (laid_pattern_220_local_4_mortar + laid_pattern_220_local_21_bevel), laid_pattern_220_local_19_du);
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_23_bed = smoothstep(laid_pattern_220_local_4_mortar, (laid_pattern_220_local_4_mortar + laid_pattern_220_local_21_bevel), laid_pattern_220_local_20_dv);
  // This numeric value has no quantity annotation.
  bool laid_pattern_220_local_24_shingle = (laid_pattern_220_local_1_shape > 2.5f);
  // This numeric value has no quantity annotation.
  bool laid_pattern_220_local_25_checker = (laid_pattern_220_local_1_shape > 3.5f);
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_26_mask = (laid_pattern_220_local_25_checker ? (laid_pattern_220_local_22_joint * laid_pattern_220_local_23_bed) : (laid_pattern_220_local_24_shingle ? (laid_pattern_220_local_22_joint * smoothstep(0.0f, (laid_pattern_220_local_4_mortar + laid_pattern_220_local_21_bevel), laid_pattern_220_local_13_fv)) : (laid_pattern_220_local_22_joint * laid_pattern_220_local_23_bed)));
  // This value is a difference-valued scalar, unitless and dimensionless.
  float laid_pattern_220_local_27_ramp = (laid_pattern_220_local_25_checker ? 1.0f : (laid_pattern_220_local_24_shingle ? (1.0f - (0.5f * laid_pattern_220_local_13_fv)) : 1.0f));
  // This numeric value has no quantity annotation.
  float3 paper_hash_221_local_1_scattered = fract((float3(laid_pattern_220_local_17_col, laid_pattern_220_local_12_row, floor((laid_pattern_220_local_10_w + 0.5f))) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_221_local_2_shift = dot(paper_hash_221_local_1_scattered, (paper_hash_221_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_221_local_3_folded = (paper_hash_221_local_1_scattered + float3(paper_hash_221_local_2_shift, paper_hash_221_local_2_shift, paper_hash_221_local_2_shift));
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_28_hash = fract(((paper_hash_221_local_3_folded.x + paper_hash_221_local_3_folded.y) * paper_hash_221_local_3_folded.z));
  // This numeric value has no quantity annotation.
  float laid_pattern_220_local_29_checked = (2.0f * fract(((laid_pattern_220_local_12_row + laid_pattern_220_local_17_col) * 0.5f)));
  // This numeric value has no quantity annotation.
  float face_laid_pattern_222_local_1_shape = stage_in.material_pattern.x;
  // This numeric value has no quantity annotation.
  float3 face_coordinates_223_local_1_an = abs(normal);
  // This numeric value has no quantity annotation.
  bool face_coordinates_223_local_2_top = (face_coordinates_223_local_1_an.z > 0.7f);
  // This numeric value has no quantity annotation.
  bool face_coordinates_223_local_3_x_facing = (face_coordinates_223_local_1_an.x > face_coordinates_223_local_1_an.y);
  // This numeric value has no quantity annotation.
  float3 face_laid_pattern_222_local_2_face = float3((face_coordinates_223_local_2_top ? relief_normal_217_local_5_along_point.x : (face_coordinates_223_local_3_x_facing ? relief_normal_217_local_5_along_point.y : relief_normal_217_local_5_along_point.x)), (face_coordinates_223_local_2_top ? relief_normal_217_local_5_along_point.y : relief_normal_217_local_5_along_point.z), (face_coordinates_223_local_2_top ? relief_normal_217_local_5_along_point.z : (face_coordinates_223_local_3_x_facing ? relief_normal_217_local_5_along_point.x : relief_normal_217_local_5_along_point.y)));
  // This numeric value has no quantity annotation.
  bool face_laid_pattern_222_local_3_top = (abs(normal.z) > 0.7f);
  // This numeric value has no quantity annotation.
  float mineral_pattern_224_local_1_phase = (dot(relief_normal_217_local_5_along_point, float3(7.0f, 4.0f, 5.0f)) + (1.8f * sin(dot(relief_normal_217_local_5_along_point, float3(1.3f, 2.1f, 0.7f)))));
  // This numeric value has no quantity annotation.
  float3 paper_hash_225_local_1_scattered = fract((floor((relief_normal_217_local_5_along_point * (4.75f * stage_in.material_pattern.y))) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_225_local_2_shift = dot(paper_hash_225_local_1_scattered, (paper_hash_225_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_225_local_3_folded = (paper_hash_225_local_1_scattered + float3(paper_hash_225_local_2_shift, paper_hash_225_local_2_shift, paper_hash_225_local_2_shift));
  // This numeric value has no quantity annotation.
  float mineral_pattern_224_local_2_ink = ((stage_in.material_pattern.x < 14.5f) ? smoothstep(0.88f, 0.99f, sin(mineral_pattern_224_local_1_phase)) : step(0.85f, fract(((paper_hash_225_local_3_folded.x + paper_hash_225_local_3_folded.y) * paper_hash_225_local_3_folded.z))));
  // This numeric value has no quantity annotation.
  float2 motif_face_226_local_1_uv = fract(face_laid_pattern_222_local_2_face.xy);
  // This numeric value has no quantity annotation.
  float2 motif_face_226_local_2_q = (motif_face_226_local_1_uv - float2(0.5f, 0.5f));
  // This numeric value has no quantity annotation.
  float motif_face_226_local_3_x = motif_face_226_local_2_q.x;
  // This numeric value has no quantity annotation.
  float motif_face_226_local_4_y = motif_face_226_local_2_q.y;
  // This numeric value has no quantity annotation.
  float motif_face_226_local_5_edge = max(abs(motif_face_226_local_3_x), abs(motif_face_226_local_4_y));
  // This numeric value has no quantity annotation.
  float motif_face_226_local_6_frame = smoothstep(0.34f, 0.4f, motif_face_226_local_5_edge);
  // This numeric value has no quantity annotation.
  float motif_face_226_local_7_r2 = dot(motif_face_226_local_2_q, motif_face_226_local_2_q);
  // This numeric value has no quantity annotation.
  float let_227_1_row = floor((motif_face_226_local_1_uv.y * 12.0f));
  // This numeric value has no quantity annotation.
  float let_227_2_ink = ((((1.0f - motif_face_226_local_6_frame) * (face_laid_pattern_222_local_3_top ? 0.0f : 1.0f)) * step(0.35f, fract((motif_face_226_local_1_uv.y * 12.0f)))) * step(0.3f, fract(((motif_face_226_local_1_uv.x * 9.0f) + (let_227_1_row * 0.37f)))));
  // This numeric value has no quantity annotation.
  float let_228_1_hub = (1.0f - smoothstep(0.012f, 0.025f, motif_face_226_local_7_r2));
  // This numeric value has no quantity annotation.
  float let_228_2_rim = smoothstep(0.14f, 0.18f, motif_face_226_local_7_r2);
  // This numeric value has no quantity annotation.
  float let_228_3_spoke = (1.0f - smoothstep(0.035f, 0.065f, min(abs(motif_face_226_local_3_x), abs(motif_face_226_local_4_y))));
  // This numeric value has no quantity annotation.
  float let_228_4_metal = ((1.0f - smoothstep(0.18f, 0.2f, motif_face_226_local_7_r2)) * max(let_228_1_hub, max(let_228_2_rim, let_228_3_spoke)));
  // This numeric value has no quantity annotation.
  float let_229_1_diamond = (abs(motif_face_226_local_3_x) + abs(motif_face_226_local_4_y));
  // This numeric value has no quantity annotation.
  float let_229_2_ink = (smoothstep(0.18f, 0.23f, let_229_1_diamond) * (1.0f - smoothstep(0.34f, 0.39f, let_229_1_diamond)));
  // This numeric value has no quantity annotation.
  float let_230_1_band = (1.0f - smoothstep(0.035f, 0.065f, abs((abs(motif_face_226_local_3_x) - 0.25f))));
  // This numeric value has no quantity annotation.
  float board_face_231_local_1_rowf = (face_laid_pattern_222_local_2_face.y * 4.0f);
  // This numeric value has no quantity annotation.
  float board_face_231_local_2_fv = fract(board_face_231_local_1_rowf);
  // This numeric value has no quantity annotation.
  float board_face_231_local_3_groove = (1.0f - smoothstep(0.03f, (0.03f + 0.03f), min(board_face_231_local_2_fv, (1.0f - board_face_231_local_2_fv))));
  // This numeric value has no quantity annotation.
  float3 paper_hash_233_local_1_scattered = fract((float3(floor(board_face_231_local_1_rowf), floor((face_laid_pattern_222_local_2_face.z + 0.5f)), 3.0f) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_233_local_2_shift = dot(paper_hash_233_local_1_scattered, (paper_hash_233_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_233_local_3_folded = (paper_hash_233_local_1_scattered + float3(paper_hash_233_local_2_shift, paper_hash_233_local_2_shift, paper_hash_233_local_2_shift));
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_1_rows = max(1.0f, stage_in.material_pattern.y);
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_2_books = (shelf_face_234_local_1_rows * max(0.5f, stage_in.material_pattern.z));
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_3_board = stage_in.material_pattern.w;
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_4_u = face_laid_pattern_222_local_2_face.x;
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_5_depth = floor((face_laid_pattern_222_local_2_face.z + 0.5f));
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_6_rowf = (face_laid_pattern_222_local_2_face.y * shelf_face_234_local_1_rows);
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_7_row = floor(shelf_face_234_local_6_rowf);
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_8_fv = fract(shelf_face_234_local_6_rowf);
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_9_cell_u = fract(shelf_face_234_local_4_u);
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_10_upright = (1.0f - smoothstep(0.03f, (0.03f + 0.015f), min(shelf_face_234_local_9_cell_u, (1.0f - shelf_face_234_local_9_cell_u))));
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_11_shelf = max((1.0f - smoothstep(shelf_face_234_local_3_board, (shelf_face_234_local_3_board + 0.04f), shelf_face_234_local_8_fv)), (1.0f - smoothstep((0.4f * shelf_face_234_local_3_board), ((0.4f * shelf_face_234_local_3_board) + 0.04f), (1.0f - shelf_face_234_local_8_fv))));
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_12_frame = max(shelf_face_234_local_10_upright, shelf_face_234_local_11_shelf);
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_13_slotf = (shelf_face_234_local_4_u * shelf_face_234_local_2_books);
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_14_slot = floor(shelf_face_234_local_13_slotf);
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_15_fs = fract(shelf_face_234_local_13_slotf);
  // This numeric value has no quantity annotation.
  float3 paper_hash_238_local_1_scattered = fract((float3(shelf_face_234_local_14_slot, shelf_face_234_local_7_row, (shelf_face_234_local_5_depth + 17.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_238_local_2_shift = dot(paper_hash_238_local_1_scattered, (paper_hash_238_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_238_local_3_folded = (paper_hash_238_local_1_scattered + float3(paper_hash_238_local_2_shift, paper_hash_238_local_2_shift, paper_hash_238_local_2_shift));
  // This value is a difference-valued scalar, unitless and dimensionless.
  float shelf_face_234_local_16_pair = ((fract(((paper_hash_238_local_3_folded.x + paper_hash_238_local_3_folded.y) * paper_hash_238_local_3_folded.z)) < 0.35f) ? 2.0f : 1.0f);
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_17_sub = floor((shelf_face_234_local_15_fs * shelf_face_234_local_16_pair));
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_18_fb = fract((shelf_face_234_local_15_fs * shelf_face_234_local_16_pair));
  // This numeric value has no quantity annotation.
  float3 paper_hash_239_local_1_scattered = fract((float3(((shelf_face_234_local_14_slot * 2.0f) + shelf_face_234_local_17_sub), shelf_face_234_local_7_row, shelf_face_234_local_5_depth) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_239_local_2_shift = dot(paper_hash_239_local_1_scattered, (paper_hash_239_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_239_local_3_folded = (paper_hash_239_local_1_scattered + float3(paper_hash_239_local_2_shift, paper_hash_239_local_2_shift, paper_hash_239_local_2_shift));
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_19_id = fract(((paper_hash_239_local_3_folded.x + paper_hash_239_local_3_folded.y) * paper_hash_239_local_3_folded.z));
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_20_clear = ((shelf_face_234_local_8_fv - shelf_face_234_local_3_board) / (1.0f - (1.4f * shelf_face_234_local_3_board)));
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_21_crown = (0.55f + (0.4f * fract((shelf_face_234_local_19_id * 13.7f))));
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_22_above = smoothstep((shelf_face_234_local_21_crown - 0.02f), (shelf_face_234_local_21_crown + 0.02f), shelf_face_234_local_20_clear);
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_23_seam = (1.0f - smoothstep(0.004f, (0.004f + 0.004f), (min(shelf_face_234_local_18_fb, (1.0f - shelf_face_234_local_18_fb)) / (shelf_face_234_local_2_books * shelf_face_234_local_16_pair))));
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_24_recess = ((1.0f - shelf_face_234_local_12_frame) * max(shelf_face_234_local_22_above, shelf_face_234_local_23_seam));
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_25_across = ((2.0f * shelf_face_234_local_18_fb) - 1.0f);
  // This numeric value has no quantity annotation.
  float shelf_face_234_local_26_spine = (0.55f + (0.2f * (1.0f - (shelf_face_234_local_25_across * shelf_face_234_local_25_across))));
  // This value is a difference-valued scalar, unitless and dimensionless.
  float shelf_face_234_local_27_gilt = ((abs((shelf_face_234_local_20_clear - (0.82f * shelf_face_234_local_21_crown))) < 0.025f) ? ((fract((shelf_face_234_local_19_id * 5.3f)) > 0.4f) ? 1.0f : 0.0f) : 0.0f);
  // This numeric value has no quantity annotation.
  float window_face_241_local_1_panes = max(1.0f, stage_in.material_pattern.y);
  // This numeric value has no quantity annotation.
  float window_face_241_local_2_width = stage_in.material_pattern.w;
  // This numeric value has no quantity annotation.
  float cell_edge_distance_242_local_1_fu = fract(face_laid_pattern_222_local_2_face.x);
  // This numeric value has no quantity annotation.
  float cell_edge_distance_242_local_2_fv = fract(face_laid_pattern_222_local_2_face.y);
  // This numeric value has no quantity annotation.
  float window_face_241_local_3_edge = min(min(cell_edge_distance_242_local_1_fu, (1.0f - cell_edge_distance_242_local_1_fu)), min(cell_edge_distance_242_local_2_fv, (1.0f - cell_edge_distance_242_local_2_fv)));
  // This numeric value has no quantity annotation.
  float window_face_241_local_4_frame = (1.0f - smoothstep(window_face_241_local_2_width, (window_face_241_local_2_width + 0.012f), window_face_241_local_3_edge));
  // This numeric value has no quantity annotation.
  float window_face_241_local_5_groove = (window_face_241_local_4_frame * (1.0f - smoothstep(0.01f, (0.01f + 0.008f), abs((window_face_241_local_3_edge - (0.5f * window_face_241_local_2_width))))));
  // This numeric value has no quantity annotation.
  float window_face_241_local_6_pu = fract((face_laid_pattern_222_local_2_face.x * window_face_241_local_1_panes));
  // This numeric value has no quantity annotation.
  float window_face_241_local_7_pv = fract((face_laid_pattern_222_local_2_face.y * window_face_241_local_1_panes));
  // This numeric value has no quantity annotation.
  float window_face_241_local_8_mullion = (1.0f - smoothstep(0.02f, (0.02f + 0.01f), (min(min(window_face_241_local_6_pu, (1.0f - window_face_241_local_6_pu)), min(window_face_241_local_7_pv, (1.0f - window_face_241_local_7_pv))) / window_face_241_local_1_panes)));
  // This numeric value has no quantity annotation.
  float window_face_241_local_9_bar = max(window_face_241_local_4_frame, window_face_241_local_8_mullion);
  // This numeric value has no quantity annotation.
  float3 paper_hash_246_local_1_scattered = fract((float3(floor((face_laid_pattern_222_local_2_face.x * window_face_241_local_1_panes)), floor((face_laid_pattern_222_local_2_face.y * window_face_241_local_1_panes)), (floor((face_laid_pattern_222_local_2_face.z + 0.5f)) + 5.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_246_local_2_shift = dot(paper_hash_246_local_1_scattered, (paper_hash_246_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_246_local_3_folded = (paper_hash_246_local_1_scattered + float3(paper_hash_246_local_2_shift, paper_hash_246_local_2_shift, paper_hash_246_local_2_shift));
  // This numeric value has no quantity annotation.
  float window_face_241_local_10_lamp = fract(((paper_hash_246_local_3_folded.x + paper_hash_246_local_3_folded.y) * paper_hash_246_local_3_folded.z));
  // This numeric value has no quantity annotation.
  float window_face_241_local_11_light = clamp(((0.3f + (0.5f * (1.0f - window_face_241_local_7_pv))) + (0.4f * (window_face_241_local_10_lamp - 0.5f))), 0.0f, 1.0f);
  // This numeric value has no quantity annotation.
  float timbered_face_247_local_1_width = (0.5f * stage_in.material_pattern.w);
  // This numeric value has no quantity annotation.
  float timbered_face_247_local_2_fu = fract(face_laid_pattern_222_local_2_face.x);
  // This numeric value has no quantity annotation.
  float timbered_face_247_local_3_fv = fract(face_laid_pattern_222_local_2_face.y);
  // This numeric value has no quantity annotation.
  float cell_edge_distance_248_local_1_fu = fract(face_laid_pattern_222_local_2_face.x);
  // This numeric value has no quantity annotation.
  float cell_edge_distance_248_local_2_fv = fract(face_laid_pattern_222_local_2_face.y);
  // This numeric value has no quantity annotation.
  float timbered_face_247_local_4_post = (1.0f - smoothstep(timbered_face_247_local_1_width, (timbered_face_247_local_1_width + 0.015f), min(min(cell_edge_distance_248_local_1_fu, (1.0f - cell_edge_distance_248_local_1_fu)), min(cell_edge_distance_248_local_2_fv, (1.0f - cell_edge_distance_248_local_2_fv)))));
  // This numeric value has no quantity annotation.
  float timbered_face_247_local_5_parity = fract((0.5f * (floor(face_laid_pattern_222_local_2_face.x) + floor(face_laid_pattern_222_local_2_face.y))));
  // This numeric value has no quantity annotation.
  float timbered_face_247_local_6_diagonal = ((timbered_face_247_local_5_parity > 0.25f) ? abs((timbered_face_247_local_2_fu - timbered_face_247_local_3_fv)) : abs(((timbered_face_247_local_2_fu + timbered_face_247_local_3_fv) - 1.0f)));
  // This numeric value has no quantity annotation.
  float timbered_face_247_local_7_brace = (1.0f - smoothstep(timbered_face_247_local_1_width, (timbered_face_247_local_1_width + 0.015f), (0.7071f * timbered_face_247_local_6_diagonal)));
  // This numeric value has no quantity annotation.
  float timbered_face_247_local_8_frame = max(timbered_face_247_local_4_post, timbered_face_247_local_7_brace);
  // This numeric value has no quantity annotation.
  float3 paper_noise_251_local_1_lattice = floor((face_laid_pattern_222_local_2_face * 7.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_251_local_2_offset = fract((face_laid_pattern_222_local_2_face * 7.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_251_local_3_weight = (paper_noise_251_local_2_offset * (paper_noise_251_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_251_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_251_local_4_u = paper_noise_251_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_251_local_5_v = paper_noise_251_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_251_local_6_w = paper_noise_251_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_252_local_1_scattered = fract((paper_noise_251_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_252_local_2_shift = dot(paper_hash_252_local_1_scattered, (paper_hash_252_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_252_local_3_folded = (paper_hash_252_local_1_scattered + float3(paper_hash_252_local_2_shift, paper_hash_252_local_2_shift, paper_hash_252_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_253_local_1_scattered = fract(((paper_noise_251_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_253_local_2_shift = dot(paper_hash_253_local_1_scattered, (paper_hash_253_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_253_local_3_folded = (paper_hash_253_local_1_scattered + float3(paper_hash_253_local_2_shift, paper_hash_253_local_2_shift, paper_hash_253_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_251_local_7_near_low = mix(fract(((paper_hash_252_local_3_folded.x + paper_hash_252_local_3_folded.y) * paper_hash_252_local_3_folded.z)), fract(((paper_hash_253_local_3_folded.x + paper_hash_253_local_3_folded.y) * paper_hash_253_local_3_folded.z)), paper_noise_251_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_254_local_1_scattered = fract(((paper_noise_251_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_254_local_2_shift = dot(paper_hash_254_local_1_scattered, (paper_hash_254_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_254_local_3_folded = (paper_hash_254_local_1_scattered + float3(paper_hash_254_local_2_shift, paper_hash_254_local_2_shift, paper_hash_254_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_255_local_1_scattered = fract(((paper_noise_251_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_255_local_2_shift = dot(paper_hash_255_local_1_scattered, (paper_hash_255_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_255_local_3_folded = (paper_hash_255_local_1_scattered + float3(paper_hash_255_local_2_shift, paper_hash_255_local_2_shift, paper_hash_255_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_251_local_8_near_high = mix(fract(((paper_hash_254_local_3_folded.x + paper_hash_254_local_3_folded.y) * paper_hash_254_local_3_folded.z)), fract(((paper_hash_255_local_3_folded.x + paper_hash_255_local_3_folded.y) * paper_hash_255_local_3_folded.z)), paper_noise_251_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_256_local_1_scattered = fract(((paper_noise_251_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_256_local_2_shift = dot(paper_hash_256_local_1_scattered, (paper_hash_256_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_256_local_3_folded = (paper_hash_256_local_1_scattered + float3(paper_hash_256_local_2_shift, paper_hash_256_local_2_shift, paper_hash_256_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_257_local_1_scattered = fract(((paper_noise_251_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_257_local_2_shift = dot(paper_hash_257_local_1_scattered, (paper_hash_257_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_257_local_3_folded = (paper_hash_257_local_1_scattered + float3(paper_hash_257_local_2_shift, paper_hash_257_local_2_shift, paper_hash_257_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_251_local_9_far_low = mix(fract(((paper_hash_256_local_3_folded.x + paper_hash_256_local_3_folded.y) * paper_hash_256_local_3_folded.z)), fract(((paper_hash_257_local_3_folded.x + paper_hash_257_local_3_folded.y) * paper_hash_257_local_3_folded.z)), paper_noise_251_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_258_local_1_scattered = fract(((paper_noise_251_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_258_local_2_shift = dot(paper_hash_258_local_1_scattered, (paper_hash_258_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_258_local_3_folded = (paper_hash_258_local_1_scattered + float3(paper_hash_258_local_2_shift, paper_hash_258_local_2_shift, paper_hash_258_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_259_local_1_scattered = fract(((paper_noise_251_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_259_local_2_shift = dot(paper_hash_259_local_1_scattered, (paper_hash_259_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_259_local_3_folded = (paper_hash_259_local_1_scattered + float3(paper_hash_259_local_2_shift, paper_hash_259_local_2_shift, paper_hash_259_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_251_local_10_far_high = mix(fract(((paper_hash_258_local_3_folded.x + paper_hash_258_local_3_folded.y) * paper_hash_258_local_3_folded.z)), fract(((paper_hash_259_local_3_folded.x + paper_hash_259_local_3_folded.y) * paper_hash_259_local_3_folded.z)), paper_noise_251_local_4_u);
  // This numeric value has no quantity annotation.
  float panel_face_260_local_1_width = stage_in.material_pattern.w;
  // This numeric value has no quantity annotation.
  float cell_edge_distance_261_local_1_fu = fract(face_laid_pattern_222_local_2_face.x);
  // This numeric value has no quantity annotation.
  float cell_edge_distance_261_local_2_fv = fract(face_laid_pattern_222_local_2_face.y);
  // This numeric value has no quantity annotation.
  float panel_face_260_local_2_edge = min(min(cell_edge_distance_261_local_1_fu, (1.0f - cell_edge_distance_261_local_1_fu)), min(cell_edge_distance_261_local_2_fv, (1.0f - cell_edge_distance_261_local_2_fv)));
  // This numeric value has no quantity annotation.
  float panel_face_260_local_3_frame = (1.0f - smoothstep(panel_face_260_local_1_width, (panel_face_260_local_1_width + 0.03f), panel_face_260_local_2_edge));
  // This numeric value has no quantity annotation.
  float panel_face_260_local_4_bevel = smoothstep(panel_face_260_local_1_width, (panel_face_260_local_1_width + 0.12f), panel_face_260_local_2_edge);
  // This numeric value has no quantity annotation.
  float3 paper_hash_263_local_1_scattered = fract((float3(floor(face_laid_pattern_222_local_2_face.x), floor(face_laid_pattern_222_local_2_face.y), floor((face_laid_pattern_222_local_2_face.z + 0.5f))) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_263_local_2_shift = dot(paper_hash_263_local_1_scattered, (paper_hash_263_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_263_local_3_folded = (paper_hash_263_local_1_scattered + float3(paper_hash_263_local_2_shift, paper_hash_263_local_2_shift, paper_hash_263_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_noise_266_local_1_lattice = floor((relief_normal_217_local_5_along_point * 4.7f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_266_local_2_offset = fract((relief_normal_217_local_5_along_point * 4.7f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_266_local_3_weight = (paper_noise_266_local_2_offset * (paper_noise_266_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_266_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_266_local_4_u = paper_noise_266_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_266_local_5_v = paper_noise_266_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_266_local_6_w = paper_noise_266_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_267_local_1_scattered = fract((paper_noise_266_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_267_local_2_shift = dot(paper_hash_267_local_1_scattered, (paper_hash_267_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_267_local_3_folded = (paper_hash_267_local_1_scattered + float3(paper_hash_267_local_2_shift, paper_hash_267_local_2_shift, paper_hash_267_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_268_local_1_scattered = fract(((paper_noise_266_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_268_local_2_shift = dot(paper_hash_268_local_1_scattered, (paper_hash_268_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_268_local_3_folded = (paper_hash_268_local_1_scattered + float3(paper_hash_268_local_2_shift, paper_hash_268_local_2_shift, paper_hash_268_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_266_local_7_near_low = mix(fract(((paper_hash_267_local_3_folded.x + paper_hash_267_local_3_folded.y) * paper_hash_267_local_3_folded.z)), fract(((paper_hash_268_local_3_folded.x + paper_hash_268_local_3_folded.y) * paper_hash_268_local_3_folded.z)), paper_noise_266_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_269_local_1_scattered = fract(((paper_noise_266_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_269_local_2_shift = dot(paper_hash_269_local_1_scattered, (paper_hash_269_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_269_local_3_folded = (paper_hash_269_local_1_scattered + float3(paper_hash_269_local_2_shift, paper_hash_269_local_2_shift, paper_hash_269_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_270_local_1_scattered = fract(((paper_noise_266_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_270_local_2_shift = dot(paper_hash_270_local_1_scattered, (paper_hash_270_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_270_local_3_folded = (paper_hash_270_local_1_scattered + float3(paper_hash_270_local_2_shift, paper_hash_270_local_2_shift, paper_hash_270_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_266_local_8_near_high = mix(fract(((paper_hash_269_local_3_folded.x + paper_hash_269_local_3_folded.y) * paper_hash_269_local_3_folded.z)), fract(((paper_hash_270_local_3_folded.x + paper_hash_270_local_3_folded.y) * paper_hash_270_local_3_folded.z)), paper_noise_266_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_271_local_1_scattered = fract(((paper_noise_266_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_271_local_2_shift = dot(paper_hash_271_local_1_scattered, (paper_hash_271_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_271_local_3_folded = (paper_hash_271_local_1_scattered + float3(paper_hash_271_local_2_shift, paper_hash_271_local_2_shift, paper_hash_271_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_272_local_1_scattered = fract(((paper_noise_266_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_272_local_2_shift = dot(paper_hash_272_local_1_scattered, (paper_hash_272_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_272_local_3_folded = (paper_hash_272_local_1_scattered + float3(paper_hash_272_local_2_shift, paper_hash_272_local_2_shift, paper_hash_272_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_266_local_9_far_low = mix(fract(((paper_hash_271_local_3_folded.x + paper_hash_271_local_3_folded.y) * paper_hash_271_local_3_folded.z)), fract(((paper_hash_272_local_3_folded.x + paper_hash_272_local_3_folded.y) * paper_hash_272_local_3_folded.z)), paper_noise_266_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_273_local_1_scattered = fract(((paper_noise_266_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_273_local_2_shift = dot(paper_hash_273_local_1_scattered, (paper_hash_273_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_273_local_3_folded = (paper_hash_273_local_1_scattered + float3(paper_hash_273_local_2_shift, paper_hash_273_local_2_shift, paper_hash_273_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_274_local_1_scattered = fract(((paper_noise_266_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_274_local_2_shift = dot(paper_hash_274_local_1_scattered, (paper_hash_274_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_274_local_3_folded = (paper_hash_274_local_1_scattered + float3(paper_hash_274_local_2_shift, paper_hash_274_local_2_shift, paper_hash_274_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_266_local_10_far_high = mix(fract(((paper_hash_273_local_3_folded.x + paper_hash_273_local_3_folded.y) * paper_hash_273_local_3_folded.z)), fract(((paper_hash_274_local_3_folded.x + paper_hash_274_local_3_folded.y) * paper_hash_274_local_3_folded.z)), paper_noise_266_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_275_local_1_lattice = floor((relief_normal_217_local_5_along_point * 13.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_275_local_2_offset = fract((relief_normal_217_local_5_along_point * 13.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_275_local_3_weight = (paper_noise_275_local_2_offset * (paper_noise_275_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_275_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_275_local_4_u = paper_noise_275_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_275_local_5_v = paper_noise_275_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_275_local_6_w = paper_noise_275_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_276_local_1_scattered = fract((paper_noise_275_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_276_local_2_shift = dot(paper_hash_276_local_1_scattered, (paper_hash_276_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_276_local_3_folded = (paper_hash_276_local_1_scattered + float3(paper_hash_276_local_2_shift, paper_hash_276_local_2_shift, paper_hash_276_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_277_local_1_scattered = fract(((paper_noise_275_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_277_local_2_shift = dot(paper_hash_277_local_1_scattered, (paper_hash_277_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_277_local_3_folded = (paper_hash_277_local_1_scattered + float3(paper_hash_277_local_2_shift, paper_hash_277_local_2_shift, paper_hash_277_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_275_local_7_near_low = mix(fract(((paper_hash_276_local_3_folded.x + paper_hash_276_local_3_folded.y) * paper_hash_276_local_3_folded.z)), fract(((paper_hash_277_local_3_folded.x + paper_hash_277_local_3_folded.y) * paper_hash_277_local_3_folded.z)), paper_noise_275_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_278_local_1_scattered = fract(((paper_noise_275_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_278_local_2_shift = dot(paper_hash_278_local_1_scattered, (paper_hash_278_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_278_local_3_folded = (paper_hash_278_local_1_scattered + float3(paper_hash_278_local_2_shift, paper_hash_278_local_2_shift, paper_hash_278_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_279_local_1_scattered = fract(((paper_noise_275_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_279_local_2_shift = dot(paper_hash_279_local_1_scattered, (paper_hash_279_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_279_local_3_folded = (paper_hash_279_local_1_scattered + float3(paper_hash_279_local_2_shift, paper_hash_279_local_2_shift, paper_hash_279_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_275_local_8_near_high = mix(fract(((paper_hash_278_local_3_folded.x + paper_hash_278_local_3_folded.y) * paper_hash_278_local_3_folded.z)), fract(((paper_hash_279_local_3_folded.x + paper_hash_279_local_3_folded.y) * paper_hash_279_local_3_folded.z)), paper_noise_275_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_280_local_1_scattered = fract(((paper_noise_275_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_280_local_2_shift = dot(paper_hash_280_local_1_scattered, (paper_hash_280_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_280_local_3_folded = (paper_hash_280_local_1_scattered + float3(paper_hash_280_local_2_shift, paper_hash_280_local_2_shift, paper_hash_280_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_281_local_1_scattered = fract(((paper_noise_275_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_281_local_2_shift = dot(paper_hash_281_local_1_scattered, (paper_hash_281_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_281_local_3_folded = (paper_hash_281_local_1_scattered + float3(paper_hash_281_local_2_shift, paper_hash_281_local_2_shift, paper_hash_281_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_275_local_9_far_low = mix(fract(((paper_hash_280_local_3_folded.x + paper_hash_280_local_3_folded.y) * paper_hash_280_local_3_folded.z)), fract(((paper_hash_281_local_3_folded.x + paper_hash_281_local_3_folded.y) * paper_hash_281_local_3_folded.z)), paper_noise_275_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_282_local_1_scattered = fract(((paper_noise_275_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_282_local_2_shift = dot(paper_hash_282_local_1_scattered, (paper_hash_282_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_282_local_3_folded = (paper_hash_282_local_1_scattered + float3(paper_hash_282_local_2_shift, paper_hash_282_local_2_shift, paper_hash_282_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_283_local_1_scattered = fract(((paper_noise_275_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_283_local_2_shift = dot(paper_hash_283_local_1_scattered, (paper_hash_283_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_283_local_3_folded = (paper_hash_283_local_1_scattered + float3(paper_hash_283_local_2_shift, paper_hash_283_local_2_shift, paper_hash_283_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_275_local_10_far_high = mix(fract(((paper_hash_282_local_3_folded.x + paper_hash_282_local_3_folded.y) * paper_hash_282_local_3_folded.z)), fract(((paper_hash_283_local_3_folded.x + paper_hash_283_local_3_folded.y) * paper_hash_283_local_3_folded.z)), paper_noise_275_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_285_local_1_lattice = floor((relief_normal_217_local_5_along_point * 1.9f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_285_local_2_offset = fract((relief_normal_217_local_5_along_point * 1.9f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_285_local_3_weight = (paper_noise_285_local_2_offset * (paper_noise_285_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_285_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_285_local_4_u = paper_noise_285_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_285_local_5_v = paper_noise_285_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_285_local_6_w = paper_noise_285_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_286_local_1_scattered = fract((paper_noise_285_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_286_local_2_shift = dot(paper_hash_286_local_1_scattered, (paper_hash_286_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_286_local_3_folded = (paper_hash_286_local_1_scattered + float3(paper_hash_286_local_2_shift, paper_hash_286_local_2_shift, paper_hash_286_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_287_local_1_scattered = fract(((paper_noise_285_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_287_local_2_shift = dot(paper_hash_287_local_1_scattered, (paper_hash_287_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_287_local_3_folded = (paper_hash_287_local_1_scattered + float3(paper_hash_287_local_2_shift, paper_hash_287_local_2_shift, paper_hash_287_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_285_local_7_near_low = mix(fract(((paper_hash_286_local_3_folded.x + paper_hash_286_local_3_folded.y) * paper_hash_286_local_3_folded.z)), fract(((paper_hash_287_local_3_folded.x + paper_hash_287_local_3_folded.y) * paper_hash_287_local_3_folded.z)), paper_noise_285_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_288_local_1_scattered = fract(((paper_noise_285_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_288_local_2_shift = dot(paper_hash_288_local_1_scattered, (paper_hash_288_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_288_local_3_folded = (paper_hash_288_local_1_scattered + float3(paper_hash_288_local_2_shift, paper_hash_288_local_2_shift, paper_hash_288_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_289_local_1_scattered = fract(((paper_noise_285_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_289_local_2_shift = dot(paper_hash_289_local_1_scattered, (paper_hash_289_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_289_local_3_folded = (paper_hash_289_local_1_scattered + float3(paper_hash_289_local_2_shift, paper_hash_289_local_2_shift, paper_hash_289_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_285_local_8_near_high = mix(fract(((paper_hash_288_local_3_folded.x + paper_hash_288_local_3_folded.y) * paper_hash_288_local_3_folded.z)), fract(((paper_hash_289_local_3_folded.x + paper_hash_289_local_3_folded.y) * paper_hash_289_local_3_folded.z)), paper_noise_285_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_290_local_1_scattered = fract(((paper_noise_285_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_290_local_2_shift = dot(paper_hash_290_local_1_scattered, (paper_hash_290_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_290_local_3_folded = (paper_hash_290_local_1_scattered + float3(paper_hash_290_local_2_shift, paper_hash_290_local_2_shift, paper_hash_290_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_291_local_1_scattered = fract(((paper_noise_285_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_291_local_2_shift = dot(paper_hash_291_local_1_scattered, (paper_hash_291_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_291_local_3_folded = (paper_hash_291_local_1_scattered + float3(paper_hash_291_local_2_shift, paper_hash_291_local_2_shift, paper_hash_291_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_285_local_9_far_low = mix(fract(((paper_hash_290_local_3_folded.x + paper_hash_290_local_3_folded.y) * paper_hash_290_local_3_folded.z)), fract(((paper_hash_291_local_3_folded.x + paper_hash_291_local_3_folded.y) * paper_hash_291_local_3_folded.z)), paper_noise_285_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_292_local_1_scattered = fract(((paper_noise_285_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_292_local_2_shift = dot(paper_hash_292_local_1_scattered, (paper_hash_292_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_292_local_3_folded = (paper_hash_292_local_1_scattered + float3(paper_hash_292_local_2_shift, paper_hash_292_local_2_shift, paper_hash_292_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_293_local_1_scattered = fract(((paper_noise_285_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_293_local_2_shift = dot(paper_hash_293_local_1_scattered, (paper_hash_293_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_293_local_3_folded = (paper_hash_293_local_1_scattered + float3(paper_hash_293_local_2_shift, paper_hash_293_local_2_shift, paper_hash_293_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_285_local_10_far_high = mix(fract(((paper_hash_292_local_3_folded.x + paper_hash_292_local_3_folded.y) * paper_hash_292_local_3_folded.z)), fract(((paper_hash_293_local_3_folded.x + paper_hash_293_local_3_folded.y) * paper_hash_293_local_3_folded.z)), paper_noise_285_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_294_local_1_lattice = floor((relief_normal_217_local_5_along_point * 0.7f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_294_local_2_offset = fract((relief_normal_217_local_5_along_point * 0.7f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_294_local_3_weight = (paper_noise_294_local_2_offset * (paper_noise_294_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_294_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_294_local_4_u = paper_noise_294_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_294_local_5_v = paper_noise_294_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_294_local_6_w = paper_noise_294_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_295_local_1_scattered = fract((paper_noise_294_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_295_local_2_shift = dot(paper_hash_295_local_1_scattered, (paper_hash_295_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_295_local_3_folded = (paper_hash_295_local_1_scattered + float3(paper_hash_295_local_2_shift, paper_hash_295_local_2_shift, paper_hash_295_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_296_local_1_scattered = fract(((paper_noise_294_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_296_local_2_shift = dot(paper_hash_296_local_1_scattered, (paper_hash_296_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_296_local_3_folded = (paper_hash_296_local_1_scattered + float3(paper_hash_296_local_2_shift, paper_hash_296_local_2_shift, paper_hash_296_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_294_local_7_near_low = mix(fract(((paper_hash_295_local_3_folded.x + paper_hash_295_local_3_folded.y) * paper_hash_295_local_3_folded.z)), fract(((paper_hash_296_local_3_folded.x + paper_hash_296_local_3_folded.y) * paper_hash_296_local_3_folded.z)), paper_noise_294_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_297_local_1_scattered = fract(((paper_noise_294_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_297_local_2_shift = dot(paper_hash_297_local_1_scattered, (paper_hash_297_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_297_local_3_folded = (paper_hash_297_local_1_scattered + float3(paper_hash_297_local_2_shift, paper_hash_297_local_2_shift, paper_hash_297_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_298_local_1_scattered = fract(((paper_noise_294_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_298_local_2_shift = dot(paper_hash_298_local_1_scattered, (paper_hash_298_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_298_local_3_folded = (paper_hash_298_local_1_scattered + float3(paper_hash_298_local_2_shift, paper_hash_298_local_2_shift, paper_hash_298_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_294_local_8_near_high = mix(fract(((paper_hash_297_local_3_folded.x + paper_hash_297_local_3_folded.y) * paper_hash_297_local_3_folded.z)), fract(((paper_hash_298_local_3_folded.x + paper_hash_298_local_3_folded.y) * paper_hash_298_local_3_folded.z)), paper_noise_294_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_299_local_1_scattered = fract(((paper_noise_294_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_299_local_2_shift = dot(paper_hash_299_local_1_scattered, (paper_hash_299_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_299_local_3_folded = (paper_hash_299_local_1_scattered + float3(paper_hash_299_local_2_shift, paper_hash_299_local_2_shift, paper_hash_299_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_300_local_1_scattered = fract(((paper_noise_294_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_300_local_2_shift = dot(paper_hash_300_local_1_scattered, (paper_hash_300_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_300_local_3_folded = (paper_hash_300_local_1_scattered + float3(paper_hash_300_local_2_shift, paper_hash_300_local_2_shift, paper_hash_300_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_294_local_9_far_low = mix(fract(((paper_hash_299_local_3_folded.x + paper_hash_299_local_3_folded.y) * paper_hash_299_local_3_folded.z)), fract(((paper_hash_300_local_3_folded.x + paper_hash_300_local_3_folded.y) * paper_hash_300_local_3_folded.z)), paper_noise_294_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_301_local_1_scattered = fract(((paper_noise_294_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_301_local_2_shift = dot(paper_hash_301_local_1_scattered, (paper_hash_301_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_301_local_3_folded = (paper_hash_301_local_1_scattered + float3(paper_hash_301_local_2_shift, paper_hash_301_local_2_shift, paper_hash_301_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_302_local_1_scattered = fract(((paper_noise_294_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_302_local_2_shift = dot(paper_hash_302_local_1_scattered, (paper_hash_302_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_302_local_3_folded = (paper_hash_302_local_1_scattered + float3(paper_hash_302_local_2_shift, paper_hash_302_local_2_shift, paper_hash_302_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_294_local_10_far_high = mix(fract(((paper_hash_301_local_3_folded.x + paper_hash_301_local_3_folded.y) * paper_hash_301_local_3_folded.z)), fract(((paper_hash_302_local_3_folded.x + paper_hash_302_local_3_folded.y) * paper_hash_302_local_3_folded.z)), paper_noise_294_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_303_local_1_lattice = floor((relief_normal_217_local_5_along_point * 7.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_303_local_2_offset = fract((relief_normal_217_local_5_along_point * 7.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_303_local_3_weight = (paper_noise_303_local_2_offset * (paper_noise_303_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_303_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_303_local_4_u = paper_noise_303_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_303_local_5_v = paper_noise_303_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_303_local_6_w = paper_noise_303_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_304_local_1_scattered = fract((paper_noise_303_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_304_local_2_shift = dot(paper_hash_304_local_1_scattered, (paper_hash_304_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_304_local_3_folded = (paper_hash_304_local_1_scattered + float3(paper_hash_304_local_2_shift, paper_hash_304_local_2_shift, paper_hash_304_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_305_local_1_scattered = fract(((paper_noise_303_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_305_local_2_shift = dot(paper_hash_305_local_1_scattered, (paper_hash_305_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_305_local_3_folded = (paper_hash_305_local_1_scattered + float3(paper_hash_305_local_2_shift, paper_hash_305_local_2_shift, paper_hash_305_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_303_local_7_near_low = mix(fract(((paper_hash_304_local_3_folded.x + paper_hash_304_local_3_folded.y) * paper_hash_304_local_3_folded.z)), fract(((paper_hash_305_local_3_folded.x + paper_hash_305_local_3_folded.y) * paper_hash_305_local_3_folded.z)), paper_noise_303_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_306_local_1_scattered = fract(((paper_noise_303_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_306_local_2_shift = dot(paper_hash_306_local_1_scattered, (paper_hash_306_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_306_local_3_folded = (paper_hash_306_local_1_scattered + float3(paper_hash_306_local_2_shift, paper_hash_306_local_2_shift, paper_hash_306_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_307_local_1_scattered = fract(((paper_noise_303_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_307_local_2_shift = dot(paper_hash_307_local_1_scattered, (paper_hash_307_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_307_local_3_folded = (paper_hash_307_local_1_scattered + float3(paper_hash_307_local_2_shift, paper_hash_307_local_2_shift, paper_hash_307_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_303_local_8_near_high = mix(fract(((paper_hash_306_local_3_folded.x + paper_hash_306_local_3_folded.y) * paper_hash_306_local_3_folded.z)), fract(((paper_hash_307_local_3_folded.x + paper_hash_307_local_3_folded.y) * paper_hash_307_local_3_folded.z)), paper_noise_303_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_308_local_1_scattered = fract(((paper_noise_303_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_308_local_2_shift = dot(paper_hash_308_local_1_scattered, (paper_hash_308_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_308_local_3_folded = (paper_hash_308_local_1_scattered + float3(paper_hash_308_local_2_shift, paper_hash_308_local_2_shift, paper_hash_308_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_309_local_1_scattered = fract(((paper_noise_303_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_309_local_2_shift = dot(paper_hash_309_local_1_scattered, (paper_hash_309_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_309_local_3_folded = (paper_hash_309_local_1_scattered + float3(paper_hash_309_local_2_shift, paper_hash_309_local_2_shift, paper_hash_309_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_303_local_9_far_low = mix(fract(((paper_hash_308_local_3_folded.x + paper_hash_308_local_3_folded.y) * paper_hash_308_local_3_folded.z)), fract(((paper_hash_309_local_3_folded.x + paper_hash_309_local_3_folded.y) * paper_hash_309_local_3_folded.z)), paper_noise_303_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_310_local_1_scattered = fract(((paper_noise_303_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_310_local_2_shift = dot(paper_hash_310_local_1_scattered, (paper_hash_310_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_310_local_3_folded = (paper_hash_310_local_1_scattered + float3(paper_hash_310_local_2_shift, paper_hash_310_local_2_shift, paper_hash_310_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_311_local_1_scattered = fract(((paper_noise_303_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_311_local_2_shift = dot(paper_hash_311_local_1_scattered, (paper_hash_311_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_311_local_3_folded = (paper_hash_311_local_1_scattered + float3(paper_hash_311_local_2_shift, paper_hash_311_local_2_shift, paper_hash_311_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_303_local_10_far_high = mix(fract(((paper_hash_310_local_3_folded.x + paper_hash_310_local_3_folded.y) * paper_hash_310_local_3_folded.z)), fract(((paper_hash_311_local_3_folded.x + paper_hash_311_local_3_folded.y) * paper_hash_311_local_3_folded.z)), paper_noise_303_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_312_local_1_lattice = floor((relief_normal_217_local_5_along_point * 9.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_312_local_2_offset = fract((relief_normal_217_local_5_along_point * 9.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_312_local_3_weight = (paper_noise_312_local_2_offset * (paper_noise_312_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_312_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_312_local_4_u = paper_noise_312_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_312_local_5_v = paper_noise_312_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_312_local_6_w = paper_noise_312_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_313_local_1_scattered = fract((paper_noise_312_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_313_local_2_shift = dot(paper_hash_313_local_1_scattered, (paper_hash_313_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_313_local_3_folded = (paper_hash_313_local_1_scattered + float3(paper_hash_313_local_2_shift, paper_hash_313_local_2_shift, paper_hash_313_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_314_local_1_scattered = fract(((paper_noise_312_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_314_local_2_shift = dot(paper_hash_314_local_1_scattered, (paper_hash_314_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_314_local_3_folded = (paper_hash_314_local_1_scattered + float3(paper_hash_314_local_2_shift, paper_hash_314_local_2_shift, paper_hash_314_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_312_local_7_near_low = mix(fract(((paper_hash_313_local_3_folded.x + paper_hash_313_local_3_folded.y) * paper_hash_313_local_3_folded.z)), fract(((paper_hash_314_local_3_folded.x + paper_hash_314_local_3_folded.y) * paper_hash_314_local_3_folded.z)), paper_noise_312_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_315_local_1_scattered = fract(((paper_noise_312_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_315_local_2_shift = dot(paper_hash_315_local_1_scattered, (paper_hash_315_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_315_local_3_folded = (paper_hash_315_local_1_scattered + float3(paper_hash_315_local_2_shift, paper_hash_315_local_2_shift, paper_hash_315_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_316_local_1_scattered = fract(((paper_noise_312_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_316_local_2_shift = dot(paper_hash_316_local_1_scattered, (paper_hash_316_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_316_local_3_folded = (paper_hash_316_local_1_scattered + float3(paper_hash_316_local_2_shift, paper_hash_316_local_2_shift, paper_hash_316_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_312_local_8_near_high = mix(fract(((paper_hash_315_local_3_folded.x + paper_hash_315_local_3_folded.y) * paper_hash_315_local_3_folded.z)), fract(((paper_hash_316_local_3_folded.x + paper_hash_316_local_3_folded.y) * paper_hash_316_local_3_folded.z)), paper_noise_312_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_317_local_1_scattered = fract(((paper_noise_312_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_317_local_2_shift = dot(paper_hash_317_local_1_scattered, (paper_hash_317_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_317_local_3_folded = (paper_hash_317_local_1_scattered + float3(paper_hash_317_local_2_shift, paper_hash_317_local_2_shift, paper_hash_317_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_318_local_1_scattered = fract(((paper_noise_312_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_318_local_2_shift = dot(paper_hash_318_local_1_scattered, (paper_hash_318_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_318_local_3_folded = (paper_hash_318_local_1_scattered + float3(paper_hash_318_local_2_shift, paper_hash_318_local_2_shift, paper_hash_318_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_312_local_9_far_low = mix(fract(((paper_hash_317_local_3_folded.x + paper_hash_317_local_3_folded.y) * paper_hash_317_local_3_folded.z)), fract(((paper_hash_318_local_3_folded.x + paper_hash_318_local_3_folded.y) * paper_hash_318_local_3_folded.z)), paper_noise_312_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_319_local_1_scattered = fract(((paper_noise_312_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_319_local_2_shift = dot(paper_hash_319_local_1_scattered, (paper_hash_319_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_319_local_3_folded = (paper_hash_319_local_1_scattered + float3(paper_hash_319_local_2_shift, paper_hash_319_local_2_shift, paper_hash_319_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_320_local_1_scattered = fract(((paper_noise_312_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_320_local_2_shift = dot(paper_hash_320_local_1_scattered, (paper_hash_320_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_320_local_3_folded = (paper_hash_320_local_1_scattered + float3(paper_hash_320_local_2_shift, paper_hash_320_local_2_shift, paper_hash_320_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_312_local_10_far_high = mix(fract(((paper_hash_319_local_3_folded.x + paper_hash_319_local_3_folded.y) * paper_hash_319_local_3_folded.z)), fract(((paper_hash_320_local_3_folded.x + paper_hash_320_local_3_folded.y) * paper_hash_320_local_3_folded.z)), paper_noise_312_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_321_local_1_lattice = floor((relief_normal_217_local_5_along_point * 2.3f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_321_local_2_offset = fract((relief_normal_217_local_5_along_point * 2.3f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_321_local_3_weight = (paper_noise_321_local_2_offset * (paper_noise_321_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_321_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_321_local_4_u = paper_noise_321_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_321_local_5_v = paper_noise_321_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_321_local_6_w = paper_noise_321_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_322_local_1_scattered = fract((paper_noise_321_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_322_local_2_shift = dot(paper_hash_322_local_1_scattered, (paper_hash_322_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_322_local_3_folded = (paper_hash_322_local_1_scattered + float3(paper_hash_322_local_2_shift, paper_hash_322_local_2_shift, paper_hash_322_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_323_local_1_scattered = fract(((paper_noise_321_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_323_local_2_shift = dot(paper_hash_323_local_1_scattered, (paper_hash_323_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_323_local_3_folded = (paper_hash_323_local_1_scattered + float3(paper_hash_323_local_2_shift, paper_hash_323_local_2_shift, paper_hash_323_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_321_local_7_near_low = mix(fract(((paper_hash_322_local_3_folded.x + paper_hash_322_local_3_folded.y) * paper_hash_322_local_3_folded.z)), fract(((paper_hash_323_local_3_folded.x + paper_hash_323_local_3_folded.y) * paper_hash_323_local_3_folded.z)), paper_noise_321_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_324_local_1_scattered = fract(((paper_noise_321_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_324_local_2_shift = dot(paper_hash_324_local_1_scattered, (paper_hash_324_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_324_local_3_folded = (paper_hash_324_local_1_scattered + float3(paper_hash_324_local_2_shift, paper_hash_324_local_2_shift, paper_hash_324_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_325_local_1_scattered = fract(((paper_noise_321_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_325_local_2_shift = dot(paper_hash_325_local_1_scattered, (paper_hash_325_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_325_local_3_folded = (paper_hash_325_local_1_scattered + float3(paper_hash_325_local_2_shift, paper_hash_325_local_2_shift, paper_hash_325_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_321_local_8_near_high = mix(fract(((paper_hash_324_local_3_folded.x + paper_hash_324_local_3_folded.y) * paper_hash_324_local_3_folded.z)), fract(((paper_hash_325_local_3_folded.x + paper_hash_325_local_3_folded.y) * paper_hash_325_local_3_folded.z)), paper_noise_321_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_326_local_1_scattered = fract(((paper_noise_321_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_326_local_2_shift = dot(paper_hash_326_local_1_scattered, (paper_hash_326_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_326_local_3_folded = (paper_hash_326_local_1_scattered + float3(paper_hash_326_local_2_shift, paper_hash_326_local_2_shift, paper_hash_326_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_327_local_1_scattered = fract(((paper_noise_321_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_327_local_2_shift = dot(paper_hash_327_local_1_scattered, (paper_hash_327_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_327_local_3_folded = (paper_hash_327_local_1_scattered + float3(paper_hash_327_local_2_shift, paper_hash_327_local_2_shift, paper_hash_327_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_321_local_9_far_low = mix(fract(((paper_hash_326_local_3_folded.x + paper_hash_326_local_3_folded.y) * paper_hash_326_local_3_folded.z)), fract(((paper_hash_327_local_3_folded.x + paper_hash_327_local_3_folded.y) * paper_hash_327_local_3_folded.z)), paper_noise_321_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_328_local_1_scattered = fract(((paper_noise_321_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_328_local_2_shift = dot(paper_hash_328_local_1_scattered, (paper_hash_328_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_328_local_3_folded = (paper_hash_328_local_1_scattered + float3(paper_hash_328_local_2_shift, paper_hash_328_local_2_shift, paper_hash_328_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_329_local_1_scattered = fract(((paper_noise_321_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_329_local_2_shift = dot(paper_hash_329_local_1_scattered, (paper_hash_329_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_329_local_3_folded = (paper_hash_329_local_1_scattered + float3(paper_hash_329_local_2_shift, paper_hash_329_local_2_shift, paper_hash_329_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_321_local_10_far_high = mix(fract(((paper_hash_328_local_3_folded.x + paper_hash_328_local_3_folded.y) * paper_hash_328_local_3_folded.z)), fract(((paper_hash_329_local_3_folded.x + paper_hash_329_local_3_folded.y) * paper_hash_329_local_3_folded.z)), paper_noise_321_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_331_local_1_lattice = floor((relief_normal_217_local_5_along_point * float3(5.5f, 5.5f, 0.6f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_331_local_2_offset = fract((relief_normal_217_local_5_along_point * float3(5.5f, 5.5f, 0.6f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_331_local_3_weight = (paper_noise_331_local_2_offset * (paper_noise_331_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_331_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_331_local_4_u = paper_noise_331_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_331_local_5_v = paper_noise_331_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_331_local_6_w = paper_noise_331_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_332_local_1_scattered = fract((paper_noise_331_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_332_local_2_shift = dot(paper_hash_332_local_1_scattered, (paper_hash_332_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_332_local_3_folded = (paper_hash_332_local_1_scattered + float3(paper_hash_332_local_2_shift, paper_hash_332_local_2_shift, paper_hash_332_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_333_local_1_scattered = fract(((paper_noise_331_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_333_local_2_shift = dot(paper_hash_333_local_1_scattered, (paper_hash_333_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_333_local_3_folded = (paper_hash_333_local_1_scattered + float3(paper_hash_333_local_2_shift, paper_hash_333_local_2_shift, paper_hash_333_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_331_local_7_near_low = mix(fract(((paper_hash_332_local_3_folded.x + paper_hash_332_local_3_folded.y) * paper_hash_332_local_3_folded.z)), fract(((paper_hash_333_local_3_folded.x + paper_hash_333_local_3_folded.y) * paper_hash_333_local_3_folded.z)), paper_noise_331_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_334_local_1_scattered = fract(((paper_noise_331_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_334_local_2_shift = dot(paper_hash_334_local_1_scattered, (paper_hash_334_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_334_local_3_folded = (paper_hash_334_local_1_scattered + float3(paper_hash_334_local_2_shift, paper_hash_334_local_2_shift, paper_hash_334_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_335_local_1_scattered = fract(((paper_noise_331_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_335_local_2_shift = dot(paper_hash_335_local_1_scattered, (paper_hash_335_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_335_local_3_folded = (paper_hash_335_local_1_scattered + float3(paper_hash_335_local_2_shift, paper_hash_335_local_2_shift, paper_hash_335_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_331_local_8_near_high = mix(fract(((paper_hash_334_local_3_folded.x + paper_hash_334_local_3_folded.y) * paper_hash_334_local_3_folded.z)), fract(((paper_hash_335_local_3_folded.x + paper_hash_335_local_3_folded.y) * paper_hash_335_local_3_folded.z)), paper_noise_331_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_336_local_1_scattered = fract(((paper_noise_331_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_336_local_2_shift = dot(paper_hash_336_local_1_scattered, (paper_hash_336_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_336_local_3_folded = (paper_hash_336_local_1_scattered + float3(paper_hash_336_local_2_shift, paper_hash_336_local_2_shift, paper_hash_336_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_337_local_1_scattered = fract(((paper_noise_331_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_337_local_2_shift = dot(paper_hash_337_local_1_scattered, (paper_hash_337_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_337_local_3_folded = (paper_hash_337_local_1_scattered + float3(paper_hash_337_local_2_shift, paper_hash_337_local_2_shift, paper_hash_337_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_331_local_9_far_low = mix(fract(((paper_hash_336_local_3_folded.x + paper_hash_336_local_3_folded.y) * paper_hash_336_local_3_folded.z)), fract(((paper_hash_337_local_3_folded.x + paper_hash_337_local_3_folded.y) * paper_hash_337_local_3_folded.z)), paper_noise_331_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_338_local_1_scattered = fract(((paper_noise_331_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_338_local_2_shift = dot(paper_hash_338_local_1_scattered, (paper_hash_338_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_338_local_3_folded = (paper_hash_338_local_1_scattered + float3(paper_hash_338_local_2_shift, paper_hash_338_local_2_shift, paper_hash_338_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_339_local_1_scattered = fract(((paper_noise_331_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_339_local_2_shift = dot(paper_hash_339_local_1_scattered, (paper_hash_339_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_339_local_3_folded = (paper_hash_339_local_1_scattered + float3(paper_hash_339_local_2_shift, paper_hash_339_local_2_shift, paper_hash_339_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_331_local_10_far_high = mix(fract(((paper_hash_338_local_3_folded.x + paper_hash_338_local_3_folded.y) * paper_hash_338_local_3_folded.z)), fract(((paper_hash_339_local_3_folded.x + paper_hash_339_local_3_folded.y) * paper_hash_339_local_3_folded.z)), paper_noise_331_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_340_local_1_lattice = floor((relief_normal_217_local_5_along_point * 5.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_340_local_2_offset = fract((relief_normal_217_local_5_along_point * 5.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_340_local_3_weight = (paper_noise_340_local_2_offset * (paper_noise_340_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_340_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_340_local_4_u = paper_noise_340_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_340_local_5_v = paper_noise_340_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_340_local_6_w = paper_noise_340_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_341_local_1_scattered = fract((paper_noise_340_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_341_local_2_shift = dot(paper_hash_341_local_1_scattered, (paper_hash_341_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_341_local_3_folded = (paper_hash_341_local_1_scattered + float3(paper_hash_341_local_2_shift, paper_hash_341_local_2_shift, paper_hash_341_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_342_local_1_scattered = fract(((paper_noise_340_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_342_local_2_shift = dot(paper_hash_342_local_1_scattered, (paper_hash_342_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_342_local_3_folded = (paper_hash_342_local_1_scattered + float3(paper_hash_342_local_2_shift, paper_hash_342_local_2_shift, paper_hash_342_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_340_local_7_near_low = mix(fract(((paper_hash_341_local_3_folded.x + paper_hash_341_local_3_folded.y) * paper_hash_341_local_3_folded.z)), fract(((paper_hash_342_local_3_folded.x + paper_hash_342_local_3_folded.y) * paper_hash_342_local_3_folded.z)), paper_noise_340_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_343_local_1_scattered = fract(((paper_noise_340_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_343_local_2_shift = dot(paper_hash_343_local_1_scattered, (paper_hash_343_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_343_local_3_folded = (paper_hash_343_local_1_scattered + float3(paper_hash_343_local_2_shift, paper_hash_343_local_2_shift, paper_hash_343_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_344_local_1_scattered = fract(((paper_noise_340_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_344_local_2_shift = dot(paper_hash_344_local_1_scattered, (paper_hash_344_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_344_local_3_folded = (paper_hash_344_local_1_scattered + float3(paper_hash_344_local_2_shift, paper_hash_344_local_2_shift, paper_hash_344_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_340_local_8_near_high = mix(fract(((paper_hash_343_local_3_folded.x + paper_hash_343_local_3_folded.y) * paper_hash_343_local_3_folded.z)), fract(((paper_hash_344_local_3_folded.x + paper_hash_344_local_3_folded.y) * paper_hash_344_local_3_folded.z)), paper_noise_340_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_345_local_1_scattered = fract(((paper_noise_340_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_345_local_2_shift = dot(paper_hash_345_local_1_scattered, (paper_hash_345_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_345_local_3_folded = (paper_hash_345_local_1_scattered + float3(paper_hash_345_local_2_shift, paper_hash_345_local_2_shift, paper_hash_345_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_346_local_1_scattered = fract(((paper_noise_340_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_346_local_2_shift = dot(paper_hash_346_local_1_scattered, (paper_hash_346_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_346_local_3_folded = (paper_hash_346_local_1_scattered + float3(paper_hash_346_local_2_shift, paper_hash_346_local_2_shift, paper_hash_346_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_340_local_9_far_low = mix(fract(((paper_hash_345_local_3_folded.x + paper_hash_345_local_3_folded.y) * paper_hash_345_local_3_folded.z)), fract(((paper_hash_346_local_3_folded.x + paper_hash_346_local_3_folded.y) * paper_hash_346_local_3_folded.z)), paper_noise_340_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_347_local_1_scattered = fract(((paper_noise_340_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_347_local_2_shift = dot(paper_hash_347_local_1_scattered, (paper_hash_347_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_347_local_3_folded = (paper_hash_347_local_1_scattered + float3(paper_hash_347_local_2_shift, paper_hash_347_local_2_shift, paper_hash_347_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_348_local_1_scattered = fract(((paper_noise_340_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_348_local_2_shift = dot(paper_hash_348_local_1_scattered, (paper_hash_348_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_348_local_3_folded = (paper_hash_348_local_1_scattered + float3(paper_hash_348_local_2_shift, paper_hash_348_local_2_shift, paper_hash_348_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_340_local_10_far_high = mix(fract(((paper_hash_347_local_3_folded.x + paper_hash_347_local_3_folded.y) * paper_hash_347_local_3_folded.z)), fract(((paper_hash_348_local_3_folded.x + paper_hash_348_local_3_folded.y) * paper_hash_348_local_3_folded.z)), paper_noise_340_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_349_local_1_lattice = floor((relief_normal_217_local_5_along_point * 14.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_349_local_2_offset = fract((relief_normal_217_local_5_along_point * 14.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_349_local_3_weight = (paper_noise_349_local_2_offset * (paper_noise_349_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_349_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_349_local_4_u = paper_noise_349_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_349_local_5_v = paper_noise_349_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_349_local_6_w = paper_noise_349_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_350_local_1_scattered = fract((paper_noise_349_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_350_local_2_shift = dot(paper_hash_350_local_1_scattered, (paper_hash_350_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_350_local_3_folded = (paper_hash_350_local_1_scattered + float3(paper_hash_350_local_2_shift, paper_hash_350_local_2_shift, paper_hash_350_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_351_local_1_scattered = fract(((paper_noise_349_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_351_local_2_shift = dot(paper_hash_351_local_1_scattered, (paper_hash_351_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_351_local_3_folded = (paper_hash_351_local_1_scattered + float3(paper_hash_351_local_2_shift, paper_hash_351_local_2_shift, paper_hash_351_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_349_local_7_near_low = mix(fract(((paper_hash_350_local_3_folded.x + paper_hash_350_local_3_folded.y) * paper_hash_350_local_3_folded.z)), fract(((paper_hash_351_local_3_folded.x + paper_hash_351_local_3_folded.y) * paper_hash_351_local_3_folded.z)), paper_noise_349_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_352_local_1_scattered = fract(((paper_noise_349_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_352_local_2_shift = dot(paper_hash_352_local_1_scattered, (paper_hash_352_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_352_local_3_folded = (paper_hash_352_local_1_scattered + float3(paper_hash_352_local_2_shift, paper_hash_352_local_2_shift, paper_hash_352_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_353_local_1_scattered = fract(((paper_noise_349_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_353_local_2_shift = dot(paper_hash_353_local_1_scattered, (paper_hash_353_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_353_local_3_folded = (paper_hash_353_local_1_scattered + float3(paper_hash_353_local_2_shift, paper_hash_353_local_2_shift, paper_hash_353_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_349_local_8_near_high = mix(fract(((paper_hash_352_local_3_folded.x + paper_hash_352_local_3_folded.y) * paper_hash_352_local_3_folded.z)), fract(((paper_hash_353_local_3_folded.x + paper_hash_353_local_3_folded.y) * paper_hash_353_local_3_folded.z)), paper_noise_349_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_354_local_1_scattered = fract(((paper_noise_349_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_354_local_2_shift = dot(paper_hash_354_local_1_scattered, (paper_hash_354_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_354_local_3_folded = (paper_hash_354_local_1_scattered + float3(paper_hash_354_local_2_shift, paper_hash_354_local_2_shift, paper_hash_354_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_355_local_1_scattered = fract(((paper_noise_349_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_355_local_2_shift = dot(paper_hash_355_local_1_scattered, (paper_hash_355_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_355_local_3_folded = (paper_hash_355_local_1_scattered + float3(paper_hash_355_local_2_shift, paper_hash_355_local_2_shift, paper_hash_355_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_349_local_9_far_low = mix(fract(((paper_hash_354_local_3_folded.x + paper_hash_354_local_3_folded.y) * paper_hash_354_local_3_folded.z)), fract(((paper_hash_355_local_3_folded.x + paper_hash_355_local_3_folded.y) * paper_hash_355_local_3_folded.z)), paper_noise_349_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_356_local_1_scattered = fract(((paper_noise_349_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_356_local_2_shift = dot(paper_hash_356_local_1_scattered, (paper_hash_356_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_356_local_3_folded = (paper_hash_356_local_1_scattered + float3(paper_hash_356_local_2_shift, paper_hash_356_local_2_shift, paper_hash_356_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_357_local_1_scattered = fract(((paper_noise_349_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_357_local_2_shift = dot(paper_hash_357_local_1_scattered, (paper_hash_357_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_357_local_3_folded = (paper_hash_357_local_1_scattered + float3(paper_hash_357_local_2_shift, paper_hash_357_local_2_shift, paper_hash_357_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_349_local_10_far_high = mix(fract(((paper_hash_356_local_3_folded.x + paper_hash_356_local_3_folded.y) * paper_hash_356_local_3_folded.z)), fract(((paper_hash_357_local_3_folded.x + paper_hash_357_local_3_folded.y) * paper_hash_357_local_3_folded.z)), paper_noise_349_local_4_u);
  // This numeric value has no quantity annotation.
  float plank_height_358_local_1_u = fract(((relief_normal_217_local_5_along_point.x + relief_normal_217_local_5_along_point.y) * 4.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_359_local_1_lattice = floor((relief_normal_217_local_5_along_point * float3(1.0f, 1.0f, 9.0f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_359_local_2_offset = fract((relief_normal_217_local_5_along_point * float3(1.0f, 1.0f, 9.0f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_359_local_3_weight = (paper_noise_359_local_2_offset * (paper_noise_359_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_359_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_359_local_4_u = paper_noise_359_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_359_local_5_v = paper_noise_359_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_359_local_6_w = paper_noise_359_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_360_local_1_scattered = fract((paper_noise_359_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_360_local_2_shift = dot(paper_hash_360_local_1_scattered, (paper_hash_360_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_360_local_3_folded = (paper_hash_360_local_1_scattered + float3(paper_hash_360_local_2_shift, paper_hash_360_local_2_shift, paper_hash_360_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_361_local_1_scattered = fract(((paper_noise_359_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_361_local_2_shift = dot(paper_hash_361_local_1_scattered, (paper_hash_361_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_361_local_3_folded = (paper_hash_361_local_1_scattered + float3(paper_hash_361_local_2_shift, paper_hash_361_local_2_shift, paper_hash_361_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_359_local_7_near_low = mix(fract(((paper_hash_360_local_3_folded.x + paper_hash_360_local_3_folded.y) * paper_hash_360_local_3_folded.z)), fract(((paper_hash_361_local_3_folded.x + paper_hash_361_local_3_folded.y) * paper_hash_361_local_3_folded.z)), paper_noise_359_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_362_local_1_scattered = fract(((paper_noise_359_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_362_local_2_shift = dot(paper_hash_362_local_1_scattered, (paper_hash_362_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_362_local_3_folded = (paper_hash_362_local_1_scattered + float3(paper_hash_362_local_2_shift, paper_hash_362_local_2_shift, paper_hash_362_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_363_local_1_scattered = fract(((paper_noise_359_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_363_local_2_shift = dot(paper_hash_363_local_1_scattered, (paper_hash_363_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_363_local_3_folded = (paper_hash_363_local_1_scattered + float3(paper_hash_363_local_2_shift, paper_hash_363_local_2_shift, paper_hash_363_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_359_local_8_near_high = mix(fract(((paper_hash_362_local_3_folded.x + paper_hash_362_local_3_folded.y) * paper_hash_362_local_3_folded.z)), fract(((paper_hash_363_local_3_folded.x + paper_hash_363_local_3_folded.y) * paper_hash_363_local_3_folded.z)), paper_noise_359_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_364_local_1_scattered = fract(((paper_noise_359_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_364_local_2_shift = dot(paper_hash_364_local_1_scattered, (paper_hash_364_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_364_local_3_folded = (paper_hash_364_local_1_scattered + float3(paper_hash_364_local_2_shift, paper_hash_364_local_2_shift, paper_hash_364_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_365_local_1_scattered = fract(((paper_noise_359_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_365_local_2_shift = dot(paper_hash_365_local_1_scattered, (paper_hash_365_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_365_local_3_folded = (paper_hash_365_local_1_scattered + float3(paper_hash_365_local_2_shift, paper_hash_365_local_2_shift, paper_hash_365_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_359_local_9_far_low = mix(fract(((paper_hash_364_local_3_folded.x + paper_hash_364_local_3_folded.y) * paper_hash_364_local_3_folded.z)), fract(((paper_hash_365_local_3_folded.x + paper_hash_365_local_3_folded.y) * paper_hash_365_local_3_folded.z)), paper_noise_359_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_366_local_1_scattered = fract(((paper_noise_359_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_366_local_2_shift = dot(paper_hash_366_local_1_scattered, (paper_hash_366_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_366_local_3_folded = (paper_hash_366_local_1_scattered + float3(paper_hash_366_local_2_shift, paper_hash_366_local_2_shift, paper_hash_366_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_367_local_1_scattered = fract(((paper_noise_359_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_367_local_2_shift = dot(paper_hash_367_local_1_scattered, (paper_hash_367_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_367_local_3_folded = (paper_hash_367_local_1_scattered + float3(paper_hash_367_local_2_shift, paper_hash_367_local_2_shift, paper_hash_367_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_359_local_10_far_high = mix(fract(((paper_hash_366_local_3_folded.x + paper_hash_366_local_3_folded.y) * paper_hash_366_local_3_folded.z)), fract(((paper_hash_367_local_3_folded.x + paper_hash_367_local_3_folded.y) * paper_hash_367_local_3_folded.z)), paper_noise_359_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_368_local_1_lattice = floor((relief_normal_217_local_5_along_point * 1.3f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_368_local_2_offset = fract((relief_normal_217_local_5_along_point * 1.3f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_368_local_3_weight = (paper_noise_368_local_2_offset * (paper_noise_368_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_368_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_368_local_4_u = paper_noise_368_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_368_local_5_v = paper_noise_368_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_368_local_6_w = paper_noise_368_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_369_local_1_scattered = fract((paper_noise_368_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_369_local_2_shift = dot(paper_hash_369_local_1_scattered, (paper_hash_369_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_369_local_3_folded = (paper_hash_369_local_1_scattered + float3(paper_hash_369_local_2_shift, paper_hash_369_local_2_shift, paper_hash_369_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_370_local_1_scattered = fract(((paper_noise_368_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_370_local_2_shift = dot(paper_hash_370_local_1_scattered, (paper_hash_370_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_370_local_3_folded = (paper_hash_370_local_1_scattered + float3(paper_hash_370_local_2_shift, paper_hash_370_local_2_shift, paper_hash_370_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_368_local_7_near_low = mix(fract(((paper_hash_369_local_3_folded.x + paper_hash_369_local_3_folded.y) * paper_hash_369_local_3_folded.z)), fract(((paper_hash_370_local_3_folded.x + paper_hash_370_local_3_folded.y) * paper_hash_370_local_3_folded.z)), paper_noise_368_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_371_local_1_scattered = fract(((paper_noise_368_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_371_local_2_shift = dot(paper_hash_371_local_1_scattered, (paper_hash_371_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_371_local_3_folded = (paper_hash_371_local_1_scattered + float3(paper_hash_371_local_2_shift, paper_hash_371_local_2_shift, paper_hash_371_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_372_local_1_scattered = fract(((paper_noise_368_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_372_local_2_shift = dot(paper_hash_372_local_1_scattered, (paper_hash_372_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_372_local_3_folded = (paper_hash_372_local_1_scattered + float3(paper_hash_372_local_2_shift, paper_hash_372_local_2_shift, paper_hash_372_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_368_local_8_near_high = mix(fract(((paper_hash_371_local_3_folded.x + paper_hash_371_local_3_folded.y) * paper_hash_371_local_3_folded.z)), fract(((paper_hash_372_local_3_folded.x + paper_hash_372_local_3_folded.y) * paper_hash_372_local_3_folded.z)), paper_noise_368_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_373_local_1_scattered = fract(((paper_noise_368_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_373_local_2_shift = dot(paper_hash_373_local_1_scattered, (paper_hash_373_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_373_local_3_folded = (paper_hash_373_local_1_scattered + float3(paper_hash_373_local_2_shift, paper_hash_373_local_2_shift, paper_hash_373_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_374_local_1_scattered = fract(((paper_noise_368_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_374_local_2_shift = dot(paper_hash_374_local_1_scattered, (paper_hash_374_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_374_local_3_folded = (paper_hash_374_local_1_scattered + float3(paper_hash_374_local_2_shift, paper_hash_374_local_2_shift, paper_hash_374_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_368_local_9_far_low = mix(fract(((paper_hash_373_local_3_folded.x + paper_hash_373_local_3_folded.y) * paper_hash_373_local_3_folded.z)), fract(((paper_hash_374_local_3_folded.x + paper_hash_374_local_3_folded.y) * paper_hash_374_local_3_folded.z)), paper_noise_368_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_375_local_1_scattered = fract(((paper_noise_368_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_375_local_2_shift = dot(paper_hash_375_local_1_scattered, (paper_hash_375_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_375_local_3_folded = (paper_hash_375_local_1_scattered + float3(paper_hash_375_local_2_shift, paper_hash_375_local_2_shift, paper_hash_375_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_376_local_1_scattered = fract(((paper_noise_368_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_376_local_2_shift = dot(paper_hash_376_local_1_scattered, (paper_hash_376_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_376_local_3_folded = (paper_hash_376_local_1_scattered + float3(paper_hash_376_local_2_shift, paper_hash_376_local_2_shift, paper_hash_376_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_368_local_10_far_high = mix(fract(((paper_hash_375_local_3_folded.x + paper_hash_375_local_3_folded.y) * paper_hash_375_local_3_folded.z)), fract(((paper_hash_376_local_3_folded.x + paper_hash_376_local_3_folded.y) * paper_hash_376_local_3_folded.z)), paper_noise_368_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_377_local_1_lattice = floor((relief_normal_217_local_5_along_point * 4.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_377_local_2_offset = fract((relief_normal_217_local_5_along_point * 4.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_377_local_3_weight = (paper_noise_377_local_2_offset * (paper_noise_377_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_377_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_377_local_4_u = paper_noise_377_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_377_local_5_v = paper_noise_377_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_377_local_6_w = paper_noise_377_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_378_local_1_scattered = fract((paper_noise_377_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_378_local_2_shift = dot(paper_hash_378_local_1_scattered, (paper_hash_378_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_378_local_3_folded = (paper_hash_378_local_1_scattered + float3(paper_hash_378_local_2_shift, paper_hash_378_local_2_shift, paper_hash_378_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_379_local_1_scattered = fract(((paper_noise_377_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_379_local_2_shift = dot(paper_hash_379_local_1_scattered, (paper_hash_379_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_379_local_3_folded = (paper_hash_379_local_1_scattered + float3(paper_hash_379_local_2_shift, paper_hash_379_local_2_shift, paper_hash_379_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_377_local_7_near_low = mix(fract(((paper_hash_378_local_3_folded.x + paper_hash_378_local_3_folded.y) * paper_hash_378_local_3_folded.z)), fract(((paper_hash_379_local_3_folded.x + paper_hash_379_local_3_folded.y) * paper_hash_379_local_3_folded.z)), paper_noise_377_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_380_local_1_scattered = fract(((paper_noise_377_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_380_local_2_shift = dot(paper_hash_380_local_1_scattered, (paper_hash_380_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_380_local_3_folded = (paper_hash_380_local_1_scattered + float3(paper_hash_380_local_2_shift, paper_hash_380_local_2_shift, paper_hash_380_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_381_local_1_scattered = fract(((paper_noise_377_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_381_local_2_shift = dot(paper_hash_381_local_1_scattered, (paper_hash_381_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_381_local_3_folded = (paper_hash_381_local_1_scattered + float3(paper_hash_381_local_2_shift, paper_hash_381_local_2_shift, paper_hash_381_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_377_local_8_near_high = mix(fract(((paper_hash_380_local_3_folded.x + paper_hash_380_local_3_folded.y) * paper_hash_380_local_3_folded.z)), fract(((paper_hash_381_local_3_folded.x + paper_hash_381_local_3_folded.y) * paper_hash_381_local_3_folded.z)), paper_noise_377_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_382_local_1_scattered = fract(((paper_noise_377_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_382_local_2_shift = dot(paper_hash_382_local_1_scattered, (paper_hash_382_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_382_local_3_folded = (paper_hash_382_local_1_scattered + float3(paper_hash_382_local_2_shift, paper_hash_382_local_2_shift, paper_hash_382_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_383_local_1_scattered = fract(((paper_noise_377_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_383_local_2_shift = dot(paper_hash_383_local_1_scattered, (paper_hash_383_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_383_local_3_folded = (paper_hash_383_local_1_scattered + float3(paper_hash_383_local_2_shift, paper_hash_383_local_2_shift, paper_hash_383_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_377_local_9_far_low = mix(fract(((paper_hash_382_local_3_folded.x + paper_hash_382_local_3_folded.y) * paper_hash_382_local_3_folded.z)), fract(((paper_hash_383_local_3_folded.x + paper_hash_383_local_3_folded.y) * paper_hash_383_local_3_folded.z)), paper_noise_377_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_384_local_1_scattered = fract(((paper_noise_377_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_384_local_2_shift = dot(paper_hash_384_local_1_scattered, (paper_hash_384_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_384_local_3_folded = (paper_hash_384_local_1_scattered + float3(paper_hash_384_local_2_shift, paper_hash_384_local_2_shift, paper_hash_384_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_385_local_1_scattered = fract(((paper_noise_377_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_385_local_2_shift = dot(paper_hash_385_local_1_scattered, (paper_hash_385_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_385_local_3_folded = (paper_hash_385_local_1_scattered + float3(paper_hash_385_local_2_shift, paper_hash_385_local_2_shift, paper_hash_385_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_377_local_10_far_high = mix(fract(((paper_hash_384_local_3_folded.x + paper_hash_384_local_3_folded.y) * paper_hash_384_local_3_folded.z)), fract(((paper_hash_385_local_3_folded.x + paper_hash_385_local_3_folded.y) * paper_hash_385_local_3_folded.z)), paper_noise_377_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_386_local_1_lattice = floor((relief_normal_217_local_5_along_point * 2.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_386_local_2_offset = fract((relief_normal_217_local_5_along_point * 2.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_386_local_3_weight = (paper_noise_386_local_2_offset * (paper_noise_386_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_386_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_386_local_4_u = paper_noise_386_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_386_local_5_v = paper_noise_386_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_386_local_6_w = paper_noise_386_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_387_local_1_scattered = fract((paper_noise_386_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_387_local_2_shift = dot(paper_hash_387_local_1_scattered, (paper_hash_387_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_387_local_3_folded = (paper_hash_387_local_1_scattered + float3(paper_hash_387_local_2_shift, paper_hash_387_local_2_shift, paper_hash_387_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_388_local_1_scattered = fract(((paper_noise_386_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_388_local_2_shift = dot(paper_hash_388_local_1_scattered, (paper_hash_388_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_388_local_3_folded = (paper_hash_388_local_1_scattered + float3(paper_hash_388_local_2_shift, paper_hash_388_local_2_shift, paper_hash_388_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_386_local_7_near_low = mix(fract(((paper_hash_387_local_3_folded.x + paper_hash_387_local_3_folded.y) * paper_hash_387_local_3_folded.z)), fract(((paper_hash_388_local_3_folded.x + paper_hash_388_local_3_folded.y) * paper_hash_388_local_3_folded.z)), paper_noise_386_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_389_local_1_scattered = fract(((paper_noise_386_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_389_local_2_shift = dot(paper_hash_389_local_1_scattered, (paper_hash_389_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_389_local_3_folded = (paper_hash_389_local_1_scattered + float3(paper_hash_389_local_2_shift, paper_hash_389_local_2_shift, paper_hash_389_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_390_local_1_scattered = fract(((paper_noise_386_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_390_local_2_shift = dot(paper_hash_390_local_1_scattered, (paper_hash_390_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_390_local_3_folded = (paper_hash_390_local_1_scattered + float3(paper_hash_390_local_2_shift, paper_hash_390_local_2_shift, paper_hash_390_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_386_local_8_near_high = mix(fract(((paper_hash_389_local_3_folded.x + paper_hash_389_local_3_folded.y) * paper_hash_389_local_3_folded.z)), fract(((paper_hash_390_local_3_folded.x + paper_hash_390_local_3_folded.y) * paper_hash_390_local_3_folded.z)), paper_noise_386_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_391_local_1_scattered = fract(((paper_noise_386_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_391_local_2_shift = dot(paper_hash_391_local_1_scattered, (paper_hash_391_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_391_local_3_folded = (paper_hash_391_local_1_scattered + float3(paper_hash_391_local_2_shift, paper_hash_391_local_2_shift, paper_hash_391_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_392_local_1_scattered = fract(((paper_noise_386_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_392_local_2_shift = dot(paper_hash_392_local_1_scattered, (paper_hash_392_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_392_local_3_folded = (paper_hash_392_local_1_scattered + float3(paper_hash_392_local_2_shift, paper_hash_392_local_2_shift, paper_hash_392_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_386_local_9_far_low = mix(fract(((paper_hash_391_local_3_folded.x + paper_hash_391_local_3_folded.y) * paper_hash_391_local_3_folded.z)), fract(((paper_hash_392_local_3_folded.x + paper_hash_392_local_3_folded.y) * paper_hash_392_local_3_folded.z)), paper_noise_386_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_393_local_1_scattered = fract(((paper_noise_386_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_393_local_2_shift = dot(paper_hash_393_local_1_scattered, (paper_hash_393_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_393_local_3_folded = (paper_hash_393_local_1_scattered + float3(paper_hash_393_local_2_shift, paper_hash_393_local_2_shift, paper_hash_393_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_394_local_1_scattered = fract(((paper_noise_386_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_394_local_2_shift = dot(paper_hash_394_local_1_scattered, (paper_hash_394_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_394_local_3_folded = (paper_hash_394_local_1_scattered + float3(paper_hash_394_local_2_shift, paper_hash_394_local_2_shift, paper_hash_394_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_386_local_10_far_high = mix(fract(((paper_hash_393_local_3_folded.x + paper_hash_393_local_3_folded.y) * paper_hash_393_local_3_folded.z)), fract(((paper_hash_394_local_3_folded.x + paper_hash_394_local_3_folded.y) * paper_hash_394_local_3_folded.z)), paper_noise_386_local_4_u);
  // This numeric value has no quantity annotation.
  float3 cloth_height_395_local_1_q = ((relief_normal_217_local_5_along_point * 8.0f) + float3(0.5f, 0.5f, 0.5f));
  // This numeric value has no quantity annotation.
  float3 cloth_height_395_local_2_cell = floor(cloth_height_395_local_1_q);
  // This numeric value has no quantity annotation.
  float3 cloth_height_395_local_3_offset = fract(cloth_height_395_local_1_q);
  // This numeric value has no quantity annotation.
  float cloth_height_395_local_4_x = cloth_height_395_local_3_offset.x;
  // This numeric value has no quantity annotation.
  float cloth_height_395_local_5_y = cloth_height_395_local_3_offset.y;
  // This numeric value has no quantity annotation.
  float cloth_height_395_local_6_z = cloth_height_395_local_3_offset.z;
  // This numeric value has no quantity annotation.
  float cloth_height_395_local_7_over = (2.0f * fract((0.5f * ((cloth_height_395_local_2_cell.x + cloth_height_395_local_2_cell.y) + cloth_height_395_local_2_cell.z))));
  // This numeric value has no quantity annotation.
  float cloth_height_395_local_8_along_x = (((((4.0f * cloth_height_395_local_5_y) * (1.0f - cloth_height_395_local_5_y)) * ((4.0f * cloth_height_395_local_6_z) * (1.0f - cloth_height_395_local_6_z))) * (0.55f + (0.45f * ((4.0f * cloth_height_395_local_4_x) * (1.0f - cloth_height_395_local_4_x))))) * (0.7f + (0.3f * cloth_height_395_local_7_over)));
  // This numeric value has no quantity annotation.
  float cloth_height_395_local_9_along_y = (((((4.0f * cloth_height_395_local_4_x) * (1.0f - cloth_height_395_local_4_x)) * ((4.0f * cloth_height_395_local_6_z) * (1.0f - cloth_height_395_local_6_z))) * (0.55f + (0.45f * ((4.0f * cloth_height_395_local_5_y) * (1.0f - cloth_height_395_local_5_y))))) * (0.7f + (0.3f * (1.0f - cloth_height_395_local_7_over))));
  // This numeric value has no quantity annotation.
  float cloth_height_395_local_10_along_z = (((((4.0f * cloth_height_395_local_4_x) * (1.0f - cloth_height_395_local_4_x)) * ((4.0f * cloth_height_395_local_5_y) * (1.0f - cloth_height_395_local_5_y))) * (0.55f + (0.45f * ((4.0f * cloth_height_395_local_6_z) * (1.0f - cloth_height_395_local_6_z))))) * (0.7f + (0.3f * cloth_height_395_local_7_over)));
  // This numeric value has no quantity annotation.
  float fiber_height_408_local_1_u = (relief_normal_217_local_5_along_point.x + relief_normal_217_local_5_along_point.y);
  // This numeric value has no quantity annotation.
  float fiber_height_408_local_2_z = relief_normal_217_local_5_along_point.z;
  // This numeric value has no quantity annotation.
  float3 paper_noise_410_local_1_lattice = floor((relief_normal_217_local_5_along_point * float3(19.0f, 19.0f, 3.0f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_410_local_2_offset = fract((relief_normal_217_local_5_along_point * float3(19.0f, 19.0f, 3.0f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_410_local_3_weight = (paper_noise_410_local_2_offset * (paper_noise_410_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_410_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_410_local_4_u = paper_noise_410_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_410_local_5_v = paper_noise_410_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_410_local_6_w = paper_noise_410_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_411_local_1_scattered = fract((paper_noise_410_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_411_local_2_shift = dot(paper_hash_411_local_1_scattered, (paper_hash_411_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_411_local_3_folded = (paper_hash_411_local_1_scattered + float3(paper_hash_411_local_2_shift, paper_hash_411_local_2_shift, paper_hash_411_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_412_local_1_scattered = fract(((paper_noise_410_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_412_local_2_shift = dot(paper_hash_412_local_1_scattered, (paper_hash_412_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_412_local_3_folded = (paper_hash_412_local_1_scattered + float3(paper_hash_412_local_2_shift, paper_hash_412_local_2_shift, paper_hash_412_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_410_local_7_near_low = mix(fract(((paper_hash_411_local_3_folded.x + paper_hash_411_local_3_folded.y) * paper_hash_411_local_3_folded.z)), fract(((paper_hash_412_local_3_folded.x + paper_hash_412_local_3_folded.y) * paper_hash_412_local_3_folded.z)), paper_noise_410_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_413_local_1_scattered = fract(((paper_noise_410_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_413_local_2_shift = dot(paper_hash_413_local_1_scattered, (paper_hash_413_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_413_local_3_folded = (paper_hash_413_local_1_scattered + float3(paper_hash_413_local_2_shift, paper_hash_413_local_2_shift, paper_hash_413_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_414_local_1_scattered = fract(((paper_noise_410_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_414_local_2_shift = dot(paper_hash_414_local_1_scattered, (paper_hash_414_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_414_local_3_folded = (paper_hash_414_local_1_scattered + float3(paper_hash_414_local_2_shift, paper_hash_414_local_2_shift, paper_hash_414_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_410_local_8_near_high = mix(fract(((paper_hash_413_local_3_folded.x + paper_hash_413_local_3_folded.y) * paper_hash_413_local_3_folded.z)), fract(((paper_hash_414_local_3_folded.x + paper_hash_414_local_3_folded.y) * paper_hash_414_local_3_folded.z)), paper_noise_410_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_415_local_1_scattered = fract(((paper_noise_410_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_415_local_2_shift = dot(paper_hash_415_local_1_scattered, (paper_hash_415_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_415_local_3_folded = (paper_hash_415_local_1_scattered + float3(paper_hash_415_local_2_shift, paper_hash_415_local_2_shift, paper_hash_415_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_416_local_1_scattered = fract(((paper_noise_410_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_416_local_2_shift = dot(paper_hash_416_local_1_scattered, (paper_hash_416_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_416_local_3_folded = (paper_hash_416_local_1_scattered + float3(paper_hash_416_local_2_shift, paper_hash_416_local_2_shift, paper_hash_416_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_410_local_9_far_low = mix(fract(((paper_hash_415_local_3_folded.x + paper_hash_415_local_3_folded.y) * paper_hash_415_local_3_folded.z)), fract(((paper_hash_416_local_3_folded.x + paper_hash_416_local_3_folded.y) * paper_hash_416_local_3_folded.z)), paper_noise_410_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_417_local_1_scattered = fract(((paper_noise_410_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_417_local_2_shift = dot(paper_hash_417_local_1_scattered, (paper_hash_417_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_417_local_3_folded = (paper_hash_417_local_1_scattered + float3(paper_hash_417_local_2_shift, paper_hash_417_local_2_shift, paper_hash_417_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_418_local_1_scattered = fract(((paper_noise_410_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_418_local_2_shift = dot(paper_hash_418_local_1_scattered, (paper_hash_418_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_418_local_3_folded = (paper_hash_418_local_1_scattered + float3(paper_hash_418_local_2_shift, paper_hash_418_local_2_shift, paper_hash_418_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_410_local_10_far_high = mix(fract(((paper_hash_417_local_3_folded.x + paper_hash_417_local_3_folded.y) * paper_hash_417_local_3_folded.z)), fract(((paper_hash_418_local_3_folded.x + paper_hash_418_local_3_folded.y) * paper_hash_418_local_3_folded.z)), paper_noise_410_local_4_u);
  // This value is a difference-valued scalar, unitless and dimensionless.
  float surface_height_264_local_1_raw = ((relief < 0.5f) ? 0.5f : ((relief < 1.5f) ? ((0.6f * mix(mix(paper_noise_266_local_7_near_low, paper_noise_266_local_8_near_high, paper_noise_266_local_5_v), mix(paper_noise_266_local_9_far_low, paper_noise_266_local_10_far_high, paper_noise_266_local_5_v), paper_noise_266_local_6_w)) + (0.4f * mix(mix(paper_noise_275_local_7_near_low, paper_noise_275_local_8_near_high, paper_noise_275_local_5_v), mix(paper_noise_275_local_9_far_low, paper_noise_275_local_10_far_high, paper_noise_275_local_5_v), paper_noise_275_local_6_w))) : ((relief < 2.5f) ? (((0.55f * (1.0f - abs(((mix(mix(paper_noise_285_local_7_near_low, paper_noise_285_local_8_near_high, paper_noise_285_local_5_v), mix(paper_noise_285_local_9_far_low, paper_noise_285_local_10_far_high, paper_noise_285_local_5_v), paper_noise_285_local_6_w) * 2.0f) - 1.0f)))) + (0.3f * mix(mix(paper_noise_294_local_7_near_low, paper_noise_294_local_8_near_high, paper_noise_294_local_5_v), mix(paper_noise_294_local_9_far_low, paper_noise_294_local_10_far_high, paper_noise_294_local_5_v), paper_noise_294_local_6_w))) + (0.15f * mix(mix(paper_noise_303_local_7_near_low, paper_noise_303_local_8_near_high, paper_noise_303_local_5_v), mix(paper_noise_303_local_9_far_low, paper_noise_303_local_10_far_high, paper_noise_303_local_5_v), paper_noise_303_local_6_w))) : ((relief < 3.5f) ? ((0.7f * mix(mix(paper_noise_312_local_7_near_low, paper_noise_312_local_8_near_high, paper_noise_312_local_5_v), mix(paper_noise_312_local_9_far_low, paper_noise_312_local_10_far_high, paper_noise_312_local_5_v), paper_noise_312_local_6_w)) + (0.3f * mix(mix(paper_noise_321_local_7_near_low, paper_noise_321_local_8_near_high, paper_noise_321_local_5_v), mix(paper_noise_321_local_9_far_low, paper_noise_321_local_10_far_high, paper_noise_321_local_5_v), paper_noise_321_local_6_w))) : ((relief < 4.5f) ? (1.0f - abs(((mix(mix(paper_noise_331_local_7_near_low, paper_noise_331_local_8_near_high, paper_noise_331_local_5_v), mix(paper_noise_331_local_9_far_low, paper_noise_331_local_10_far_high, paper_noise_331_local_5_v), paper_noise_331_local_6_w) * 2.0f) - 1.0f))) : ((relief < 5.5f) ? ((0.65f * smoothstep(0.3f, 0.7f, mix(mix(paper_noise_340_local_7_near_low, paper_noise_340_local_8_near_high, paper_noise_340_local_5_v), mix(paper_noise_340_local_9_far_low, paper_noise_340_local_10_far_high, paper_noise_340_local_5_v), paper_noise_340_local_6_w))) + (0.35f * mix(mix(paper_noise_349_local_7_near_low, paper_noise_349_local_8_near_high, paper_noise_349_local_5_v), mix(paper_noise_349_local_9_far_low, paper_noise_349_local_10_far_high, paper_noise_349_local_5_v), paper_noise_349_local_6_w))) : ((relief < 6.5f) ? ((smoothstep(0.0f, 0.1f, plank_height_358_local_1_u) * (1.0f - smoothstep(0.9f, 1.0f, plank_height_358_local_1_u))) * (0.75f + (0.25f * mix(mix(paper_noise_359_local_7_near_low, paper_noise_359_local_8_near_high, paper_noise_359_local_5_v), mix(paper_noise_359_local_9_far_low, paper_noise_359_local_10_far_high, paper_noise_359_local_5_v), paper_noise_359_local_6_w)))) : ((relief < 7.5f) ? ((0.7f * mix(mix(paper_noise_368_local_7_near_low, paper_noise_368_local_8_near_high, paper_noise_368_local_5_v), mix(paper_noise_368_local_9_far_low, paper_noise_368_local_10_far_high, paper_noise_368_local_5_v), paper_noise_368_local_6_w)) + (0.3f * mix(mix(paper_noise_377_local_7_near_low, paper_noise_377_local_8_near_high, paper_noise_377_local_5_v), mix(paper_noise_377_local_9_far_low, paper_noise_377_local_10_far_high, paper_noise_377_local_5_v), paper_noise_377_local_6_w))) : ((relief < 8.5f) ? mix(mix(paper_noise_386_local_7_near_low, paper_noise_386_local_8_near_high, paper_noise_386_local_5_v), mix(paper_noise_386_local_9_far_low, paper_noise_386_local_10_far_high, paper_noise_386_local_5_v), paper_noise_386_local_6_w) : ((relief < 9.5f) ? (0.1f + (0.8f * max(cloth_height_395_local_8_along_x, max(cloth_height_395_local_9_along_y, cloth_height_395_local_10_along_z)))) : ((relief < 10.5f) ? ((0.7f * ((4.0f * fract(((fiber_height_408_local_1_u * 17.0f) + (fiber_height_408_local_2_z * 1.3f)))) * (1.0f - fract(((fiber_height_408_local_1_u * 17.0f) + (fiber_height_408_local_2_z * 1.3f)))))) + (0.3f * mix(mix(paper_noise_410_local_7_near_low, paper_noise_410_local_8_near_high, paper_noise_410_local_5_v), mix(paper_noise_410_local_9_far_low, paper_noise_410_local_10_far_high, paper_noise_410_local_5_v), paper_noise_410_local_6_w))) : ((relief < 11.5f) ? ((0.8f * ((4.0f * fract((fiber_height_408_local_1_u * 5.0f))) * (1.0f - fract((fiber_height_408_local_1_u * 5.0f))))) + (0.2f * step(0.85f, fract(((fiber_height_408_local_1_u * 13.0f) + (fiber_height_408_local_2_z * 7.0f)))))) : (0.45f + (0.1f * ((4.0f * fract((fiber_height_408_local_2_z * 24.0f))) * (1.0f - fract((fiber_height_408_local_2_z * 24.0f))))))))))))))))));
  // This numeric value has no quantity annotation.
  float surface_height_264_local_2_relief = ((relief > 8.5f) ? ((relief < 10.5f) ? mix(0.5f, surface_height_264_local_1_raw, nap_fade) : surface_height_264_local_1_raw) : surface_height_264_local_1_raw);
  // This numeric value has no quantity annotation.
  float surface_height_264_local_3_cut = ((((laid_pattern_220_local_1_shape < 0.5f) ? float4(1.0f, 0.5f, 1.0f, 0.0f) : ((laid_pattern_220_local_1_shape > 4.5f) ? ((face_laid_pattern_222_local_1_shape > 8.5f) ? ((face_laid_pattern_222_local_1_shape > 13.5f) ? float4(1.0f, mineral_pattern_224_local_2_ink, 0.0f, 0.0f) : ((face_laid_pattern_222_local_1_shape < 9.5f) ? float4((0.4f + (0.5f * motif_face_226_local_6_frame)), let_227_2_ink, motif_face_226_local_6_frame, 0.0f) : ((face_laid_pattern_222_local_1_shape < 10.5f) ? float4((0.35f + (0.55f * let_228_4_metal)), let_228_4_metal, 0.0f, 0.0f) : ((face_laid_pattern_222_local_1_shape < 11.5f) ? float4(0.85f, let_229_2_ink, smoothstep(0.43f, 0.47f, abs(motif_face_226_local_3_x)), 0.0f) : ((face_laid_pattern_222_local_1_shape < 12.5f) ? float4((0.9f - (let_230_1_band * 0.25f)), 0.0f, let_230_1_band, 0.0f) : float4((0.35f + (0.6f * motif_face_226_local_6_frame)), (face_laid_pattern_222_local_3_top ? (1.0f - motif_face_226_local_6_frame) : 0.0f), (face_laid_pattern_222_local_3_top ? motif_face_226_local_6_frame : 1.0f), 0.0f)))))) : (face_laid_pattern_222_local_3_top ? ((face_laid_pattern_222_local_1_shape < 5.5f) ? float4((1.0f - (0.7f * board_face_231_local_3_groove)), fract(((paper_hash_233_local_3_folded.x + paper_hash_233_local_3_folded.y) * paper_hash_233_local_3_folded.z)), 0.0f, (0.6f * board_face_231_local_3_groove)) : ((face_laid_pattern_222_local_1_shape < 7.5f) ? float4(1.0f, 0.5f, 1.0f, 0.0f) : float4(0.8f, 0.5f, 0.0f, 0.0f))) : ((face_laid_pattern_222_local_1_shape < 5.5f) ? float4(mix(mix(shelf_face_234_local_26_spine, 0.05f, shelf_face_234_local_24_recess), 1.0f, shelf_face_234_local_12_frame), (shelf_face_234_local_19_id + shelf_face_234_local_27_gilt), shelf_face_234_local_12_frame, shelf_face_234_local_24_recess) : ((face_laid_pattern_222_local_1_shape < 6.5f) ? float4(mix(0.2f, mix(mix(0.85f, 1.0f, window_face_241_local_4_frame), 0.45f, window_face_241_local_5_groove), window_face_241_local_9_bar), window_face_241_local_11_light, window_face_241_local_9_bar, window_face_241_local_5_groove) : ((face_laid_pattern_222_local_1_shape < 7.5f) ? float4(mix((0.35f + (0.2f * mix(mix(paper_noise_251_local_7_near_low, paper_noise_251_local_8_near_high, paper_noise_251_local_5_v), mix(paper_noise_251_local_9_far_low, paper_noise_251_local_10_far_high, paper_noise_251_local_5_v), paper_noise_251_local_6_w))), 0.95f, timbered_face_247_local_8_frame), 0.5f, timbered_face_247_local_8_frame, 0.0f) : float4(mix(mix(0.55f, 0.85f, panel_face_260_local_4_bevel), 0.95f, panel_face_260_local_3_frame), fract(((paper_hash_263_local_3_folded.x + paper_hash_263_local_3_folded.y) * paper_hash_263_local_3_folded.z)), panel_face_260_local_3_frame, 0.0f)))))) : float4(laid_pattern_220_local_26_mask, laid_pattern_220_local_28_hash, laid_pattern_220_local_27_ramp, laid_pattern_220_local_29_checked))).x * ((stage_in.material_pattern.x > 4.5f) ? 1.0f : ((laid_pattern_220_local_1_shape < 0.5f) ? float4(1.0f, 0.5f, 1.0f, 0.0f) : ((laid_pattern_220_local_1_shape > 4.5f) ? ((face_laid_pattern_222_local_1_shape > 8.5f) ? ((face_laid_pattern_222_local_1_shape > 13.5f) ? float4(1.0f, mineral_pattern_224_local_2_ink, 0.0f, 0.0f) : ((face_laid_pattern_222_local_1_shape < 9.5f) ? float4((0.4f + (0.5f * motif_face_226_local_6_frame)), let_227_2_ink, motif_face_226_local_6_frame, 0.0f) : ((face_laid_pattern_222_local_1_shape < 10.5f) ? float4((0.35f + (0.55f * let_228_4_metal)), let_228_4_metal, 0.0f, 0.0f) : ((face_laid_pattern_222_local_1_shape < 11.5f) ? float4(0.85f, let_229_2_ink, smoothstep(0.43f, 0.47f, abs(motif_face_226_local_3_x)), 0.0f) : ((face_laid_pattern_222_local_1_shape < 12.5f) ? float4((0.9f - (let_230_1_band * 0.25f)), 0.0f, let_230_1_band, 0.0f) : float4((0.35f + (0.6f * motif_face_226_local_6_frame)), (face_laid_pattern_222_local_3_top ? (1.0f - motif_face_226_local_6_frame) : 0.0f), (face_laid_pattern_222_local_3_top ? motif_face_226_local_6_frame : 1.0f), 0.0f)))))) : (face_laid_pattern_222_local_3_top ? ((face_laid_pattern_222_local_1_shape < 5.5f) ? float4((1.0f - (0.7f * board_face_231_local_3_groove)), fract(((paper_hash_233_local_3_folded.x + paper_hash_233_local_3_folded.y) * paper_hash_233_local_3_folded.z)), 0.0f, (0.6f * board_face_231_local_3_groove)) : ((face_laid_pattern_222_local_1_shape < 7.5f) ? float4(1.0f, 0.5f, 1.0f, 0.0f) : float4(0.8f, 0.5f, 0.0f, 0.0f))) : ((face_laid_pattern_222_local_1_shape < 5.5f) ? float4(mix(mix(shelf_face_234_local_26_spine, 0.05f, shelf_face_234_local_24_recess), 1.0f, shelf_face_234_local_12_frame), (shelf_face_234_local_19_id + shelf_face_234_local_27_gilt), shelf_face_234_local_12_frame, shelf_face_234_local_24_recess) : ((face_laid_pattern_222_local_1_shape < 6.5f) ? float4(mix(0.2f, mix(mix(0.85f, 1.0f, window_face_241_local_4_frame), 0.45f, window_face_241_local_5_groove), window_face_241_local_9_bar), window_face_241_local_11_light, window_face_241_local_9_bar, window_face_241_local_5_groove) : ((face_laid_pattern_222_local_1_shape < 7.5f) ? float4(mix((0.35f + (0.2f * mix(mix(paper_noise_251_local_7_near_low, paper_noise_251_local_8_near_high, paper_noise_251_local_5_v), mix(paper_noise_251_local_9_far_low, paper_noise_251_local_10_far_high, paper_noise_251_local_5_v), paper_noise_251_local_6_w))), 0.95f, timbered_face_247_local_8_frame), 0.5f, timbered_face_247_local_8_frame, 0.0f) : float4(mix(mix(0.55f, 0.85f, panel_face_260_local_4_bevel), 0.95f, panel_face_260_local_3_frame), fract(((paper_hash_263_local_3_folded.x + paper_hash_263_local_3_folded.y) * paper_hash_263_local_3_folded.z)), panel_face_260_local_3_frame, 0.0f)))))) : float4(laid_pattern_220_local_26_mask, laid_pattern_220_local_28_hash, laid_pattern_220_local_27_ramp, laid_pattern_220_local_29_checked))).z)) * (0.75f + (0.25f * surface_height_264_local_2_relief)));
  // This numeric value has no quantity annotation.
  float relief_normal_217_local_7_along = ((stage_in.material_pattern.x < 0.5f) ? surface_height_264_local_2_relief : mix(surface_height_264_local_2_relief, surface_height_264_local_3_cut, fade));
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_1_shape = stage_in.material_pattern.x;
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_2_courses = max(1.0f, stage_in.material_pattern.y);
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_3_aspect = max(0.5f, stage_in.material_pattern.z);
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_4_mortar = (0.5f * stage_in.material_pattern.w);
  // This numeric value has no quantity annotation.
  float3 laid_pattern_421_local_5_an = abs(normal);
  // This numeric value has no quantity annotation.
  bool laid_pattern_421_local_6_top = (laid_pattern_421_local_5_an.z > 0.7f);
  // This numeric value has no quantity annotation.
  bool laid_pattern_421_local_7_x_facing = (laid_pattern_421_local_5_an.x > laid_pattern_421_local_5_an.y);
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_8_u = (laid_pattern_421_local_6_top ? relief_normal_217_local_6_across_point.x : (laid_pattern_421_local_7_x_facing ? relief_normal_217_local_6_across_point.y : relief_normal_217_local_6_across_point.x));
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_9_v = (laid_pattern_421_local_6_top ? relief_normal_217_local_6_across_point.y : relief_normal_217_local_6_across_point.z);
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_10_w = (laid_pattern_421_local_6_top ? relief_normal_217_local_6_across_point.z : (laid_pattern_421_local_7_x_facing ? relief_normal_217_local_6_across_point.x : relief_normal_217_local_6_across_point.y));
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_11_rowf = (laid_pattern_421_local_9_v * laid_pattern_421_local_2_courses);
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_12_row = floor(laid_pattern_421_local_11_rowf);
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_13_fv = fract(laid_pattern_421_local_11_rowf);
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_14_parity = (2.0f * fract((laid_pattern_421_local_12_row * 0.5f)));
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_15_shift = ((laid_pattern_421_local_1_shape < 1.5f) ? (0.5f * laid_pattern_421_local_14_parity) : ((laid_pattern_421_local_1_shape > 2.5f) ? ((laid_pattern_421_local_1_shape < 3.5f) ? (0.5f * laid_pattern_421_local_14_parity) : 0.0f) : 0.0f));
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_16_uf = (((laid_pattern_421_local_8_u * laid_pattern_421_local_2_courses) / laid_pattern_421_local_3_aspect) + laid_pattern_421_local_15_shift);
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_17_col = floor(laid_pattern_421_local_16_uf);
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_18_fu = fract(laid_pattern_421_local_16_uf);
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_19_du = (laid_pattern_421_local_3_aspect * min(laid_pattern_421_local_18_fu, (1.0f - laid_pattern_421_local_18_fu)));
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_20_dv = min(laid_pattern_421_local_13_fv, (1.0f - laid_pattern_421_local_13_fv));
  // This value is a difference-valued scalar, unitless and dimensionless.
  float laid_pattern_421_local_21_bevel = 0.08f;
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_22_joint = smoothstep(laid_pattern_421_local_4_mortar, (laid_pattern_421_local_4_mortar + laid_pattern_421_local_21_bevel), laid_pattern_421_local_19_du);
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_23_bed = smoothstep(laid_pattern_421_local_4_mortar, (laid_pattern_421_local_4_mortar + laid_pattern_421_local_21_bevel), laid_pattern_421_local_20_dv);
  // This numeric value has no quantity annotation.
  bool laid_pattern_421_local_24_shingle = (laid_pattern_421_local_1_shape > 2.5f);
  // This numeric value has no quantity annotation.
  bool laid_pattern_421_local_25_checker = (laid_pattern_421_local_1_shape > 3.5f);
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_26_mask = (laid_pattern_421_local_25_checker ? (laid_pattern_421_local_22_joint * laid_pattern_421_local_23_bed) : (laid_pattern_421_local_24_shingle ? (laid_pattern_421_local_22_joint * smoothstep(0.0f, (laid_pattern_421_local_4_mortar + laid_pattern_421_local_21_bevel), laid_pattern_421_local_13_fv)) : (laid_pattern_421_local_22_joint * laid_pattern_421_local_23_bed)));
  // This value is a difference-valued scalar, unitless and dimensionless.
  float laid_pattern_421_local_27_ramp = (laid_pattern_421_local_25_checker ? 1.0f : (laid_pattern_421_local_24_shingle ? (1.0f - (0.5f * laid_pattern_421_local_13_fv)) : 1.0f));
  // This numeric value has no quantity annotation.
  float3 paper_hash_422_local_1_scattered = fract((float3(laid_pattern_421_local_17_col, laid_pattern_421_local_12_row, floor((laid_pattern_421_local_10_w + 0.5f))) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_422_local_2_shift = dot(paper_hash_422_local_1_scattered, (paper_hash_422_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_422_local_3_folded = (paper_hash_422_local_1_scattered + float3(paper_hash_422_local_2_shift, paper_hash_422_local_2_shift, paper_hash_422_local_2_shift));
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_28_hash = fract(((paper_hash_422_local_3_folded.x + paper_hash_422_local_3_folded.y) * paper_hash_422_local_3_folded.z));
  // This numeric value has no quantity annotation.
  float laid_pattern_421_local_29_checked = (2.0f * fract(((laid_pattern_421_local_12_row + laid_pattern_421_local_17_col) * 0.5f)));
  // This numeric value has no quantity annotation.
  float face_laid_pattern_423_local_1_shape = stage_in.material_pattern.x;
  // This numeric value has no quantity annotation.
  float3 face_coordinates_424_local_1_an = abs(normal);
  // This numeric value has no quantity annotation.
  bool face_coordinates_424_local_2_top = (face_coordinates_424_local_1_an.z > 0.7f);
  // This numeric value has no quantity annotation.
  bool face_coordinates_424_local_3_x_facing = (face_coordinates_424_local_1_an.x > face_coordinates_424_local_1_an.y);
  // This numeric value has no quantity annotation.
  float3 face_laid_pattern_423_local_2_face = float3((face_coordinates_424_local_2_top ? relief_normal_217_local_6_across_point.x : (face_coordinates_424_local_3_x_facing ? relief_normal_217_local_6_across_point.y : relief_normal_217_local_6_across_point.x)), (face_coordinates_424_local_2_top ? relief_normal_217_local_6_across_point.y : relief_normal_217_local_6_across_point.z), (face_coordinates_424_local_2_top ? relief_normal_217_local_6_across_point.z : (face_coordinates_424_local_3_x_facing ? relief_normal_217_local_6_across_point.x : relief_normal_217_local_6_across_point.y)));
  // This numeric value has no quantity annotation.
  bool face_laid_pattern_423_local_3_top = (abs(normal.z) > 0.7f);
  // This numeric value has no quantity annotation.
  float mineral_pattern_425_local_1_phase = (dot(relief_normal_217_local_6_across_point, float3(7.0f, 4.0f, 5.0f)) + (1.8f * sin(dot(relief_normal_217_local_6_across_point, float3(1.3f, 2.1f, 0.7f)))));
  // This numeric value has no quantity annotation.
  float3 paper_hash_426_local_1_scattered = fract((floor((relief_normal_217_local_6_across_point * (4.75f * stage_in.material_pattern.y))) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_426_local_2_shift = dot(paper_hash_426_local_1_scattered, (paper_hash_426_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_426_local_3_folded = (paper_hash_426_local_1_scattered + float3(paper_hash_426_local_2_shift, paper_hash_426_local_2_shift, paper_hash_426_local_2_shift));
  // This numeric value has no quantity annotation.
  float mineral_pattern_425_local_2_ink = ((stage_in.material_pattern.x < 14.5f) ? smoothstep(0.88f, 0.99f, sin(mineral_pattern_425_local_1_phase)) : step(0.85f, fract(((paper_hash_426_local_3_folded.x + paper_hash_426_local_3_folded.y) * paper_hash_426_local_3_folded.z))));
  // This numeric value has no quantity annotation.
  float2 motif_face_427_local_1_uv = fract(face_laid_pattern_423_local_2_face.xy);
  // This numeric value has no quantity annotation.
  float2 motif_face_427_local_2_q = (motif_face_427_local_1_uv - float2(0.5f, 0.5f));
  // This numeric value has no quantity annotation.
  float motif_face_427_local_3_x = motif_face_427_local_2_q.x;
  // This numeric value has no quantity annotation.
  float motif_face_427_local_4_y = motif_face_427_local_2_q.y;
  // This numeric value has no quantity annotation.
  float motif_face_427_local_5_edge = max(abs(motif_face_427_local_3_x), abs(motif_face_427_local_4_y));
  // This numeric value has no quantity annotation.
  float motif_face_427_local_6_frame = smoothstep(0.34f, 0.4f, motif_face_427_local_5_edge);
  // This numeric value has no quantity annotation.
  float motif_face_427_local_7_r2 = dot(motif_face_427_local_2_q, motif_face_427_local_2_q);
  // This numeric value has no quantity annotation.
  float let_428_1_row = floor((motif_face_427_local_1_uv.y * 12.0f));
  // This numeric value has no quantity annotation.
  float let_428_2_ink = ((((1.0f - motif_face_427_local_6_frame) * (face_laid_pattern_423_local_3_top ? 0.0f : 1.0f)) * step(0.35f, fract((motif_face_427_local_1_uv.y * 12.0f)))) * step(0.3f, fract(((motif_face_427_local_1_uv.x * 9.0f) + (let_428_1_row * 0.37f)))));
  // This numeric value has no quantity annotation.
  float let_429_1_hub = (1.0f - smoothstep(0.012f, 0.025f, motif_face_427_local_7_r2));
  // This numeric value has no quantity annotation.
  float let_429_2_rim = smoothstep(0.14f, 0.18f, motif_face_427_local_7_r2);
  // This numeric value has no quantity annotation.
  float let_429_3_spoke = (1.0f - smoothstep(0.035f, 0.065f, min(abs(motif_face_427_local_3_x), abs(motif_face_427_local_4_y))));
  // This numeric value has no quantity annotation.
  float let_429_4_metal = ((1.0f - smoothstep(0.18f, 0.2f, motif_face_427_local_7_r2)) * max(let_429_1_hub, max(let_429_2_rim, let_429_3_spoke)));
  // This numeric value has no quantity annotation.
  float let_430_1_diamond = (abs(motif_face_427_local_3_x) + abs(motif_face_427_local_4_y));
  // This numeric value has no quantity annotation.
  float let_430_2_ink = (smoothstep(0.18f, 0.23f, let_430_1_diamond) * (1.0f - smoothstep(0.34f, 0.39f, let_430_1_diamond)));
  // This numeric value has no quantity annotation.
  float let_431_1_band = (1.0f - smoothstep(0.035f, 0.065f, abs((abs(motif_face_427_local_3_x) - 0.25f))));
  // This numeric value has no quantity annotation.
  float board_face_432_local_1_rowf = (face_laid_pattern_423_local_2_face.y * 4.0f);
  // This numeric value has no quantity annotation.
  float board_face_432_local_2_fv = fract(board_face_432_local_1_rowf);
  // This numeric value has no quantity annotation.
  float board_face_432_local_3_groove = (1.0f - smoothstep(0.03f, (0.03f + 0.03f), min(board_face_432_local_2_fv, (1.0f - board_face_432_local_2_fv))));
  // This numeric value has no quantity annotation.
  float3 paper_hash_434_local_1_scattered = fract((float3(floor(board_face_432_local_1_rowf), floor((face_laid_pattern_423_local_2_face.z + 0.5f)), 3.0f) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_434_local_2_shift = dot(paper_hash_434_local_1_scattered, (paper_hash_434_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_434_local_3_folded = (paper_hash_434_local_1_scattered + float3(paper_hash_434_local_2_shift, paper_hash_434_local_2_shift, paper_hash_434_local_2_shift));
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_1_rows = max(1.0f, stage_in.material_pattern.y);
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_2_books = (shelf_face_435_local_1_rows * max(0.5f, stage_in.material_pattern.z));
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_3_board = stage_in.material_pattern.w;
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_4_u = face_laid_pattern_423_local_2_face.x;
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_5_depth = floor((face_laid_pattern_423_local_2_face.z + 0.5f));
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_6_rowf = (face_laid_pattern_423_local_2_face.y * shelf_face_435_local_1_rows);
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_7_row = floor(shelf_face_435_local_6_rowf);
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_8_fv = fract(shelf_face_435_local_6_rowf);
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_9_cell_u = fract(shelf_face_435_local_4_u);
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_10_upright = (1.0f - smoothstep(0.03f, (0.03f + 0.015f), min(shelf_face_435_local_9_cell_u, (1.0f - shelf_face_435_local_9_cell_u))));
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_11_shelf = max((1.0f - smoothstep(shelf_face_435_local_3_board, (shelf_face_435_local_3_board + 0.04f), shelf_face_435_local_8_fv)), (1.0f - smoothstep((0.4f * shelf_face_435_local_3_board), ((0.4f * shelf_face_435_local_3_board) + 0.04f), (1.0f - shelf_face_435_local_8_fv))));
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_12_frame = max(shelf_face_435_local_10_upright, shelf_face_435_local_11_shelf);
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_13_slotf = (shelf_face_435_local_4_u * shelf_face_435_local_2_books);
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_14_slot = floor(shelf_face_435_local_13_slotf);
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_15_fs = fract(shelf_face_435_local_13_slotf);
  // This numeric value has no quantity annotation.
  float3 paper_hash_439_local_1_scattered = fract((float3(shelf_face_435_local_14_slot, shelf_face_435_local_7_row, (shelf_face_435_local_5_depth + 17.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_439_local_2_shift = dot(paper_hash_439_local_1_scattered, (paper_hash_439_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_439_local_3_folded = (paper_hash_439_local_1_scattered + float3(paper_hash_439_local_2_shift, paper_hash_439_local_2_shift, paper_hash_439_local_2_shift));
  // This value is a difference-valued scalar, unitless and dimensionless.
  float shelf_face_435_local_16_pair = ((fract(((paper_hash_439_local_3_folded.x + paper_hash_439_local_3_folded.y) * paper_hash_439_local_3_folded.z)) < 0.35f) ? 2.0f : 1.0f);
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_17_sub = floor((shelf_face_435_local_15_fs * shelf_face_435_local_16_pair));
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_18_fb = fract((shelf_face_435_local_15_fs * shelf_face_435_local_16_pair));
  // This numeric value has no quantity annotation.
  float3 paper_hash_440_local_1_scattered = fract((float3(((shelf_face_435_local_14_slot * 2.0f) + shelf_face_435_local_17_sub), shelf_face_435_local_7_row, shelf_face_435_local_5_depth) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_440_local_2_shift = dot(paper_hash_440_local_1_scattered, (paper_hash_440_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_440_local_3_folded = (paper_hash_440_local_1_scattered + float3(paper_hash_440_local_2_shift, paper_hash_440_local_2_shift, paper_hash_440_local_2_shift));
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_19_id = fract(((paper_hash_440_local_3_folded.x + paper_hash_440_local_3_folded.y) * paper_hash_440_local_3_folded.z));
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_20_clear = ((shelf_face_435_local_8_fv - shelf_face_435_local_3_board) / (1.0f - (1.4f * shelf_face_435_local_3_board)));
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_21_crown = (0.55f + (0.4f * fract((shelf_face_435_local_19_id * 13.7f))));
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_22_above = smoothstep((shelf_face_435_local_21_crown - 0.02f), (shelf_face_435_local_21_crown + 0.02f), shelf_face_435_local_20_clear);
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_23_seam = (1.0f - smoothstep(0.004f, (0.004f + 0.004f), (min(shelf_face_435_local_18_fb, (1.0f - shelf_face_435_local_18_fb)) / (shelf_face_435_local_2_books * shelf_face_435_local_16_pair))));
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_24_recess = ((1.0f - shelf_face_435_local_12_frame) * max(shelf_face_435_local_22_above, shelf_face_435_local_23_seam));
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_25_across = ((2.0f * shelf_face_435_local_18_fb) - 1.0f);
  // This numeric value has no quantity annotation.
  float shelf_face_435_local_26_spine = (0.55f + (0.2f * (1.0f - (shelf_face_435_local_25_across * shelf_face_435_local_25_across))));
  // This value is a difference-valued scalar, unitless and dimensionless.
  float shelf_face_435_local_27_gilt = ((abs((shelf_face_435_local_20_clear - (0.82f * shelf_face_435_local_21_crown))) < 0.025f) ? ((fract((shelf_face_435_local_19_id * 5.3f)) > 0.4f) ? 1.0f : 0.0f) : 0.0f);
  // This numeric value has no quantity annotation.
  float window_face_442_local_1_panes = max(1.0f, stage_in.material_pattern.y);
  // This numeric value has no quantity annotation.
  float window_face_442_local_2_width = stage_in.material_pattern.w;
  // This numeric value has no quantity annotation.
  float cell_edge_distance_443_local_1_fu = fract(face_laid_pattern_423_local_2_face.x);
  // This numeric value has no quantity annotation.
  float cell_edge_distance_443_local_2_fv = fract(face_laid_pattern_423_local_2_face.y);
  // This numeric value has no quantity annotation.
  float window_face_442_local_3_edge = min(min(cell_edge_distance_443_local_1_fu, (1.0f - cell_edge_distance_443_local_1_fu)), min(cell_edge_distance_443_local_2_fv, (1.0f - cell_edge_distance_443_local_2_fv)));
  // This numeric value has no quantity annotation.
  float window_face_442_local_4_frame = (1.0f - smoothstep(window_face_442_local_2_width, (window_face_442_local_2_width + 0.012f), window_face_442_local_3_edge));
  // This numeric value has no quantity annotation.
  float window_face_442_local_5_groove = (window_face_442_local_4_frame * (1.0f - smoothstep(0.01f, (0.01f + 0.008f), abs((window_face_442_local_3_edge - (0.5f * window_face_442_local_2_width))))));
  // This numeric value has no quantity annotation.
  float window_face_442_local_6_pu = fract((face_laid_pattern_423_local_2_face.x * window_face_442_local_1_panes));
  // This numeric value has no quantity annotation.
  float window_face_442_local_7_pv = fract((face_laid_pattern_423_local_2_face.y * window_face_442_local_1_panes));
  // This numeric value has no quantity annotation.
  float window_face_442_local_8_mullion = (1.0f - smoothstep(0.02f, (0.02f + 0.01f), (min(min(window_face_442_local_6_pu, (1.0f - window_face_442_local_6_pu)), min(window_face_442_local_7_pv, (1.0f - window_face_442_local_7_pv))) / window_face_442_local_1_panes)));
  // This numeric value has no quantity annotation.
  float window_face_442_local_9_bar = max(window_face_442_local_4_frame, window_face_442_local_8_mullion);
  // This numeric value has no quantity annotation.
  float3 paper_hash_447_local_1_scattered = fract((float3(floor((face_laid_pattern_423_local_2_face.x * window_face_442_local_1_panes)), floor((face_laid_pattern_423_local_2_face.y * window_face_442_local_1_panes)), (floor((face_laid_pattern_423_local_2_face.z + 0.5f)) + 5.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_447_local_2_shift = dot(paper_hash_447_local_1_scattered, (paper_hash_447_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_447_local_3_folded = (paper_hash_447_local_1_scattered + float3(paper_hash_447_local_2_shift, paper_hash_447_local_2_shift, paper_hash_447_local_2_shift));
  // This numeric value has no quantity annotation.
  float window_face_442_local_10_lamp = fract(((paper_hash_447_local_3_folded.x + paper_hash_447_local_3_folded.y) * paper_hash_447_local_3_folded.z));
  // This numeric value has no quantity annotation.
  float window_face_442_local_11_light = clamp(((0.3f + (0.5f * (1.0f - window_face_442_local_7_pv))) + (0.4f * (window_face_442_local_10_lamp - 0.5f))), 0.0f, 1.0f);
  // This numeric value has no quantity annotation.
  float timbered_face_448_local_1_width = (0.5f * stage_in.material_pattern.w);
  // This numeric value has no quantity annotation.
  float timbered_face_448_local_2_fu = fract(face_laid_pattern_423_local_2_face.x);
  // This numeric value has no quantity annotation.
  float timbered_face_448_local_3_fv = fract(face_laid_pattern_423_local_2_face.y);
  // This numeric value has no quantity annotation.
  float cell_edge_distance_449_local_1_fu = fract(face_laid_pattern_423_local_2_face.x);
  // This numeric value has no quantity annotation.
  float cell_edge_distance_449_local_2_fv = fract(face_laid_pattern_423_local_2_face.y);
  // This numeric value has no quantity annotation.
  float timbered_face_448_local_4_post = (1.0f - smoothstep(timbered_face_448_local_1_width, (timbered_face_448_local_1_width + 0.015f), min(min(cell_edge_distance_449_local_1_fu, (1.0f - cell_edge_distance_449_local_1_fu)), min(cell_edge_distance_449_local_2_fv, (1.0f - cell_edge_distance_449_local_2_fv)))));
  // This numeric value has no quantity annotation.
  float timbered_face_448_local_5_parity = fract((0.5f * (floor(face_laid_pattern_423_local_2_face.x) + floor(face_laid_pattern_423_local_2_face.y))));
  // This numeric value has no quantity annotation.
  float timbered_face_448_local_6_diagonal = ((timbered_face_448_local_5_parity > 0.25f) ? abs((timbered_face_448_local_2_fu - timbered_face_448_local_3_fv)) : abs(((timbered_face_448_local_2_fu + timbered_face_448_local_3_fv) - 1.0f)));
  // This numeric value has no quantity annotation.
  float timbered_face_448_local_7_brace = (1.0f - smoothstep(timbered_face_448_local_1_width, (timbered_face_448_local_1_width + 0.015f), (0.7071f * timbered_face_448_local_6_diagonal)));
  // This numeric value has no quantity annotation.
  float timbered_face_448_local_8_frame = max(timbered_face_448_local_4_post, timbered_face_448_local_7_brace);
  // This numeric value has no quantity annotation.
  float3 paper_noise_452_local_1_lattice = floor((face_laid_pattern_423_local_2_face * 7.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_452_local_2_offset = fract((face_laid_pattern_423_local_2_face * 7.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_452_local_3_weight = (paper_noise_452_local_2_offset * (paper_noise_452_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_452_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_452_local_4_u = paper_noise_452_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_452_local_5_v = paper_noise_452_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_452_local_6_w = paper_noise_452_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_453_local_1_scattered = fract((paper_noise_452_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_453_local_2_shift = dot(paper_hash_453_local_1_scattered, (paper_hash_453_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_453_local_3_folded = (paper_hash_453_local_1_scattered + float3(paper_hash_453_local_2_shift, paper_hash_453_local_2_shift, paper_hash_453_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_454_local_1_scattered = fract(((paper_noise_452_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_454_local_2_shift = dot(paper_hash_454_local_1_scattered, (paper_hash_454_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_454_local_3_folded = (paper_hash_454_local_1_scattered + float3(paper_hash_454_local_2_shift, paper_hash_454_local_2_shift, paper_hash_454_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_452_local_7_near_low = mix(fract(((paper_hash_453_local_3_folded.x + paper_hash_453_local_3_folded.y) * paper_hash_453_local_3_folded.z)), fract(((paper_hash_454_local_3_folded.x + paper_hash_454_local_3_folded.y) * paper_hash_454_local_3_folded.z)), paper_noise_452_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_455_local_1_scattered = fract(((paper_noise_452_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_455_local_2_shift = dot(paper_hash_455_local_1_scattered, (paper_hash_455_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_455_local_3_folded = (paper_hash_455_local_1_scattered + float3(paper_hash_455_local_2_shift, paper_hash_455_local_2_shift, paper_hash_455_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_456_local_1_scattered = fract(((paper_noise_452_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_456_local_2_shift = dot(paper_hash_456_local_1_scattered, (paper_hash_456_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_456_local_3_folded = (paper_hash_456_local_1_scattered + float3(paper_hash_456_local_2_shift, paper_hash_456_local_2_shift, paper_hash_456_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_452_local_8_near_high = mix(fract(((paper_hash_455_local_3_folded.x + paper_hash_455_local_3_folded.y) * paper_hash_455_local_3_folded.z)), fract(((paper_hash_456_local_3_folded.x + paper_hash_456_local_3_folded.y) * paper_hash_456_local_3_folded.z)), paper_noise_452_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_457_local_1_scattered = fract(((paper_noise_452_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_457_local_2_shift = dot(paper_hash_457_local_1_scattered, (paper_hash_457_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_457_local_3_folded = (paper_hash_457_local_1_scattered + float3(paper_hash_457_local_2_shift, paper_hash_457_local_2_shift, paper_hash_457_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_458_local_1_scattered = fract(((paper_noise_452_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_458_local_2_shift = dot(paper_hash_458_local_1_scattered, (paper_hash_458_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_458_local_3_folded = (paper_hash_458_local_1_scattered + float3(paper_hash_458_local_2_shift, paper_hash_458_local_2_shift, paper_hash_458_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_452_local_9_far_low = mix(fract(((paper_hash_457_local_3_folded.x + paper_hash_457_local_3_folded.y) * paper_hash_457_local_3_folded.z)), fract(((paper_hash_458_local_3_folded.x + paper_hash_458_local_3_folded.y) * paper_hash_458_local_3_folded.z)), paper_noise_452_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_459_local_1_scattered = fract(((paper_noise_452_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_459_local_2_shift = dot(paper_hash_459_local_1_scattered, (paper_hash_459_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_459_local_3_folded = (paper_hash_459_local_1_scattered + float3(paper_hash_459_local_2_shift, paper_hash_459_local_2_shift, paper_hash_459_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_460_local_1_scattered = fract(((paper_noise_452_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_460_local_2_shift = dot(paper_hash_460_local_1_scattered, (paper_hash_460_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_460_local_3_folded = (paper_hash_460_local_1_scattered + float3(paper_hash_460_local_2_shift, paper_hash_460_local_2_shift, paper_hash_460_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_452_local_10_far_high = mix(fract(((paper_hash_459_local_3_folded.x + paper_hash_459_local_3_folded.y) * paper_hash_459_local_3_folded.z)), fract(((paper_hash_460_local_3_folded.x + paper_hash_460_local_3_folded.y) * paper_hash_460_local_3_folded.z)), paper_noise_452_local_4_u);
  // This numeric value has no quantity annotation.
  float panel_face_461_local_1_width = stage_in.material_pattern.w;
  // This numeric value has no quantity annotation.
  float cell_edge_distance_462_local_1_fu = fract(face_laid_pattern_423_local_2_face.x);
  // This numeric value has no quantity annotation.
  float cell_edge_distance_462_local_2_fv = fract(face_laid_pattern_423_local_2_face.y);
  // This numeric value has no quantity annotation.
  float panel_face_461_local_2_edge = min(min(cell_edge_distance_462_local_1_fu, (1.0f - cell_edge_distance_462_local_1_fu)), min(cell_edge_distance_462_local_2_fv, (1.0f - cell_edge_distance_462_local_2_fv)));
  // This numeric value has no quantity annotation.
  float panel_face_461_local_3_frame = (1.0f - smoothstep(panel_face_461_local_1_width, (panel_face_461_local_1_width + 0.03f), panel_face_461_local_2_edge));
  // This numeric value has no quantity annotation.
  float panel_face_461_local_4_bevel = smoothstep(panel_face_461_local_1_width, (panel_face_461_local_1_width + 0.12f), panel_face_461_local_2_edge);
  // This numeric value has no quantity annotation.
  float3 paper_hash_464_local_1_scattered = fract((float3(floor(face_laid_pattern_423_local_2_face.x), floor(face_laid_pattern_423_local_2_face.y), floor((face_laid_pattern_423_local_2_face.z + 0.5f))) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_464_local_2_shift = dot(paper_hash_464_local_1_scattered, (paper_hash_464_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_464_local_3_folded = (paper_hash_464_local_1_scattered + float3(paper_hash_464_local_2_shift, paper_hash_464_local_2_shift, paper_hash_464_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_noise_467_local_1_lattice = floor((relief_normal_217_local_6_across_point * 4.7f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_467_local_2_offset = fract((relief_normal_217_local_6_across_point * 4.7f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_467_local_3_weight = (paper_noise_467_local_2_offset * (paper_noise_467_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_467_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_467_local_4_u = paper_noise_467_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_467_local_5_v = paper_noise_467_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_467_local_6_w = paper_noise_467_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_468_local_1_scattered = fract((paper_noise_467_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_468_local_2_shift = dot(paper_hash_468_local_1_scattered, (paper_hash_468_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_468_local_3_folded = (paper_hash_468_local_1_scattered + float3(paper_hash_468_local_2_shift, paper_hash_468_local_2_shift, paper_hash_468_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_469_local_1_scattered = fract(((paper_noise_467_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_469_local_2_shift = dot(paper_hash_469_local_1_scattered, (paper_hash_469_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_469_local_3_folded = (paper_hash_469_local_1_scattered + float3(paper_hash_469_local_2_shift, paper_hash_469_local_2_shift, paper_hash_469_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_467_local_7_near_low = mix(fract(((paper_hash_468_local_3_folded.x + paper_hash_468_local_3_folded.y) * paper_hash_468_local_3_folded.z)), fract(((paper_hash_469_local_3_folded.x + paper_hash_469_local_3_folded.y) * paper_hash_469_local_3_folded.z)), paper_noise_467_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_470_local_1_scattered = fract(((paper_noise_467_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_470_local_2_shift = dot(paper_hash_470_local_1_scattered, (paper_hash_470_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_470_local_3_folded = (paper_hash_470_local_1_scattered + float3(paper_hash_470_local_2_shift, paper_hash_470_local_2_shift, paper_hash_470_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_471_local_1_scattered = fract(((paper_noise_467_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_471_local_2_shift = dot(paper_hash_471_local_1_scattered, (paper_hash_471_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_471_local_3_folded = (paper_hash_471_local_1_scattered + float3(paper_hash_471_local_2_shift, paper_hash_471_local_2_shift, paper_hash_471_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_467_local_8_near_high = mix(fract(((paper_hash_470_local_3_folded.x + paper_hash_470_local_3_folded.y) * paper_hash_470_local_3_folded.z)), fract(((paper_hash_471_local_3_folded.x + paper_hash_471_local_3_folded.y) * paper_hash_471_local_3_folded.z)), paper_noise_467_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_472_local_1_scattered = fract(((paper_noise_467_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_472_local_2_shift = dot(paper_hash_472_local_1_scattered, (paper_hash_472_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_472_local_3_folded = (paper_hash_472_local_1_scattered + float3(paper_hash_472_local_2_shift, paper_hash_472_local_2_shift, paper_hash_472_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_473_local_1_scattered = fract(((paper_noise_467_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_473_local_2_shift = dot(paper_hash_473_local_1_scattered, (paper_hash_473_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_473_local_3_folded = (paper_hash_473_local_1_scattered + float3(paper_hash_473_local_2_shift, paper_hash_473_local_2_shift, paper_hash_473_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_467_local_9_far_low = mix(fract(((paper_hash_472_local_3_folded.x + paper_hash_472_local_3_folded.y) * paper_hash_472_local_3_folded.z)), fract(((paper_hash_473_local_3_folded.x + paper_hash_473_local_3_folded.y) * paper_hash_473_local_3_folded.z)), paper_noise_467_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_474_local_1_scattered = fract(((paper_noise_467_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_474_local_2_shift = dot(paper_hash_474_local_1_scattered, (paper_hash_474_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_474_local_3_folded = (paper_hash_474_local_1_scattered + float3(paper_hash_474_local_2_shift, paper_hash_474_local_2_shift, paper_hash_474_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_475_local_1_scattered = fract(((paper_noise_467_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_475_local_2_shift = dot(paper_hash_475_local_1_scattered, (paper_hash_475_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_475_local_3_folded = (paper_hash_475_local_1_scattered + float3(paper_hash_475_local_2_shift, paper_hash_475_local_2_shift, paper_hash_475_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_467_local_10_far_high = mix(fract(((paper_hash_474_local_3_folded.x + paper_hash_474_local_3_folded.y) * paper_hash_474_local_3_folded.z)), fract(((paper_hash_475_local_3_folded.x + paper_hash_475_local_3_folded.y) * paper_hash_475_local_3_folded.z)), paper_noise_467_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_476_local_1_lattice = floor((relief_normal_217_local_6_across_point * 13.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_476_local_2_offset = fract((relief_normal_217_local_6_across_point * 13.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_476_local_3_weight = (paper_noise_476_local_2_offset * (paper_noise_476_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_476_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_476_local_4_u = paper_noise_476_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_476_local_5_v = paper_noise_476_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_476_local_6_w = paper_noise_476_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_477_local_1_scattered = fract((paper_noise_476_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_477_local_2_shift = dot(paper_hash_477_local_1_scattered, (paper_hash_477_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_477_local_3_folded = (paper_hash_477_local_1_scattered + float3(paper_hash_477_local_2_shift, paper_hash_477_local_2_shift, paper_hash_477_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_478_local_1_scattered = fract(((paper_noise_476_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_478_local_2_shift = dot(paper_hash_478_local_1_scattered, (paper_hash_478_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_478_local_3_folded = (paper_hash_478_local_1_scattered + float3(paper_hash_478_local_2_shift, paper_hash_478_local_2_shift, paper_hash_478_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_476_local_7_near_low = mix(fract(((paper_hash_477_local_3_folded.x + paper_hash_477_local_3_folded.y) * paper_hash_477_local_3_folded.z)), fract(((paper_hash_478_local_3_folded.x + paper_hash_478_local_3_folded.y) * paper_hash_478_local_3_folded.z)), paper_noise_476_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_479_local_1_scattered = fract(((paper_noise_476_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_479_local_2_shift = dot(paper_hash_479_local_1_scattered, (paper_hash_479_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_479_local_3_folded = (paper_hash_479_local_1_scattered + float3(paper_hash_479_local_2_shift, paper_hash_479_local_2_shift, paper_hash_479_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_480_local_1_scattered = fract(((paper_noise_476_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_480_local_2_shift = dot(paper_hash_480_local_1_scattered, (paper_hash_480_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_480_local_3_folded = (paper_hash_480_local_1_scattered + float3(paper_hash_480_local_2_shift, paper_hash_480_local_2_shift, paper_hash_480_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_476_local_8_near_high = mix(fract(((paper_hash_479_local_3_folded.x + paper_hash_479_local_3_folded.y) * paper_hash_479_local_3_folded.z)), fract(((paper_hash_480_local_3_folded.x + paper_hash_480_local_3_folded.y) * paper_hash_480_local_3_folded.z)), paper_noise_476_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_481_local_1_scattered = fract(((paper_noise_476_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_481_local_2_shift = dot(paper_hash_481_local_1_scattered, (paper_hash_481_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_481_local_3_folded = (paper_hash_481_local_1_scattered + float3(paper_hash_481_local_2_shift, paper_hash_481_local_2_shift, paper_hash_481_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_482_local_1_scattered = fract(((paper_noise_476_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_482_local_2_shift = dot(paper_hash_482_local_1_scattered, (paper_hash_482_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_482_local_3_folded = (paper_hash_482_local_1_scattered + float3(paper_hash_482_local_2_shift, paper_hash_482_local_2_shift, paper_hash_482_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_476_local_9_far_low = mix(fract(((paper_hash_481_local_3_folded.x + paper_hash_481_local_3_folded.y) * paper_hash_481_local_3_folded.z)), fract(((paper_hash_482_local_3_folded.x + paper_hash_482_local_3_folded.y) * paper_hash_482_local_3_folded.z)), paper_noise_476_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_483_local_1_scattered = fract(((paper_noise_476_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_483_local_2_shift = dot(paper_hash_483_local_1_scattered, (paper_hash_483_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_483_local_3_folded = (paper_hash_483_local_1_scattered + float3(paper_hash_483_local_2_shift, paper_hash_483_local_2_shift, paper_hash_483_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_484_local_1_scattered = fract(((paper_noise_476_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_484_local_2_shift = dot(paper_hash_484_local_1_scattered, (paper_hash_484_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_484_local_3_folded = (paper_hash_484_local_1_scattered + float3(paper_hash_484_local_2_shift, paper_hash_484_local_2_shift, paper_hash_484_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_476_local_10_far_high = mix(fract(((paper_hash_483_local_3_folded.x + paper_hash_483_local_3_folded.y) * paper_hash_483_local_3_folded.z)), fract(((paper_hash_484_local_3_folded.x + paper_hash_484_local_3_folded.y) * paper_hash_484_local_3_folded.z)), paper_noise_476_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_486_local_1_lattice = floor((relief_normal_217_local_6_across_point * 1.9f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_486_local_2_offset = fract((relief_normal_217_local_6_across_point * 1.9f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_486_local_3_weight = (paper_noise_486_local_2_offset * (paper_noise_486_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_486_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_486_local_4_u = paper_noise_486_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_486_local_5_v = paper_noise_486_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_486_local_6_w = paper_noise_486_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_487_local_1_scattered = fract((paper_noise_486_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_487_local_2_shift = dot(paper_hash_487_local_1_scattered, (paper_hash_487_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_487_local_3_folded = (paper_hash_487_local_1_scattered + float3(paper_hash_487_local_2_shift, paper_hash_487_local_2_shift, paper_hash_487_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_488_local_1_scattered = fract(((paper_noise_486_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_488_local_2_shift = dot(paper_hash_488_local_1_scattered, (paper_hash_488_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_488_local_3_folded = (paper_hash_488_local_1_scattered + float3(paper_hash_488_local_2_shift, paper_hash_488_local_2_shift, paper_hash_488_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_486_local_7_near_low = mix(fract(((paper_hash_487_local_3_folded.x + paper_hash_487_local_3_folded.y) * paper_hash_487_local_3_folded.z)), fract(((paper_hash_488_local_3_folded.x + paper_hash_488_local_3_folded.y) * paper_hash_488_local_3_folded.z)), paper_noise_486_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_489_local_1_scattered = fract(((paper_noise_486_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_489_local_2_shift = dot(paper_hash_489_local_1_scattered, (paper_hash_489_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_489_local_3_folded = (paper_hash_489_local_1_scattered + float3(paper_hash_489_local_2_shift, paper_hash_489_local_2_shift, paper_hash_489_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_490_local_1_scattered = fract(((paper_noise_486_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_490_local_2_shift = dot(paper_hash_490_local_1_scattered, (paper_hash_490_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_490_local_3_folded = (paper_hash_490_local_1_scattered + float3(paper_hash_490_local_2_shift, paper_hash_490_local_2_shift, paper_hash_490_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_486_local_8_near_high = mix(fract(((paper_hash_489_local_3_folded.x + paper_hash_489_local_3_folded.y) * paper_hash_489_local_3_folded.z)), fract(((paper_hash_490_local_3_folded.x + paper_hash_490_local_3_folded.y) * paper_hash_490_local_3_folded.z)), paper_noise_486_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_491_local_1_scattered = fract(((paper_noise_486_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_491_local_2_shift = dot(paper_hash_491_local_1_scattered, (paper_hash_491_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_491_local_3_folded = (paper_hash_491_local_1_scattered + float3(paper_hash_491_local_2_shift, paper_hash_491_local_2_shift, paper_hash_491_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_492_local_1_scattered = fract(((paper_noise_486_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_492_local_2_shift = dot(paper_hash_492_local_1_scattered, (paper_hash_492_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_492_local_3_folded = (paper_hash_492_local_1_scattered + float3(paper_hash_492_local_2_shift, paper_hash_492_local_2_shift, paper_hash_492_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_486_local_9_far_low = mix(fract(((paper_hash_491_local_3_folded.x + paper_hash_491_local_3_folded.y) * paper_hash_491_local_3_folded.z)), fract(((paper_hash_492_local_3_folded.x + paper_hash_492_local_3_folded.y) * paper_hash_492_local_3_folded.z)), paper_noise_486_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_493_local_1_scattered = fract(((paper_noise_486_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_493_local_2_shift = dot(paper_hash_493_local_1_scattered, (paper_hash_493_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_493_local_3_folded = (paper_hash_493_local_1_scattered + float3(paper_hash_493_local_2_shift, paper_hash_493_local_2_shift, paper_hash_493_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_494_local_1_scattered = fract(((paper_noise_486_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_494_local_2_shift = dot(paper_hash_494_local_1_scattered, (paper_hash_494_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_494_local_3_folded = (paper_hash_494_local_1_scattered + float3(paper_hash_494_local_2_shift, paper_hash_494_local_2_shift, paper_hash_494_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_486_local_10_far_high = mix(fract(((paper_hash_493_local_3_folded.x + paper_hash_493_local_3_folded.y) * paper_hash_493_local_3_folded.z)), fract(((paper_hash_494_local_3_folded.x + paper_hash_494_local_3_folded.y) * paper_hash_494_local_3_folded.z)), paper_noise_486_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_495_local_1_lattice = floor((relief_normal_217_local_6_across_point * 0.7f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_495_local_2_offset = fract((relief_normal_217_local_6_across_point * 0.7f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_495_local_3_weight = (paper_noise_495_local_2_offset * (paper_noise_495_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_495_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_495_local_4_u = paper_noise_495_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_495_local_5_v = paper_noise_495_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_495_local_6_w = paper_noise_495_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_496_local_1_scattered = fract((paper_noise_495_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_496_local_2_shift = dot(paper_hash_496_local_1_scattered, (paper_hash_496_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_496_local_3_folded = (paper_hash_496_local_1_scattered + float3(paper_hash_496_local_2_shift, paper_hash_496_local_2_shift, paper_hash_496_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_497_local_1_scattered = fract(((paper_noise_495_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_497_local_2_shift = dot(paper_hash_497_local_1_scattered, (paper_hash_497_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_497_local_3_folded = (paper_hash_497_local_1_scattered + float3(paper_hash_497_local_2_shift, paper_hash_497_local_2_shift, paper_hash_497_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_495_local_7_near_low = mix(fract(((paper_hash_496_local_3_folded.x + paper_hash_496_local_3_folded.y) * paper_hash_496_local_3_folded.z)), fract(((paper_hash_497_local_3_folded.x + paper_hash_497_local_3_folded.y) * paper_hash_497_local_3_folded.z)), paper_noise_495_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_498_local_1_scattered = fract(((paper_noise_495_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_498_local_2_shift = dot(paper_hash_498_local_1_scattered, (paper_hash_498_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_498_local_3_folded = (paper_hash_498_local_1_scattered + float3(paper_hash_498_local_2_shift, paper_hash_498_local_2_shift, paper_hash_498_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_499_local_1_scattered = fract(((paper_noise_495_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_499_local_2_shift = dot(paper_hash_499_local_1_scattered, (paper_hash_499_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_499_local_3_folded = (paper_hash_499_local_1_scattered + float3(paper_hash_499_local_2_shift, paper_hash_499_local_2_shift, paper_hash_499_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_495_local_8_near_high = mix(fract(((paper_hash_498_local_3_folded.x + paper_hash_498_local_3_folded.y) * paper_hash_498_local_3_folded.z)), fract(((paper_hash_499_local_3_folded.x + paper_hash_499_local_3_folded.y) * paper_hash_499_local_3_folded.z)), paper_noise_495_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_500_local_1_scattered = fract(((paper_noise_495_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_500_local_2_shift = dot(paper_hash_500_local_1_scattered, (paper_hash_500_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_500_local_3_folded = (paper_hash_500_local_1_scattered + float3(paper_hash_500_local_2_shift, paper_hash_500_local_2_shift, paper_hash_500_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_501_local_1_scattered = fract(((paper_noise_495_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_501_local_2_shift = dot(paper_hash_501_local_1_scattered, (paper_hash_501_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_501_local_3_folded = (paper_hash_501_local_1_scattered + float3(paper_hash_501_local_2_shift, paper_hash_501_local_2_shift, paper_hash_501_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_495_local_9_far_low = mix(fract(((paper_hash_500_local_3_folded.x + paper_hash_500_local_3_folded.y) * paper_hash_500_local_3_folded.z)), fract(((paper_hash_501_local_3_folded.x + paper_hash_501_local_3_folded.y) * paper_hash_501_local_3_folded.z)), paper_noise_495_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_502_local_1_scattered = fract(((paper_noise_495_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_502_local_2_shift = dot(paper_hash_502_local_1_scattered, (paper_hash_502_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_502_local_3_folded = (paper_hash_502_local_1_scattered + float3(paper_hash_502_local_2_shift, paper_hash_502_local_2_shift, paper_hash_502_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_503_local_1_scattered = fract(((paper_noise_495_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_503_local_2_shift = dot(paper_hash_503_local_1_scattered, (paper_hash_503_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_503_local_3_folded = (paper_hash_503_local_1_scattered + float3(paper_hash_503_local_2_shift, paper_hash_503_local_2_shift, paper_hash_503_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_495_local_10_far_high = mix(fract(((paper_hash_502_local_3_folded.x + paper_hash_502_local_3_folded.y) * paper_hash_502_local_3_folded.z)), fract(((paper_hash_503_local_3_folded.x + paper_hash_503_local_3_folded.y) * paper_hash_503_local_3_folded.z)), paper_noise_495_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_504_local_1_lattice = floor((relief_normal_217_local_6_across_point * 7.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_504_local_2_offset = fract((relief_normal_217_local_6_across_point * 7.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_504_local_3_weight = (paper_noise_504_local_2_offset * (paper_noise_504_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_504_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_504_local_4_u = paper_noise_504_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_504_local_5_v = paper_noise_504_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_504_local_6_w = paper_noise_504_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_505_local_1_scattered = fract((paper_noise_504_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_505_local_2_shift = dot(paper_hash_505_local_1_scattered, (paper_hash_505_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_505_local_3_folded = (paper_hash_505_local_1_scattered + float3(paper_hash_505_local_2_shift, paper_hash_505_local_2_shift, paper_hash_505_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_506_local_1_scattered = fract(((paper_noise_504_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_506_local_2_shift = dot(paper_hash_506_local_1_scattered, (paper_hash_506_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_506_local_3_folded = (paper_hash_506_local_1_scattered + float3(paper_hash_506_local_2_shift, paper_hash_506_local_2_shift, paper_hash_506_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_504_local_7_near_low = mix(fract(((paper_hash_505_local_3_folded.x + paper_hash_505_local_3_folded.y) * paper_hash_505_local_3_folded.z)), fract(((paper_hash_506_local_3_folded.x + paper_hash_506_local_3_folded.y) * paper_hash_506_local_3_folded.z)), paper_noise_504_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_507_local_1_scattered = fract(((paper_noise_504_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_507_local_2_shift = dot(paper_hash_507_local_1_scattered, (paper_hash_507_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_507_local_3_folded = (paper_hash_507_local_1_scattered + float3(paper_hash_507_local_2_shift, paper_hash_507_local_2_shift, paper_hash_507_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_508_local_1_scattered = fract(((paper_noise_504_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_508_local_2_shift = dot(paper_hash_508_local_1_scattered, (paper_hash_508_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_508_local_3_folded = (paper_hash_508_local_1_scattered + float3(paper_hash_508_local_2_shift, paper_hash_508_local_2_shift, paper_hash_508_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_504_local_8_near_high = mix(fract(((paper_hash_507_local_3_folded.x + paper_hash_507_local_3_folded.y) * paper_hash_507_local_3_folded.z)), fract(((paper_hash_508_local_3_folded.x + paper_hash_508_local_3_folded.y) * paper_hash_508_local_3_folded.z)), paper_noise_504_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_509_local_1_scattered = fract(((paper_noise_504_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_509_local_2_shift = dot(paper_hash_509_local_1_scattered, (paper_hash_509_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_509_local_3_folded = (paper_hash_509_local_1_scattered + float3(paper_hash_509_local_2_shift, paper_hash_509_local_2_shift, paper_hash_509_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_510_local_1_scattered = fract(((paper_noise_504_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_510_local_2_shift = dot(paper_hash_510_local_1_scattered, (paper_hash_510_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_510_local_3_folded = (paper_hash_510_local_1_scattered + float3(paper_hash_510_local_2_shift, paper_hash_510_local_2_shift, paper_hash_510_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_504_local_9_far_low = mix(fract(((paper_hash_509_local_3_folded.x + paper_hash_509_local_3_folded.y) * paper_hash_509_local_3_folded.z)), fract(((paper_hash_510_local_3_folded.x + paper_hash_510_local_3_folded.y) * paper_hash_510_local_3_folded.z)), paper_noise_504_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_511_local_1_scattered = fract(((paper_noise_504_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_511_local_2_shift = dot(paper_hash_511_local_1_scattered, (paper_hash_511_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_511_local_3_folded = (paper_hash_511_local_1_scattered + float3(paper_hash_511_local_2_shift, paper_hash_511_local_2_shift, paper_hash_511_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_512_local_1_scattered = fract(((paper_noise_504_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_512_local_2_shift = dot(paper_hash_512_local_1_scattered, (paper_hash_512_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_512_local_3_folded = (paper_hash_512_local_1_scattered + float3(paper_hash_512_local_2_shift, paper_hash_512_local_2_shift, paper_hash_512_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_504_local_10_far_high = mix(fract(((paper_hash_511_local_3_folded.x + paper_hash_511_local_3_folded.y) * paper_hash_511_local_3_folded.z)), fract(((paper_hash_512_local_3_folded.x + paper_hash_512_local_3_folded.y) * paper_hash_512_local_3_folded.z)), paper_noise_504_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_513_local_1_lattice = floor((relief_normal_217_local_6_across_point * 9.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_513_local_2_offset = fract((relief_normal_217_local_6_across_point * 9.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_513_local_3_weight = (paper_noise_513_local_2_offset * (paper_noise_513_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_513_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_513_local_4_u = paper_noise_513_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_513_local_5_v = paper_noise_513_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_513_local_6_w = paper_noise_513_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_514_local_1_scattered = fract((paper_noise_513_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_514_local_2_shift = dot(paper_hash_514_local_1_scattered, (paper_hash_514_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_514_local_3_folded = (paper_hash_514_local_1_scattered + float3(paper_hash_514_local_2_shift, paper_hash_514_local_2_shift, paper_hash_514_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_515_local_1_scattered = fract(((paper_noise_513_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_515_local_2_shift = dot(paper_hash_515_local_1_scattered, (paper_hash_515_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_515_local_3_folded = (paper_hash_515_local_1_scattered + float3(paper_hash_515_local_2_shift, paper_hash_515_local_2_shift, paper_hash_515_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_513_local_7_near_low = mix(fract(((paper_hash_514_local_3_folded.x + paper_hash_514_local_3_folded.y) * paper_hash_514_local_3_folded.z)), fract(((paper_hash_515_local_3_folded.x + paper_hash_515_local_3_folded.y) * paper_hash_515_local_3_folded.z)), paper_noise_513_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_516_local_1_scattered = fract(((paper_noise_513_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_516_local_2_shift = dot(paper_hash_516_local_1_scattered, (paper_hash_516_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_516_local_3_folded = (paper_hash_516_local_1_scattered + float3(paper_hash_516_local_2_shift, paper_hash_516_local_2_shift, paper_hash_516_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_517_local_1_scattered = fract(((paper_noise_513_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_517_local_2_shift = dot(paper_hash_517_local_1_scattered, (paper_hash_517_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_517_local_3_folded = (paper_hash_517_local_1_scattered + float3(paper_hash_517_local_2_shift, paper_hash_517_local_2_shift, paper_hash_517_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_513_local_8_near_high = mix(fract(((paper_hash_516_local_3_folded.x + paper_hash_516_local_3_folded.y) * paper_hash_516_local_3_folded.z)), fract(((paper_hash_517_local_3_folded.x + paper_hash_517_local_3_folded.y) * paper_hash_517_local_3_folded.z)), paper_noise_513_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_518_local_1_scattered = fract(((paper_noise_513_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_518_local_2_shift = dot(paper_hash_518_local_1_scattered, (paper_hash_518_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_518_local_3_folded = (paper_hash_518_local_1_scattered + float3(paper_hash_518_local_2_shift, paper_hash_518_local_2_shift, paper_hash_518_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_519_local_1_scattered = fract(((paper_noise_513_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_519_local_2_shift = dot(paper_hash_519_local_1_scattered, (paper_hash_519_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_519_local_3_folded = (paper_hash_519_local_1_scattered + float3(paper_hash_519_local_2_shift, paper_hash_519_local_2_shift, paper_hash_519_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_513_local_9_far_low = mix(fract(((paper_hash_518_local_3_folded.x + paper_hash_518_local_3_folded.y) * paper_hash_518_local_3_folded.z)), fract(((paper_hash_519_local_3_folded.x + paper_hash_519_local_3_folded.y) * paper_hash_519_local_3_folded.z)), paper_noise_513_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_520_local_1_scattered = fract(((paper_noise_513_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_520_local_2_shift = dot(paper_hash_520_local_1_scattered, (paper_hash_520_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_520_local_3_folded = (paper_hash_520_local_1_scattered + float3(paper_hash_520_local_2_shift, paper_hash_520_local_2_shift, paper_hash_520_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_521_local_1_scattered = fract(((paper_noise_513_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_521_local_2_shift = dot(paper_hash_521_local_1_scattered, (paper_hash_521_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_521_local_3_folded = (paper_hash_521_local_1_scattered + float3(paper_hash_521_local_2_shift, paper_hash_521_local_2_shift, paper_hash_521_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_513_local_10_far_high = mix(fract(((paper_hash_520_local_3_folded.x + paper_hash_520_local_3_folded.y) * paper_hash_520_local_3_folded.z)), fract(((paper_hash_521_local_3_folded.x + paper_hash_521_local_3_folded.y) * paper_hash_521_local_3_folded.z)), paper_noise_513_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_522_local_1_lattice = floor((relief_normal_217_local_6_across_point * 2.3f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_522_local_2_offset = fract((relief_normal_217_local_6_across_point * 2.3f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_522_local_3_weight = (paper_noise_522_local_2_offset * (paper_noise_522_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_522_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_522_local_4_u = paper_noise_522_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_522_local_5_v = paper_noise_522_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_522_local_6_w = paper_noise_522_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_523_local_1_scattered = fract((paper_noise_522_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_523_local_2_shift = dot(paper_hash_523_local_1_scattered, (paper_hash_523_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_523_local_3_folded = (paper_hash_523_local_1_scattered + float3(paper_hash_523_local_2_shift, paper_hash_523_local_2_shift, paper_hash_523_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_524_local_1_scattered = fract(((paper_noise_522_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_524_local_2_shift = dot(paper_hash_524_local_1_scattered, (paper_hash_524_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_524_local_3_folded = (paper_hash_524_local_1_scattered + float3(paper_hash_524_local_2_shift, paper_hash_524_local_2_shift, paper_hash_524_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_522_local_7_near_low = mix(fract(((paper_hash_523_local_3_folded.x + paper_hash_523_local_3_folded.y) * paper_hash_523_local_3_folded.z)), fract(((paper_hash_524_local_3_folded.x + paper_hash_524_local_3_folded.y) * paper_hash_524_local_3_folded.z)), paper_noise_522_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_525_local_1_scattered = fract(((paper_noise_522_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_525_local_2_shift = dot(paper_hash_525_local_1_scattered, (paper_hash_525_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_525_local_3_folded = (paper_hash_525_local_1_scattered + float3(paper_hash_525_local_2_shift, paper_hash_525_local_2_shift, paper_hash_525_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_526_local_1_scattered = fract(((paper_noise_522_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_526_local_2_shift = dot(paper_hash_526_local_1_scattered, (paper_hash_526_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_526_local_3_folded = (paper_hash_526_local_1_scattered + float3(paper_hash_526_local_2_shift, paper_hash_526_local_2_shift, paper_hash_526_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_522_local_8_near_high = mix(fract(((paper_hash_525_local_3_folded.x + paper_hash_525_local_3_folded.y) * paper_hash_525_local_3_folded.z)), fract(((paper_hash_526_local_3_folded.x + paper_hash_526_local_3_folded.y) * paper_hash_526_local_3_folded.z)), paper_noise_522_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_527_local_1_scattered = fract(((paper_noise_522_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_527_local_2_shift = dot(paper_hash_527_local_1_scattered, (paper_hash_527_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_527_local_3_folded = (paper_hash_527_local_1_scattered + float3(paper_hash_527_local_2_shift, paper_hash_527_local_2_shift, paper_hash_527_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_528_local_1_scattered = fract(((paper_noise_522_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_528_local_2_shift = dot(paper_hash_528_local_1_scattered, (paper_hash_528_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_528_local_3_folded = (paper_hash_528_local_1_scattered + float3(paper_hash_528_local_2_shift, paper_hash_528_local_2_shift, paper_hash_528_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_522_local_9_far_low = mix(fract(((paper_hash_527_local_3_folded.x + paper_hash_527_local_3_folded.y) * paper_hash_527_local_3_folded.z)), fract(((paper_hash_528_local_3_folded.x + paper_hash_528_local_3_folded.y) * paper_hash_528_local_3_folded.z)), paper_noise_522_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_529_local_1_scattered = fract(((paper_noise_522_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_529_local_2_shift = dot(paper_hash_529_local_1_scattered, (paper_hash_529_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_529_local_3_folded = (paper_hash_529_local_1_scattered + float3(paper_hash_529_local_2_shift, paper_hash_529_local_2_shift, paper_hash_529_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_530_local_1_scattered = fract(((paper_noise_522_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_530_local_2_shift = dot(paper_hash_530_local_1_scattered, (paper_hash_530_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_530_local_3_folded = (paper_hash_530_local_1_scattered + float3(paper_hash_530_local_2_shift, paper_hash_530_local_2_shift, paper_hash_530_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_522_local_10_far_high = mix(fract(((paper_hash_529_local_3_folded.x + paper_hash_529_local_3_folded.y) * paper_hash_529_local_3_folded.z)), fract(((paper_hash_530_local_3_folded.x + paper_hash_530_local_3_folded.y) * paper_hash_530_local_3_folded.z)), paper_noise_522_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_532_local_1_lattice = floor((relief_normal_217_local_6_across_point * float3(5.5f, 5.5f, 0.6f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_532_local_2_offset = fract((relief_normal_217_local_6_across_point * float3(5.5f, 5.5f, 0.6f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_532_local_3_weight = (paper_noise_532_local_2_offset * (paper_noise_532_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_532_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_532_local_4_u = paper_noise_532_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_532_local_5_v = paper_noise_532_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_532_local_6_w = paper_noise_532_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_533_local_1_scattered = fract((paper_noise_532_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_533_local_2_shift = dot(paper_hash_533_local_1_scattered, (paper_hash_533_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_533_local_3_folded = (paper_hash_533_local_1_scattered + float3(paper_hash_533_local_2_shift, paper_hash_533_local_2_shift, paper_hash_533_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_534_local_1_scattered = fract(((paper_noise_532_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_534_local_2_shift = dot(paper_hash_534_local_1_scattered, (paper_hash_534_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_534_local_3_folded = (paper_hash_534_local_1_scattered + float3(paper_hash_534_local_2_shift, paper_hash_534_local_2_shift, paper_hash_534_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_532_local_7_near_low = mix(fract(((paper_hash_533_local_3_folded.x + paper_hash_533_local_3_folded.y) * paper_hash_533_local_3_folded.z)), fract(((paper_hash_534_local_3_folded.x + paper_hash_534_local_3_folded.y) * paper_hash_534_local_3_folded.z)), paper_noise_532_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_535_local_1_scattered = fract(((paper_noise_532_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_535_local_2_shift = dot(paper_hash_535_local_1_scattered, (paper_hash_535_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_535_local_3_folded = (paper_hash_535_local_1_scattered + float3(paper_hash_535_local_2_shift, paper_hash_535_local_2_shift, paper_hash_535_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_536_local_1_scattered = fract(((paper_noise_532_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_536_local_2_shift = dot(paper_hash_536_local_1_scattered, (paper_hash_536_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_536_local_3_folded = (paper_hash_536_local_1_scattered + float3(paper_hash_536_local_2_shift, paper_hash_536_local_2_shift, paper_hash_536_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_532_local_8_near_high = mix(fract(((paper_hash_535_local_3_folded.x + paper_hash_535_local_3_folded.y) * paper_hash_535_local_3_folded.z)), fract(((paper_hash_536_local_3_folded.x + paper_hash_536_local_3_folded.y) * paper_hash_536_local_3_folded.z)), paper_noise_532_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_537_local_1_scattered = fract(((paper_noise_532_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_537_local_2_shift = dot(paper_hash_537_local_1_scattered, (paper_hash_537_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_537_local_3_folded = (paper_hash_537_local_1_scattered + float3(paper_hash_537_local_2_shift, paper_hash_537_local_2_shift, paper_hash_537_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_538_local_1_scattered = fract(((paper_noise_532_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_538_local_2_shift = dot(paper_hash_538_local_1_scattered, (paper_hash_538_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_538_local_3_folded = (paper_hash_538_local_1_scattered + float3(paper_hash_538_local_2_shift, paper_hash_538_local_2_shift, paper_hash_538_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_532_local_9_far_low = mix(fract(((paper_hash_537_local_3_folded.x + paper_hash_537_local_3_folded.y) * paper_hash_537_local_3_folded.z)), fract(((paper_hash_538_local_3_folded.x + paper_hash_538_local_3_folded.y) * paper_hash_538_local_3_folded.z)), paper_noise_532_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_539_local_1_scattered = fract(((paper_noise_532_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_539_local_2_shift = dot(paper_hash_539_local_1_scattered, (paper_hash_539_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_539_local_3_folded = (paper_hash_539_local_1_scattered + float3(paper_hash_539_local_2_shift, paper_hash_539_local_2_shift, paper_hash_539_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_540_local_1_scattered = fract(((paper_noise_532_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_540_local_2_shift = dot(paper_hash_540_local_1_scattered, (paper_hash_540_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_540_local_3_folded = (paper_hash_540_local_1_scattered + float3(paper_hash_540_local_2_shift, paper_hash_540_local_2_shift, paper_hash_540_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_532_local_10_far_high = mix(fract(((paper_hash_539_local_3_folded.x + paper_hash_539_local_3_folded.y) * paper_hash_539_local_3_folded.z)), fract(((paper_hash_540_local_3_folded.x + paper_hash_540_local_3_folded.y) * paper_hash_540_local_3_folded.z)), paper_noise_532_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_541_local_1_lattice = floor((relief_normal_217_local_6_across_point * 5.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_541_local_2_offset = fract((relief_normal_217_local_6_across_point * 5.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_541_local_3_weight = (paper_noise_541_local_2_offset * (paper_noise_541_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_541_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_541_local_4_u = paper_noise_541_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_541_local_5_v = paper_noise_541_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_541_local_6_w = paper_noise_541_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_542_local_1_scattered = fract((paper_noise_541_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_542_local_2_shift = dot(paper_hash_542_local_1_scattered, (paper_hash_542_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_542_local_3_folded = (paper_hash_542_local_1_scattered + float3(paper_hash_542_local_2_shift, paper_hash_542_local_2_shift, paper_hash_542_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_543_local_1_scattered = fract(((paper_noise_541_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_543_local_2_shift = dot(paper_hash_543_local_1_scattered, (paper_hash_543_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_543_local_3_folded = (paper_hash_543_local_1_scattered + float3(paper_hash_543_local_2_shift, paper_hash_543_local_2_shift, paper_hash_543_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_541_local_7_near_low = mix(fract(((paper_hash_542_local_3_folded.x + paper_hash_542_local_3_folded.y) * paper_hash_542_local_3_folded.z)), fract(((paper_hash_543_local_3_folded.x + paper_hash_543_local_3_folded.y) * paper_hash_543_local_3_folded.z)), paper_noise_541_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_544_local_1_scattered = fract(((paper_noise_541_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_544_local_2_shift = dot(paper_hash_544_local_1_scattered, (paper_hash_544_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_544_local_3_folded = (paper_hash_544_local_1_scattered + float3(paper_hash_544_local_2_shift, paper_hash_544_local_2_shift, paper_hash_544_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_545_local_1_scattered = fract(((paper_noise_541_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_545_local_2_shift = dot(paper_hash_545_local_1_scattered, (paper_hash_545_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_545_local_3_folded = (paper_hash_545_local_1_scattered + float3(paper_hash_545_local_2_shift, paper_hash_545_local_2_shift, paper_hash_545_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_541_local_8_near_high = mix(fract(((paper_hash_544_local_3_folded.x + paper_hash_544_local_3_folded.y) * paper_hash_544_local_3_folded.z)), fract(((paper_hash_545_local_3_folded.x + paper_hash_545_local_3_folded.y) * paper_hash_545_local_3_folded.z)), paper_noise_541_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_546_local_1_scattered = fract(((paper_noise_541_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_546_local_2_shift = dot(paper_hash_546_local_1_scattered, (paper_hash_546_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_546_local_3_folded = (paper_hash_546_local_1_scattered + float3(paper_hash_546_local_2_shift, paper_hash_546_local_2_shift, paper_hash_546_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_547_local_1_scattered = fract(((paper_noise_541_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_547_local_2_shift = dot(paper_hash_547_local_1_scattered, (paper_hash_547_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_547_local_3_folded = (paper_hash_547_local_1_scattered + float3(paper_hash_547_local_2_shift, paper_hash_547_local_2_shift, paper_hash_547_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_541_local_9_far_low = mix(fract(((paper_hash_546_local_3_folded.x + paper_hash_546_local_3_folded.y) * paper_hash_546_local_3_folded.z)), fract(((paper_hash_547_local_3_folded.x + paper_hash_547_local_3_folded.y) * paper_hash_547_local_3_folded.z)), paper_noise_541_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_548_local_1_scattered = fract(((paper_noise_541_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_548_local_2_shift = dot(paper_hash_548_local_1_scattered, (paper_hash_548_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_548_local_3_folded = (paper_hash_548_local_1_scattered + float3(paper_hash_548_local_2_shift, paper_hash_548_local_2_shift, paper_hash_548_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_549_local_1_scattered = fract(((paper_noise_541_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_549_local_2_shift = dot(paper_hash_549_local_1_scattered, (paper_hash_549_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_549_local_3_folded = (paper_hash_549_local_1_scattered + float3(paper_hash_549_local_2_shift, paper_hash_549_local_2_shift, paper_hash_549_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_541_local_10_far_high = mix(fract(((paper_hash_548_local_3_folded.x + paper_hash_548_local_3_folded.y) * paper_hash_548_local_3_folded.z)), fract(((paper_hash_549_local_3_folded.x + paper_hash_549_local_3_folded.y) * paper_hash_549_local_3_folded.z)), paper_noise_541_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_550_local_1_lattice = floor((relief_normal_217_local_6_across_point * 14.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_550_local_2_offset = fract((relief_normal_217_local_6_across_point * 14.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_550_local_3_weight = (paper_noise_550_local_2_offset * (paper_noise_550_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_550_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_550_local_4_u = paper_noise_550_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_550_local_5_v = paper_noise_550_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_550_local_6_w = paper_noise_550_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_551_local_1_scattered = fract((paper_noise_550_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_551_local_2_shift = dot(paper_hash_551_local_1_scattered, (paper_hash_551_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_551_local_3_folded = (paper_hash_551_local_1_scattered + float3(paper_hash_551_local_2_shift, paper_hash_551_local_2_shift, paper_hash_551_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_552_local_1_scattered = fract(((paper_noise_550_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_552_local_2_shift = dot(paper_hash_552_local_1_scattered, (paper_hash_552_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_552_local_3_folded = (paper_hash_552_local_1_scattered + float3(paper_hash_552_local_2_shift, paper_hash_552_local_2_shift, paper_hash_552_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_550_local_7_near_low = mix(fract(((paper_hash_551_local_3_folded.x + paper_hash_551_local_3_folded.y) * paper_hash_551_local_3_folded.z)), fract(((paper_hash_552_local_3_folded.x + paper_hash_552_local_3_folded.y) * paper_hash_552_local_3_folded.z)), paper_noise_550_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_553_local_1_scattered = fract(((paper_noise_550_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_553_local_2_shift = dot(paper_hash_553_local_1_scattered, (paper_hash_553_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_553_local_3_folded = (paper_hash_553_local_1_scattered + float3(paper_hash_553_local_2_shift, paper_hash_553_local_2_shift, paper_hash_553_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_554_local_1_scattered = fract(((paper_noise_550_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_554_local_2_shift = dot(paper_hash_554_local_1_scattered, (paper_hash_554_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_554_local_3_folded = (paper_hash_554_local_1_scattered + float3(paper_hash_554_local_2_shift, paper_hash_554_local_2_shift, paper_hash_554_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_550_local_8_near_high = mix(fract(((paper_hash_553_local_3_folded.x + paper_hash_553_local_3_folded.y) * paper_hash_553_local_3_folded.z)), fract(((paper_hash_554_local_3_folded.x + paper_hash_554_local_3_folded.y) * paper_hash_554_local_3_folded.z)), paper_noise_550_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_555_local_1_scattered = fract(((paper_noise_550_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_555_local_2_shift = dot(paper_hash_555_local_1_scattered, (paper_hash_555_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_555_local_3_folded = (paper_hash_555_local_1_scattered + float3(paper_hash_555_local_2_shift, paper_hash_555_local_2_shift, paper_hash_555_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_556_local_1_scattered = fract(((paper_noise_550_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_556_local_2_shift = dot(paper_hash_556_local_1_scattered, (paper_hash_556_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_556_local_3_folded = (paper_hash_556_local_1_scattered + float3(paper_hash_556_local_2_shift, paper_hash_556_local_2_shift, paper_hash_556_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_550_local_9_far_low = mix(fract(((paper_hash_555_local_3_folded.x + paper_hash_555_local_3_folded.y) * paper_hash_555_local_3_folded.z)), fract(((paper_hash_556_local_3_folded.x + paper_hash_556_local_3_folded.y) * paper_hash_556_local_3_folded.z)), paper_noise_550_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_557_local_1_scattered = fract(((paper_noise_550_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_557_local_2_shift = dot(paper_hash_557_local_1_scattered, (paper_hash_557_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_557_local_3_folded = (paper_hash_557_local_1_scattered + float3(paper_hash_557_local_2_shift, paper_hash_557_local_2_shift, paper_hash_557_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_558_local_1_scattered = fract(((paper_noise_550_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_558_local_2_shift = dot(paper_hash_558_local_1_scattered, (paper_hash_558_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_558_local_3_folded = (paper_hash_558_local_1_scattered + float3(paper_hash_558_local_2_shift, paper_hash_558_local_2_shift, paper_hash_558_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_550_local_10_far_high = mix(fract(((paper_hash_557_local_3_folded.x + paper_hash_557_local_3_folded.y) * paper_hash_557_local_3_folded.z)), fract(((paper_hash_558_local_3_folded.x + paper_hash_558_local_3_folded.y) * paper_hash_558_local_3_folded.z)), paper_noise_550_local_4_u);
  // This numeric value has no quantity annotation.
  float plank_height_559_local_1_u = fract(((relief_normal_217_local_6_across_point.x + relief_normal_217_local_6_across_point.y) * 4.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_560_local_1_lattice = floor((relief_normal_217_local_6_across_point * float3(1.0f, 1.0f, 9.0f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_560_local_2_offset = fract((relief_normal_217_local_6_across_point * float3(1.0f, 1.0f, 9.0f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_560_local_3_weight = (paper_noise_560_local_2_offset * (paper_noise_560_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_560_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_560_local_4_u = paper_noise_560_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_560_local_5_v = paper_noise_560_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_560_local_6_w = paper_noise_560_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_561_local_1_scattered = fract((paper_noise_560_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_561_local_2_shift = dot(paper_hash_561_local_1_scattered, (paper_hash_561_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_561_local_3_folded = (paper_hash_561_local_1_scattered + float3(paper_hash_561_local_2_shift, paper_hash_561_local_2_shift, paper_hash_561_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_562_local_1_scattered = fract(((paper_noise_560_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_562_local_2_shift = dot(paper_hash_562_local_1_scattered, (paper_hash_562_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_562_local_3_folded = (paper_hash_562_local_1_scattered + float3(paper_hash_562_local_2_shift, paper_hash_562_local_2_shift, paper_hash_562_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_560_local_7_near_low = mix(fract(((paper_hash_561_local_3_folded.x + paper_hash_561_local_3_folded.y) * paper_hash_561_local_3_folded.z)), fract(((paper_hash_562_local_3_folded.x + paper_hash_562_local_3_folded.y) * paper_hash_562_local_3_folded.z)), paper_noise_560_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_563_local_1_scattered = fract(((paper_noise_560_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_563_local_2_shift = dot(paper_hash_563_local_1_scattered, (paper_hash_563_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_563_local_3_folded = (paper_hash_563_local_1_scattered + float3(paper_hash_563_local_2_shift, paper_hash_563_local_2_shift, paper_hash_563_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_564_local_1_scattered = fract(((paper_noise_560_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_564_local_2_shift = dot(paper_hash_564_local_1_scattered, (paper_hash_564_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_564_local_3_folded = (paper_hash_564_local_1_scattered + float3(paper_hash_564_local_2_shift, paper_hash_564_local_2_shift, paper_hash_564_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_560_local_8_near_high = mix(fract(((paper_hash_563_local_3_folded.x + paper_hash_563_local_3_folded.y) * paper_hash_563_local_3_folded.z)), fract(((paper_hash_564_local_3_folded.x + paper_hash_564_local_3_folded.y) * paper_hash_564_local_3_folded.z)), paper_noise_560_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_565_local_1_scattered = fract(((paper_noise_560_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_565_local_2_shift = dot(paper_hash_565_local_1_scattered, (paper_hash_565_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_565_local_3_folded = (paper_hash_565_local_1_scattered + float3(paper_hash_565_local_2_shift, paper_hash_565_local_2_shift, paper_hash_565_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_566_local_1_scattered = fract(((paper_noise_560_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_566_local_2_shift = dot(paper_hash_566_local_1_scattered, (paper_hash_566_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_566_local_3_folded = (paper_hash_566_local_1_scattered + float3(paper_hash_566_local_2_shift, paper_hash_566_local_2_shift, paper_hash_566_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_560_local_9_far_low = mix(fract(((paper_hash_565_local_3_folded.x + paper_hash_565_local_3_folded.y) * paper_hash_565_local_3_folded.z)), fract(((paper_hash_566_local_3_folded.x + paper_hash_566_local_3_folded.y) * paper_hash_566_local_3_folded.z)), paper_noise_560_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_567_local_1_scattered = fract(((paper_noise_560_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_567_local_2_shift = dot(paper_hash_567_local_1_scattered, (paper_hash_567_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_567_local_3_folded = (paper_hash_567_local_1_scattered + float3(paper_hash_567_local_2_shift, paper_hash_567_local_2_shift, paper_hash_567_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_568_local_1_scattered = fract(((paper_noise_560_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_568_local_2_shift = dot(paper_hash_568_local_1_scattered, (paper_hash_568_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_568_local_3_folded = (paper_hash_568_local_1_scattered + float3(paper_hash_568_local_2_shift, paper_hash_568_local_2_shift, paper_hash_568_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_560_local_10_far_high = mix(fract(((paper_hash_567_local_3_folded.x + paper_hash_567_local_3_folded.y) * paper_hash_567_local_3_folded.z)), fract(((paper_hash_568_local_3_folded.x + paper_hash_568_local_3_folded.y) * paper_hash_568_local_3_folded.z)), paper_noise_560_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_569_local_1_lattice = floor((relief_normal_217_local_6_across_point * 1.3f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_569_local_2_offset = fract((relief_normal_217_local_6_across_point * 1.3f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_569_local_3_weight = (paper_noise_569_local_2_offset * (paper_noise_569_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_569_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_569_local_4_u = paper_noise_569_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_569_local_5_v = paper_noise_569_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_569_local_6_w = paper_noise_569_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_570_local_1_scattered = fract((paper_noise_569_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_570_local_2_shift = dot(paper_hash_570_local_1_scattered, (paper_hash_570_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_570_local_3_folded = (paper_hash_570_local_1_scattered + float3(paper_hash_570_local_2_shift, paper_hash_570_local_2_shift, paper_hash_570_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_571_local_1_scattered = fract(((paper_noise_569_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_571_local_2_shift = dot(paper_hash_571_local_1_scattered, (paper_hash_571_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_571_local_3_folded = (paper_hash_571_local_1_scattered + float3(paper_hash_571_local_2_shift, paper_hash_571_local_2_shift, paper_hash_571_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_569_local_7_near_low = mix(fract(((paper_hash_570_local_3_folded.x + paper_hash_570_local_3_folded.y) * paper_hash_570_local_3_folded.z)), fract(((paper_hash_571_local_3_folded.x + paper_hash_571_local_3_folded.y) * paper_hash_571_local_3_folded.z)), paper_noise_569_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_572_local_1_scattered = fract(((paper_noise_569_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_572_local_2_shift = dot(paper_hash_572_local_1_scattered, (paper_hash_572_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_572_local_3_folded = (paper_hash_572_local_1_scattered + float3(paper_hash_572_local_2_shift, paper_hash_572_local_2_shift, paper_hash_572_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_573_local_1_scattered = fract(((paper_noise_569_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_573_local_2_shift = dot(paper_hash_573_local_1_scattered, (paper_hash_573_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_573_local_3_folded = (paper_hash_573_local_1_scattered + float3(paper_hash_573_local_2_shift, paper_hash_573_local_2_shift, paper_hash_573_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_569_local_8_near_high = mix(fract(((paper_hash_572_local_3_folded.x + paper_hash_572_local_3_folded.y) * paper_hash_572_local_3_folded.z)), fract(((paper_hash_573_local_3_folded.x + paper_hash_573_local_3_folded.y) * paper_hash_573_local_3_folded.z)), paper_noise_569_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_574_local_1_scattered = fract(((paper_noise_569_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_574_local_2_shift = dot(paper_hash_574_local_1_scattered, (paper_hash_574_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_574_local_3_folded = (paper_hash_574_local_1_scattered + float3(paper_hash_574_local_2_shift, paper_hash_574_local_2_shift, paper_hash_574_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_575_local_1_scattered = fract(((paper_noise_569_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_575_local_2_shift = dot(paper_hash_575_local_1_scattered, (paper_hash_575_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_575_local_3_folded = (paper_hash_575_local_1_scattered + float3(paper_hash_575_local_2_shift, paper_hash_575_local_2_shift, paper_hash_575_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_569_local_9_far_low = mix(fract(((paper_hash_574_local_3_folded.x + paper_hash_574_local_3_folded.y) * paper_hash_574_local_3_folded.z)), fract(((paper_hash_575_local_3_folded.x + paper_hash_575_local_3_folded.y) * paper_hash_575_local_3_folded.z)), paper_noise_569_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_576_local_1_scattered = fract(((paper_noise_569_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_576_local_2_shift = dot(paper_hash_576_local_1_scattered, (paper_hash_576_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_576_local_3_folded = (paper_hash_576_local_1_scattered + float3(paper_hash_576_local_2_shift, paper_hash_576_local_2_shift, paper_hash_576_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_577_local_1_scattered = fract(((paper_noise_569_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_577_local_2_shift = dot(paper_hash_577_local_1_scattered, (paper_hash_577_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_577_local_3_folded = (paper_hash_577_local_1_scattered + float3(paper_hash_577_local_2_shift, paper_hash_577_local_2_shift, paper_hash_577_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_569_local_10_far_high = mix(fract(((paper_hash_576_local_3_folded.x + paper_hash_576_local_3_folded.y) * paper_hash_576_local_3_folded.z)), fract(((paper_hash_577_local_3_folded.x + paper_hash_577_local_3_folded.y) * paper_hash_577_local_3_folded.z)), paper_noise_569_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_578_local_1_lattice = floor((relief_normal_217_local_6_across_point * 4.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_578_local_2_offset = fract((relief_normal_217_local_6_across_point * 4.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_578_local_3_weight = (paper_noise_578_local_2_offset * (paper_noise_578_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_578_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_578_local_4_u = paper_noise_578_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_578_local_5_v = paper_noise_578_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_578_local_6_w = paper_noise_578_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_579_local_1_scattered = fract((paper_noise_578_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_579_local_2_shift = dot(paper_hash_579_local_1_scattered, (paper_hash_579_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_579_local_3_folded = (paper_hash_579_local_1_scattered + float3(paper_hash_579_local_2_shift, paper_hash_579_local_2_shift, paper_hash_579_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_580_local_1_scattered = fract(((paper_noise_578_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_580_local_2_shift = dot(paper_hash_580_local_1_scattered, (paper_hash_580_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_580_local_3_folded = (paper_hash_580_local_1_scattered + float3(paper_hash_580_local_2_shift, paper_hash_580_local_2_shift, paper_hash_580_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_578_local_7_near_low = mix(fract(((paper_hash_579_local_3_folded.x + paper_hash_579_local_3_folded.y) * paper_hash_579_local_3_folded.z)), fract(((paper_hash_580_local_3_folded.x + paper_hash_580_local_3_folded.y) * paper_hash_580_local_3_folded.z)), paper_noise_578_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_581_local_1_scattered = fract(((paper_noise_578_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_581_local_2_shift = dot(paper_hash_581_local_1_scattered, (paper_hash_581_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_581_local_3_folded = (paper_hash_581_local_1_scattered + float3(paper_hash_581_local_2_shift, paper_hash_581_local_2_shift, paper_hash_581_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_582_local_1_scattered = fract(((paper_noise_578_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_582_local_2_shift = dot(paper_hash_582_local_1_scattered, (paper_hash_582_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_582_local_3_folded = (paper_hash_582_local_1_scattered + float3(paper_hash_582_local_2_shift, paper_hash_582_local_2_shift, paper_hash_582_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_578_local_8_near_high = mix(fract(((paper_hash_581_local_3_folded.x + paper_hash_581_local_3_folded.y) * paper_hash_581_local_3_folded.z)), fract(((paper_hash_582_local_3_folded.x + paper_hash_582_local_3_folded.y) * paper_hash_582_local_3_folded.z)), paper_noise_578_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_583_local_1_scattered = fract(((paper_noise_578_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_583_local_2_shift = dot(paper_hash_583_local_1_scattered, (paper_hash_583_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_583_local_3_folded = (paper_hash_583_local_1_scattered + float3(paper_hash_583_local_2_shift, paper_hash_583_local_2_shift, paper_hash_583_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_584_local_1_scattered = fract(((paper_noise_578_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_584_local_2_shift = dot(paper_hash_584_local_1_scattered, (paper_hash_584_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_584_local_3_folded = (paper_hash_584_local_1_scattered + float3(paper_hash_584_local_2_shift, paper_hash_584_local_2_shift, paper_hash_584_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_578_local_9_far_low = mix(fract(((paper_hash_583_local_3_folded.x + paper_hash_583_local_3_folded.y) * paper_hash_583_local_3_folded.z)), fract(((paper_hash_584_local_3_folded.x + paper_hash_584_local_3_folded.y) * paper_hash_584_local_3_folded.z)), paper_noise_578_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_585_local_1_scattered = fract(((paper_noise_578_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_585_local_2_shift = dot(paper_hash_585_local_1_scattered, (paper_hash_585_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_585_local_3_folded = (paper_hash_585_local_1_scattered + float3(paper_hash_585_local_2_shift, paper_hash_585_local_2_shift, paper_hash_585_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_586_local_1_scattered = fract(((paper_noise_578_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_586_local_2_shift = dot(paper_hash_586_local_1_scattered, (paper_hash_586_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_586_local_3_folded = (paper_hash_586_local_1_scattered + float3(paper_hash_586_local_2_shift, paper_hash_586_local_2_shift, paper_hash_586_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_578_local_10_far_high = mix(fract(((paper_hash_585_local_3_folded.x + paper_hash_585_local_3_folded.y) * paper_hash_585_local_3_folded.z)), fract(((paper_hash_586_local_3_folded.x + paper_hash_586_local_3_folded.y) * paper_hash_586_local_3_folded.z)), paper_noise_578_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_noise_587_local_1_lattice = floor((relief_normal_217_local_6_across_point * 2.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_587_local_2_offset = fract((relief_normal_217_local_6_across_point * 2.0f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_587_local_3_weight = (paper_noise_587_local_2_offset * (paper_noise_587_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_587_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_587_local_4_u = paper_noise_587_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_587_local_5_v = paper_noise_587_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_587_local_6_w = paper_noise_587_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_588_local_1_scattered = fract((paper_noise_587_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_588_local_2_shift = dot(paper_hash_588_local_1_scattered, (paper_hash_588_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_588_local_3_folded = (paper_hash_588_local_1_scattered + float3(paper_hash_588_local_2_shift, paper_hash_588_local_2_shift, paper_hash_588_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_589_local_1_scattered = fract(((paper_noise_587_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_589_local_2_shift = dot(paper_hash_589_local_1_scattered, (paper_hash_589_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_589_local_3_folded = (paper_hash_589_local_1_scattered + float3(paper_hash_589_local_2_shift, paper_hash_589_local_2_shift, paper_hash_589_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_587_local_7_near_low = mix(fract(((paper_hash_588_local_3_folded.x + paper_hash_588_local_3_folded.y) * paper_hash_588_local_3_folded.z)), fract(((paper_hash_589_local_3_folded.x + paper_hash_589_local_3_folded.y) * paper_hash_589_local_3_folded.z)), paper_noise_587_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_590_local_1_scattered = fract(((paper_noise_587_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_590_local_2_shift = dot(paper_hash_590_local_1_scattered, (paper_hash_590_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_590_local_3_folded = (paper_hash_590_local_1_scattered + float3(paper_hash_590_local_2_shift, paper_hash_590_local_2_shift, paper_hash_590_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_591_local_1_scattered = fract(((paper_noise_587_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_591_local_2_shift = dot(paper_hash_591_local_1_scattered, (paper_hash_591_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_591_local_3_folded = (paper_hash_591_local_1_scattered + float3(paper_hash_591_local_2_shift, paper_hash_591_local_2_shift, paper_hash_591_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_587_local_8_near_high = mix(fract(((paper_hash_590_local_3_folded.x + paper_hash_590_local_3_folded.y) * paper_hash_590_local_3_folded.z)), fract(((paper_hash_591_local_3_folded.x + paper_hash_591_local_3_folded.y) * paper_hash_591_local_3_folded.z)), paper_noise_587_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_592_local_1_scattered = fract(((paper_noise_587_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_592_local_2_shift = dot(paper_hash_592_local_1_scattered, (paper_hash_592_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_592_local_3_folded = (paper_hash_592_local_1_scattered + float3(paper_hash_592_local_2_shift, paper_hash_592_local_2_shift, paper_hash_592_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_593_local_1_scattered = fract(((paper_noise_587_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_593_local_2_shift = dot(paper_hash_593_local_1_scattered, (paper_hash_593_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_593_local_3_folded = (paper_hash_593_local_1_scattered + float3(paper_hash_593_local_2_shift, paper_hash_593_local_2_shift, paper_hash_593_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_587_local_9_far_low = mix(fract(((paper_hash_592_local_3_folded.x + paper_hash_592_local_3_folded.y) * paper_hash_592_local_3_folded.z)), fract(((paper_hash_593_local_3_folded.x + paper_hash_593_local_3_folded.y) * paper_hash_593_local_3_folded.z)), paper_noise_587_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_594_local_1_scattered = fract(((paper_noise_587_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_594_local_2_shift = dot(paper_hash_594_local_1_scattered, (paper_hash_594_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_594_local_3_folded = (paper_hash_594_local_1_scattered + float3(paper_hash_594_local_2_shift, paper_hash_594_local_2_shift, paper_hash_594_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_595_local_1_scattered = fract(((paper_noise_587_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_595_local_2_shift = dot(paper_hash_595_local_1_scattered, (paper_hash_595_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_595_local_3_folded = (paper_hash_595_local_1_scattered + float3(paper_hash_595_local_2_shift, paper_hash_595_local_2_shift, paper_hash_595_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_587_local_10_far_high = mix(fract(((paper_hash_594_local_3_folded.x + paper_hash_594_local_3_folded.y) * paper_hash_594_local_3_folded.z)), fract(((paper_hash_595_local_3_folded.x + paper_hash_595_local_3_folded.y) * paper_hash_595_local_3_folded.z)), paper_noise_587_local_4_u);
  // This numeric value has no quantity annotation.
  float3 cloth_height_596_local_1_q = ((relief_normal_217_local_6_across_point * 8.0f) + float3(0.5f, 0.5f, 0.5f));
  // This numeric value has no quantity annotation.
  float3 cloth_height_596_local_2_cell = floor(cloth_height_596_local_1_q);
  // This numeric value has no quantity annotation.
  float3 cloth_height_596_local_3_offset = fract(cloth_height_596_local_1_q);
  // This numeric value has no quantity annotation.
  float cloth_height_596_local_4_x = cloth_height_596_local_3_offset.x;
  // This numeric value has no quantity annotation.
  float cloth_height_596_local_5_y = cloth_height_596_local_3_offset.y;
  // This numeric value has no quantity annotation.
  float cloth_height_596_local_6_z = cloth_height_596_local_3_offset.z;
  // This numeric value has no quantity annotation.
  float cloth_height_596_local_7_over = (2.0f * fract((0.5f * ((cloth_height_596_local_2_cell.x + cloth_height_596_local_2_cell.y) + cloth_height_596_local_2_cell.z))));
  // This numeric value has no quantity annotation.
  float cloth_height_596_local_8_along_x = (((((4.0f * cloth_height_596_local_5_y) * (1.0f - cloth_height_596_local_5_y)) * ((4.0f * cloth_height_596_local_6_z) * (1.0f - cloth_height_596_local_6_z))) * (0.55f + (0.45f * ((4.0f * cloth_height_596_local_4_x) * (1.0f - cloth_height_596_local_4_x))))) * (0.7f + (0.3f * cloth_height_596_local_7_over)));
  // This numeric value has no quantity annotation.
  float cloth_height_596_local_9_along_y = (((((4.0f * cloth_height_596_local_4_x) * (1.0f - cloth_height_596_local_4_x)) * ((4.0f * cloth_height_596_local_6_z) * (1.0f - cloth_height_596_local_6_z))) * (0.55f + (0.45f * ((4.0f * cloth_height_596_local_5_y) * (1.0f - cloth_height_596_local_5_y))))) * (0.7f + (0.3f * (1.0f - cloth_height_596_local_7_over))));
  // This numeric value has no quantity annotation.
  float cloth_height_596_local_10_along_z = (((((4.0f * cloth_height_596_local_4_x) * (1.0f - cloth_height_596_local_4_x)) * ((4.0f * cloth_height_596_local_5_y) * (1.0f - cloth_height_596_local_5_y))) * (0.55f + (0.45f * ((4.0f * cloth_height_596_local_6_z) * (1.0f - cloth_height_596_local_6_z))))) * (0.7f + (0.3f * cloth_height_596_local_7_over)));
  // This numeric value has no quantity annotation.
  float fiber_height_609_local_1_u = (relief_normal_217_local_6_across_point.x + relief_normal_217_local_6_across_point.y);
  // This numeric value has no quantity annotation.
  float fiber_height_609_local_2_z = relief_normal_217_local_6_across_point.z;
  // This numeric value has no quantity annotation.
  float3 paper_noise_611_local_1_lattice = floor((relief_normal_217_local_6_across_point * float3(19.0f, 19.0f, 3.0f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_611_local_2_offset = fract((relief_normal_217_local_6_across_point * float3(19.0f, 19.0f, 3.0f)));
  // This numeric value has no quantity annotation.
  float3 paper_noise_611_local_3_weight = (paper_noise_611_local_2_offset * (paper_noise_611_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_611_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_611_local_4_u = paper_noise_611_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_611_local_5_v = paper_noise_611_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_611_local_6_w = paper_noise_611_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_612_local_1_scattered = fract((paper_noise_611_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_612_local_2_shift = dot(paper_hash_612_local_1_scattered, (paper_hash_612_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_612_local_3_folded = (paper_hash_612_local_1_scattered + float3(paper_hash_612_local_2_shift, paper_hash_612_local_2_shift, paper_hash_612_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_613_local_1_scattered = fract(((paper_noise_611_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_613_local_2_shift = dot(paper_hash_613_local_1_scattered, (paper_hash_613_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_613_local_3_folded = (paper_hash_613_local_1_scattered + float3(paper_hash_613_local_2_shift, paper_hash_613_local_2_shift, paper_hash_613_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_611_local_7_near_low = mix(fract(((paper_hash_612_local_3_folded.x + paper_hash_612_local_3_folded.y) * paper_hash_612_local_3_folded.z)), fract(((paper_hash_613_local_3_folded.x + paper_hash_613_local_3_folded.y) * paper_hash_613_local_3_folded.z)), paper_noise_611_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_614_local_1_scattered = fract(((paper_noise_611_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_614_local_2_shift = dot(paper_hash_614_local_1_scattered, (paper_hash_614_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_614_local_3_folded = (paper_hash_614_local_1_scattered + float3(paper_hash_614_local_2_shift, paper_hash_614_local_2_shift, paper_hash_614_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_615_local_1_scattered = fract(((paper_noise_611_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_615_local_2_shift = dot(paper_hash_615_local_1_scattered, (paper_hash_615_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_615_local_3_folded = (paper_hash_615_local_1_scattered + float3(paper_hash_615_local_2_shift, paper_hash_615_local_2_shift, paper_hash_615_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_611_local_8_near_high = mix(fract(((paper_hash_614_local_3_folded.x + paper_hash_614_local_3_folded.y) * paper_hash_614_local_3_folded.z)), fract(((paper_hash_615_local_3_folded.x + paper_hash_615_local_3_folded.y) * paper_hash_615_local_3_folded.z)), paper_noise_611_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_616_local_1_scattered = fract(((paper_noise_611_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_616_local_2_shift = dot(paper_hash_616_local_1_scattered, (paper_hash_616_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_616_local_3_folded = (paper_hash_616_local_1_scattered + float3(paper_hash_616_local_2_shift, paper_hash_616_local_2_shift, paper_hash_616_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_617_local_1_scattered = fract(((paper_noise_611_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_617_local_2_shift = dot(paper_hash_617_local_1_scattered, (paper_hash_617_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_617_local_3_folded = (paper_hash_617_local_1_scattered + float3(paper_hash_617_local_2_shift, paper_hash_617_local_2_shift, paper_hash_617_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_611_local_9_far_low = mix(fract(((paper_hash_616_local_3_folded.x + paper_hash_616_local_3_folded.y) * paper_hash_616_local_3_folded.z)), fract(((paper_hash_617_local_3_folded.x + paper_hash_617_local_3_folded.y) * paper_hash_617_local_3_folded.z)), paper_noise_611_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_618_local_1_scattered = fract(((paper_noise_611_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_618_local_2_shift = dot(paper_hash_618_local_1_scattered, (paper_hash_618_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_618_local_3_folded = (paper_hash_618_local_1_scattered + float3(paper_hash_618_local_2_shift, paper_hash_618_local_2_shift, paper_hash_618_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_619_local_1_scattered = fract(((paper_noise_611_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_619_local_2_shift = dot(paper_hash_619_local_1_scattered, (paper_hash_619_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_619_local_3_folded = (paper_hash_619_local_1_scattered + float3(paper_hash_619_local_2_shift, paper_hash_619_local_2_shift, paper_hash_619_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_611_local_10_far_high = mix(fract(((paper_hash_618_local_3_folded.x + paper_hash_618_local_3_folded.y) * paper_hash_618_local_3_folded.z)), fract(((paper_hash_619_local_3_folded.x + paper_hash_619_local_3_folded.y) * paper_hash_619_local_3_folded.z)), paper_noise_611_local_4_u);
  // This value is a difference-valued scalar, unitless and dimensionless.
  float surface_height_465_local_1_raw = ((relief < 0.5f) ? 0.5f : ((relief < 1.5f) ? ((0.6f * mix(mix(paper_noise_467_local_7_near_low, paper_noise_467_local_8_near_high, paper_noise_467_local_5_v), mix(paper_noise_467_local_9_far_low, paper_noise_467_local_10_far_high, paper_noise_467_local_5_v), paper_noise_467_local_6_w)) + (0.4f * mix(mix(paper_noise_476_local_7_near_low, paper_noise_476_local_8_near_high, paper_noise_476_local_5_v), mix(paper_noise_476_local_9_far_low, paper_noise_476_local_10_far_high, paper_noise_476_local_5_v), paper_noise_476_local_6_w))) : ((relief < 2.5f) ? (((0.55f * (1.0f - abs(((mix(mix(paper_noise_486_local_7_near_low, paper_noise_486_local_8_near_high, paper_noise_486_local_5_v), mix(paper_noise_486_local_9_far_low, paper_noise_486_local_10_far_high, paper_noise_486_local_5_v), paper_noise_486_local_6_w) * 2.0f) - 1.0f)))) + (0.3f * mix(mix(paper_noise_495_local_7_near_low, paper_noise_495_local_8_near_high, paper_noise_495_local_5_v), mix(paper_noise_495_local_9_far_low, paper_noise_495_local_10_far_high, paper_noise_495_local_5_v), paper_noise_495_local_6_w))) + (0.15f * mix(mix(paper_noise_504_local_7_near_low, paper_noise_504_local_8_near_high, paper_noise_504_local_5_v), mix(paper_noise_504_local_9_far_low, paper_noise_504_local_10_far_high, paper_noise_504_local_5_v), paper_noise_504_local_6_w))) : ((relief < 3.5f) ? ((0.7f * mix(mix(paper_noise_513_local_7_near_low, paper_noise_513_local_8_near_high, paper_noise_513_local_5_v), mix(paper_noise_513_local_9_far_low, paper_noise_513_local_10_far_high, paper_noise_513_local_5_v), paper_noise_513_local_6_w)) + (0.3f * mix(mix(paper_noise_522_local_7_near_low, paper_noise_522_local_8_near_high, paper_noise_522_local_5_v), mix(paper_noise_522_local_9_far_low, paper_noise_522_local_10_far_high, paper_noise_522_local_5_v), paper_noise_522_local_6_w))) : ((relief < 4.5f) ? (1.0f - abs(((mix(mix(paper_noise_532_local_7_near_low, paper_noise_532_local_8_near_high, paper_noise_532_local_5_v), mix(paper_noise_532_local_9_far_low, paper_noise_532_local_10_far_high, paper_noise_532_local_5_v), paper_noise_532_local_6_w) * 2.0f) - 1.0f))) : ((relief < 5.5f) ? ((0.65f * smoothstep(0.3f, 0.7f, mix(mix(paper_noise_541_local_7_near_low, paper_noise_541_local_8_near_high, paper_noise_541_local_5_v), mix(paper_noise_541_local_9_far_low, paper_noise_541_local_10_far_high, paper_noise_541_local_5_v), paper_noise_541_local_6_w))) + (0.35f * mix(mix(paper_noise_550_local_7_near_low, paper_noise_550_local_8_near_high, paper_noise_550_local_5_v), mix(paper_noise_550_local_9_far_low, paper_noise_550_local_10_far_high, paper_noise_550_local_5_v), paper_noise_550_local_6_w))) : ((relief < 6.5f) ? ((smoothstep(0.0f, 0.1f, plank_height_559_local_1_u) * (1.0f - smoothstep(0.9f, 1.0f, plank_height_559_local_1_u))) * (0.75f + (0.25f * mix(mix(paper_noise_560_local_7_near_low, paper_noise_560_local_8_near_high, paper_noise_560_local_5_v), mix(paper_noise_560_local_9_far_low, paper_noise_560_local_10_far_high, paper_noise_560_local_5_v), paper_noise_560_local_6_w)))) : ((relief < 7.5f) ? ((0.7f * mix(mix(paper_noise_569_local_7_near_low, paper_noise_569_local_8_near_high, paper_noise_569_local_5_v), mix(paper_noise_569_local_9_far_low, paper_noise_569_local_10_far_high, paper_noise_569_local_5_v), paper_noise_569_local_6_w)) + (0.3f * mix(mix(paper_noise_578_local_7_near_low, paper_noise_578_local_8_near_high, paper_noise_578_local_5_v), mix(paper_noise_578_local_9_far_low, paper_noise_578_local_10_far_high, paper_noise_578_local_5_v), paper_noise_578_local_6_w))) : ((relief < 8.5f) ? mix(mix(paper_noise_587_local_7_near_low, paper_noise_587_local_8_near_high, paper_noise_587_local_5_v), mix(paper_noise_587_local_9_far_low, paper_noise_587_local_10_far_high, paper_noise_587_local_5_v), paper_noise_587_local_6_w) : ((relief < 9.5f) ? (0.1f + (0.8f * max(cloth_height_596_local_8_along_x, max(cloth_height_596_local_9_along_y, cloth_height_596_local_10_along_z)))) : ((relief < 10.5f) ? ((0.7f * ((4.0f * fract(((fiber_height_609_local_1_u * 17.0f) + (fiber_height_609_local_2_z * 1.3f)))) * (1.0f - fract(((fiber_height_609_local_1_u * 17.0f) + (fiber_height_609_local_2_z * 1.3f)))))) + (0.3f * mix(mix(paper_noise_611_local_7_near_low, paper_noise_611_local_8_near_high, paper_noise_611_local_5_v), mix(paper_noise_611_local_9_far_low, paper_noise_611_local_10_far_high, paper_noise_611_local_5_v), paper_noise_611_local_6_w))) : ((relief < 11.5f) ? ((0.8f * ((4.0f * fract((fiber_height_609_local_1_u * 5.0f))) * (1.0f - fract((fiber_height_609_local_1_u * 5.0f))))) + (0.2f * step(0.85f, fract(((fiber_height_609_local_1_u * 13.0f) + (fiber_height_609_local_2_z * 7.0f)))))) : (0.45f + (0.1f * ((4.0f * fract((fiber_height_609_local_2_z * 24.0f))) * (1.0f - fract((fiber_height_609_local_2_z * 24.0f))))))))))))))))));
  // This numeric value has no quantity annotation.
  float surface_height_465_local_2_relief = ((relief > 8.5f) ? ((relief < 10.5f) ? mix(0.5f, surface_height_465_local_1_raw, nap_fade) : surface_height_465_local_1_raw) : surface_height_465_local_1_raw);
  // This numeric value has no quantity annotation.
  float surface_height_465_local_3_cut = ((((laid_pattern_421_local_1_shape < 0.5f) ? float4(1.0f, 0.5f, 1.0f, 0.0f) : ((laid_pattern_421_local_1_shape > 4.5f) ? ((face_laid_pattern_423_local_1_shape > 8.5f) ? ((face_laid_pattern_423_local_1_shape > 13.5f) ? float4(1.0f, mineral_pattern_425_local_2_ink, 0.0f, 0.0f) : ((face_laid_pattern_423_local_1_shape < 9.5f) ? float4((0.4f + (0.5f * motif_face_427_local_6_frame)), let_428_2_ink, motif_face_427_local_6_frame, 0.0f) : ((face_laid_pattern_423_local_1_shape < 10.5f) ? float4((0.35f + (0.55f * let_429_4_metal)), let_429_4_metal, 0.0f, 0.0f) : ((face_laid_pattern_423_local_1_shape < 11.5f) ? float4(0.85f, let_430_2_ink, smoothstep(0.43f, 0.47f, abs(motif_face_427_local_3_x)), 0.0f) : ((face_laid_pattern_423_local_1_shape < 12.5f) ? float4((0.9f - (let_431_1_band * 0.25f)), 0.0f, let_431_1_band, 0.0f) : float4((0.35f + (0.6f * motif_face_427_local_6_frame)), (face_laid_pattern_423_local_3_top ? (1.0f - motif_face_427_local_6_frame) : 0.0f), (face_laid_pattern_423_local_3_top ? motif_face_427_local_6_frame : 1.0f), 0.0f)))))) : (face_laid_pattern_423_local_3_top ? ((face_laid_pattern_423_local_1_shape < 5.5f) ? float4((1.0f - (0.7f * board_face_432_local_3_groove)), fract(((paper_hash_434_local_3_folded.x + paper_hash_434_local_3_folded.y) * paper_hash_434_local_3_folded.z)), 0.0f, (0.6f * board_face_432_local_3_groove)) : ((face_laid_pattern_423_local_1_shape < 7.5f) ? float4(1.0f, 0.5f, 1.0f, 0.0f) : float4(0.8f, 0.5f, 0.0f, 0.0f))) : ((face_laid_pattern_423_local_1_shape < 5.5f) ? float4(mix(mix(shelf_face_435_local_26_spine, 0.05f, shelf_face_435_local_24_recess), 1.0f, shelf_face_435_local_12_frame), (shelf_face_435_local_19_id + shelf_face_435_local_27_gilt), shelf_face_435_local_12_frame, shelf_face_435_local_24_recess) : ((face_laid_pattern_423_local_1_shape < 6.5f) ? float4(mix(0.2f, mix(mix(0.85f, 1.0f, window_face_442_local_4_frame), 0.45f, window_face_442_local_5_groove), window_face_442_local_9_bar), window_face_442_local_11_light, window_face_442_local_9_bar, window_face_442_local_5_groove) : ((face_laid_pattern_423_local_1_shape < 7.5f) ? float4(mix((0.35f + (0.2f * mix(mix(paper_noise_452_local_7_near_low, paper_noise_452_local_8_near_high, paper_noise_452_local_5_v), mix(paper_noise_452_local_9_far_low, paper_noise_452_local_10_far_high, paper_noise_452_local_5_v), paper_noise_452_local_6_w))), 0.95f, timbered_face_448_local_8_frame), 0.5f, timbered_face_448_local_8_frame, 0.0f) : float4(mix(mix(0.55f, 0.85f, panel_face_461_local_4_bevel), 0.95f, panel_face_461_local_3_frame), fract(((paper_hash_464_local_3_folded.x + paper_hash_464_local_3_folded.y) * paper_hash_464_local_3_folded.z)), panel_face_461_local_3_frame, 0.0f)))))) : float4(laid_pattern_421_local_26_mask, laid_pattern_421_local_28_hash, laid_pattern_421_local_27_ramp, laid_pattern_421_local_29_checked))).x * ((stage_in.material_pattern.x > 4.5f) ? 1.0f : ((laid_pattern_421_local_1_shape < 0.5f) ? float4(1.0f, 0.5f, 1.0f, 0.0f) : ((laid_pattern_421_local_1_shape > 4.5f) ? ((face_laid_pattern_423_local_1_shape > 8.5f) ? ((face_laid_pattern_423_local_1_shape > 13.5f) ? float4(1.0f, mineral_pattern_425_local_2_ink, 0.0f, 0.0f) : ((face_laid_pattern_423_local_1_shape < 9.5f) ? float4((0.4f + (0.5f * motif_face_427_local_6_frame)), let_428_2_ink, motif_face_427_local_6_frame, 0.0f) : ((face_laid_pattern_423_local_1_shape < 10.5f) ? float4((0.35f + (0.55f * let_429_4_metal)), let_429_4_metal, 0.0f, 0.0f) : ((face_laid_pattern_423_local_1_shape < 11.5f) ? float4(0.85f, let_430_2_ink, smoothstep(0.43f, 0.47f, abs(motif_face_427_local_3_x)), 0.0f) : ((face_laid_pattern_423_local_1_shape < 12.5f) ? float4((0.9f - (let_431_1_band * 0.25f)), 0.0f, let_431_1_band, 0.0f) : float4((0.35f + (0.6f * motif_face_427_local_6_frame)), (face_laid_pattern_423_local_3_top ? (1.0f - motif_face_427_local_6_frame) : 0.0f), (face_laid_pattern_423_local_3_top ? motif_face_427_local_6_frame : 1.0f), 0.0f)))))) : (face_laid_pattern_423_local_3_top ? ((face_laid_pattern_423_local_1_shape < 5.5f) ? float4((1.0f - (0.7f * board_face_432_local_3_groove)), fract(((paper_hash_434_local_3_folded.x + paper_hash_434_local_3_folded.y) * paper_hash_434_local_3_folded.z)), 0.0f, (0.6f * board_face_432_local_3_groove)) : ((face_laid_pattern_423_local_1_shape < 7.5f) ? float4(1.0f, 0.5f, 1.0f, 0.0f) : float4(0.8f, 0.5f, 0.0f, 0.0f))) : ((face_laid_pattern_423_local_1_shape < 5.5f) ? float4(mix(mix(shelf_face_435_local_26_spine, 0.05f, shelf_face_435_local_24_recess), 1.0f, shelf_face_435_local_12_frame), (shelf_face_435_local_19_id + shelf_face_435_local_27_gilt), shelf_face_435_local_12_frame, shelf_face_435_local_24_recess) : ((face_laid_pattern_423_local_1_shape < 6.5f) ? float4(mix(0.2f, mix(mix(0.85f, 1.0f, window_face_442_local_4_frame), 0.45f, window_face_442_local_5_groove), window_face_442_local_9_bar), window_face_442_local_11_light, window_face_442_local_9_bar, window_face_442_local_5_groove) : ((face_laid_pattern_423_local_1_shape < 7.5f) ? float4(mix((0.35f + (0.2f * mix(mix(paper_noise_452_local_7_near_low, paper_noise_452_local_8_near_high, paper_noise_452_local_5_v), mix(paper_noise_452_local_9_far_low, paper_noise_452_local_10_far_high, paper_noise_452_local_5_v), paper_noise_452_local_6_w))), 0.95f, timbered_face_448_local_8_frame), 0.5f, timbered_face_448_local_8_frame, 0.0f) : float4(mix(mix(0.55f, 0.85f, panel_face_461_local_4_bevel), 0.95f, panel_face_461_local_3_frame), fract(((paper_hash_464_local_3_folded.x + paper_hash_464_local_3_folded.y) * paper_hash_464_local_3_folded.z)), panel_face_461_local_3_frame, 0.0f)))))) : float4(laid_pattern_421_local_26_mask, laid_pattern_421_local_28_hash, laid_pattern_421_local_27_ramp, laid_pattern_421_local_29_checked))).z)) * (0.75f + (0.25f * surface_height_465_local_2_relief)));
  // This numeric value has no quantity annotation.
  float relief_normal_217_local_8_across = ((stage_in.material_pattern.x < 0.5f) ? surface_height_465_local_2_relief : mix(surface_height_465_local_2_relief, surface_height_465_local_3_cut, fade));
  // This numeric value has no quantity annotation.
  float relief_normal_217_local_9_slope = (strength * 0.09f);
  // This numeric value has no quantity annotation.
  float3 bent = normalize((normal - (((relief_normal_217_local_2_tangent * (relief_normal_217_local_7_along - height)) + (relief_normal_217_local_3_bitangent * (relief_normal_217_local_8_across - height))) * (relief_normal_217_local_9_slope / relief_normal_217_local_4_step))));
  // This numeric value has no quantity annotation.
  float3 mortar_tone = stage_in.material_mortar.xyz;
  // This numeric value has no quantity annotation.
  float book_tone_622_local_1_k = floor((laid.y * 6.0f));
  // This numeric value has no quantity annotation.
  float3 element_tone = (((laid.w > 0.5f) ? ((stage_in.material_pattern.x > 3.5f) ? mortar_tone : stage_in.material_tone) : ((dot(stage_in.material_accent.xyz, float3(1.0f, 1.0f, 1.0f)) > 0.001f) ? ((stage_in.material_pattern.x < 1.5f) ? mix(stage_in.material_tone, stage_in.material_accent.xyz, laid.y) : ((book_tone_622_local_1_k < 0.5f) ? stage_in.material_accent.xyz : ((book_tone_622_local_1_k < 1.5f) ? stage_in.material_accent.xyz.yxz : ((book_tone_622_local_1_k < 2.5f) ? stage_in.material_accent.xyz.zyx : ((book_tone_622_local_1_k < 3.5f) ? ((stage_in.material_accent.xyz + stage_in.material_accent.xyz.yxz) * 0.6f) : ((book_tone_622_local_1_k < 4.5f) ? ((stage_in.material_accent.xyz + stage_in.material_accent.xyz.zyx) * 0.6f) : (stage_in.material_tone * 0.55f))))))) : stage_in.material_tone)) * (1.0f + ((2.0f * stage_in.material_mortar.w) * (laid.y - 0.5f))));
  // This numeric value has no quantity annotation.
  float3 joint_tone = ((stage_in.material_pattern.x > 3.5f) ? (mortar_tone * 0.6f) : mortar_tone);
  // This numeric value has no quantity annotation.
  float3 laid_tone = mix(joint_tone, element_tone, laid.x);
  // This numeric value has no quantity annotation.
  float face_element_tone_624_local_1_own = fract(laid.y);
  // This numeric value has no quantity annotation.
  float face_element_tone_624_local_2_jitter = (1.0f + ((2.0f * stage_in.material_mortar.w) * (face_element_tone_624_local_1_own - 0.5f)));
  // This numeric value has no quantity annotation.
  float book_tone_625_local_1_k = floor((face_element_tone_624_local_1_own * 6.0f));
  // This numeric value has no quantity annotation.
  float3 face_pattern_tone_623_local_1_element = ((stage_in.material_pattern.x > 8.5f) ? mix(stage_in.material_tone, stage_in.material_accent.xyz, clamp(laid.y, 0.0f, 1.0f)) : ((abs(normal.z) > 0.7f) ? (stage_in.material_tone * face_element_tone_624_local_2_jitter) : ((stage_in.material_pattern.x < 5.5f) ? mix((mix(((book_tone_625_local_1_k < 0.5f) ? stage_in.material_accent.xyz : ((book_tone_625_local_1_k < 1.5f) ? stage_in.material_accent.xyz.yxz : ((book_tone_625_local_1_k < 2.5f) ? stage_in.material_accent.xyz.zyx : ((book_tone_625_local_1_k < 3.5f) ? ((stage_in.material_accent.xyz + stage_in.material_accent.xyz.yxz) * 0.6f) : ((book_tone_625_local_1_k < 4.5f) ? ((stage_in.material_accent.xyz + stage_in.material_accent.xyz.zyx) * 0.6f) : (stage_in.material_tone * 0.55f)))))), stage_in.material_tone, 0.3f) * (1.0f + ((2.0f * stage_in.material_mortar.w) * (fract((face_element_tone_624_local_1_own * 7.31f)) - 0.5f)))), float3(0.55f, 0.38f, 0.12f), (0.7f * floor(laid.y))) : ((stage_in.material_pattern.x < 6.5f) ? (stage_in.material_accent.xyz * 0.3f) : ((stage_in.material_pattern.x < 7.5f) ? stage_in.material_accent.xyz : (stage_in.material_tone * face_element_tone_624_local_2_jitter))))));
  // This numeric value has no quantity annotation.
  float3 face_pattern_tone_623_local_2_frame_tone = stage_in.material_mortar.xyz;
  // This numeric value has no quantity annotation.
  float3 face_tone = mix(mix(face_pattern_tone_623_local_1_element, (face_pattern_tone_623_local_2_frame_tone * 0.2f), laid.w), face_pattern_tone_623_local_2_frame_tone, laid.z);
  // This numeric value has no quantity annotation.
  float3 base_tone = ((stage_in.material_pattern.x < 0.5f) ? stage_in.material_tone : ((stage_in.material_pattern.x > 4.5f) ? mix(stage_in.material_tone, face_tone, fade) : mix(mix(stage_in.material_tone, mortar_tone, stage_in.material_pattern.w), laid_tone, fade)));
  // This numeric value has no quantity annotation.
  float fringe = ((abs((relief - 1.0f)) < 0.5f) ? (smoothstep(0.78f, 0.94f, (fract((world.z - 0.001f)) + (0.08f * (height - 0.5f)))) * (1.0f - abs(normal.z))) : 0.0f);
  // This numeric value has no quantity annotation.
  float3 tone = (mix(base_tone, stage_in.material_accent.xyz, fringe) * ((1.0f + ((strength * 0.5f) * (height - 0.5f))) + (0.22f * wear)));
  // This numeric value has no quantity annotation.
  float3 view = normalize(mix((-forward), (eye.xyz - world), divisor));
  // This value is a difference-valued scalar, unitless and dimensionless.
  float metal_ = ((relief > 11.5f) ? 1.0f : 0.0f);
  // This numeric value has no quantity annotation.
  float3 sky = (stage_in.voxel_light.w * camera_state.sky_color_vector.xyz);
  // This numeric value has no quantity annotation.
  float3 ground = (stage_in.voxel_light.w * camera_state.ground_color_vector.xyz);
  // This numeric value has no quantity annotation.
  float environment = (stage_in.voxel_light.w * 0.38f);
  // This numeric value has no quantity annotation.
  float paper_surface_radiance_626_local_1_upness = bent.z;
  // This numeric value has no quantity annotation.
  float paper_surface_radiance_626_local_2_direct_shape = max(0.0f, dot(bent, sun));
  // This numeric value has no quantity annotation.
  float3 paper_surface_radiance_626_local_3_direct = (sun_color * (paper_surface_radiance_626_local_2_direct_shape * visibility));
  // This numeric value has no quantity annotation.
  float3 paper_surface_radiance_626_local_4_ambient = mix(ground, sky, (0.5f + (0.5f * paper_surface_radiance_626_local_1_upness)));
  // This numeric value has no quantity annotation.
  float3 paper_surface_radiance_626_local_5_cell = floor((world - (bent * 0.25f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_627_local_1_scattered = fract(((paper_surface_radiance_626_local_5_cell + (bent * 7.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_627_local_2_shift = dot(paper_hash_627_local_1_scattered, (paper_hash_627_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_627_local_3_folded = (paper_hash_627_local_1_scattered + float3(paper_hash_627_local_2_shift, paper_hash_627_local_2_shift, paper_hash_627_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_surface_radiance_626_local_6_facet = (fract(((paper_hash_627_local_3_folded.x + paper_hash_627_local_3_folded.y) * paper_hash_627_local_3_folded.z)) - 0.5f);
  // This numeric value has no quantity annotation.
  float3 paper_noise_628_local_1_lattice = floor((world * 1.7f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_628_local_2_offset = fract((world * 1.7f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_628_local_3_weight = (paper_noise_628_local_2_offset * (paper_noise_628_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_628_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_628_local_4_u = paper_noise_628_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_628_local_5_v = paper_noise_628_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_628_local_6_w = paper_noise_628_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_629_local_1_scattered = fract((paper_noise_628_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_629_local_2_shift = dot(paper_hash_629_local_1_scattered, (paper_hash_629_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_629_local_3_folded = (paper_hash_629_local_1_scattered + float3(paper_hash_629_local_2_shift, paper_hash_629_local_2_shift, paper_hash_629_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_630_local_1_scattered = fract(((paper_noise_628_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_630_local_2_shift = dot(paper_hash_630_local_1_scattered, (paper_hash_630_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_630_local_3_folded = (paper_hash_630_local_1_scattered + float3(paper_hash_630_local_2_shift, paper_hash_630_local_2_shift, paper_hash_630_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_628_local_7_near_low = mix(fract(((paper_hash_629_local_3_folded.x + paper_hash_629_local_3_folded.y) * paper_hash_629_local_3_folded.z)), fract(((paper_hash_630_local_3_folded.x + paper_hash_630_local_3_folded.y) * paper_hash_630_local_3_folded.z)), paper_noise_628_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_631_local_1_scattered = fract(((paper_noise_628_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_631_local_2_shift = dot(paper_hash_631_local_1_scattered, (paper_hash_631_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_631_local_3_folded = (paper_hash_631_local_1_scattered + float3(paper_hash_631_local_2_shift, paper_hash_631_local_2_shift, paper_hash_631_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_632_local_1_scattered = fract(((paper_noise_628_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_632_local_2_shift = dot(paper_hash_632_local_1_scattered, (paper_hash_632_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_632_local_3_folded = (paper_hash_632_local_1_scattered + float3(paper_hash_632_local_2_shift, paper_hash_632_local_2_shift, paper_hash_632_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_628_local_8_near_high = mix(fract(((paper_hash_631_local_3_folded.x + paper_hash_631_local_3_folded.y) * paper_hash_631_local_3_folded.z)), fract(((paper_hash_632_local_3_folded.x + paper_hash_632_local_3_folded.y) * paper_hash_632_local_3_folded.z)), paper_noise_628_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_633_local_1_scattered = fract(((paper_noise_628_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_633_local_2_shift = dot(paper_hash_633_local_1_scattered, (paper_hash_633_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_633_local_3_folded = (paper_hash_633_local_1_scattered + float3(paper_hash_633_local_2_shift, paper_hash_633_local_2_shift, paper_hash_633_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_634_local_1_scattered = fract(((paper_noise_628_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_634_local_2_shift = dot(paper_hash_634_local_1_scattered, (paper_hash_634_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_634_local_3_folded = (paper_hash_634_local_1_scattered + float3(paper_hash_634_local_2_shift, paper_hash_634_local_2_shift, paper_hash_634_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_628_local_9_far_low = mix(fract(((paper_hash_633_local_3_folded.x + paper_hash_633_local_3_folded.y) * paper_hash_633_local_3_folded.z)), fract(((paper_hash_634_local_3_folded.x + paper_hash_634_local_3_folded.y) * paper_hash_634_local_3_folded.z)), paper_noise_628_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_635_local_1_scattered = fract(((paper_noise_628_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_635_local_2_shift = dot(paper_hash_635_local_1_scattered, (paper_hash_635_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_635_local_3_folded = (paper_hash_635_local_1_scattered + float3(paper_hash_635_local_2_shift, paper_hash_635_local_2_shift, paper_hash_635_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_636_local_1_scattered = fract(((paper_noise_628_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_636_local_2_shift = dot(paper_hash_636_local_1_scattered, (paper_hash_636_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_636_local_3_folded = (paper_hash_636_local_1_scattered + float3(paper_hash_636_local_2_shift, paper_hash_636_local_2_shift, paper_hash_636_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_628_local_10_far_high = mix(fract(((paper_hash_635_local_3_folded.x + paper_hash_635_local_3_folded.y) * paper_hash_635_local_3_folded.z)), fract(((paper_hash_636_local_3_folded.x + paper_hash_636_local_3_folded.y) * paper_hash_636_local_3_folded.z)), paper_noise_628_local_4_u);
  // This numeric value has no quantity annotation.
  float paper_surface_radiance_626_local_7_fibre = (mix(mix(paper_noise_628_local_7_near_low, paper_noise_628_local_8_near_high, paper_noise_628_local_5_v), mix(paper_noise_628_local_9_far_low, paper_noise_628_local_10_far_high, paper_noise_628_local_5_v), paper_noise_628_local_6_w) - 0.5f);
  // This numeric value has no quantity annotation.
  float3 paper_noise_637_local_1_lattice = floor((world * 0.045f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_637_local_2_offset = fract((world * 0.045f));
  // This numeric value has no quantity annotation.
  float3 paper_noise_637_local_3_weight = (paper_noise_637_local_2_offset * (paper_noise_637_local_2_offset * (float3(3.0f, 3.0f, 3.0f) - (paper_noise_637_local_2_offset * 2.0f))));
  // This numeric value has no quantity annotation.
  float paper_noise_637_local_4_u = paper_noise_637_local_3_weight.x;
  // This numeric value has no quantity annotation.
  float paper_noise_637_local_5_v = paper_noise_637_local_3_weight.y;
  // This numeric value has no quantity annotation.
  float paper_noise_637_local_6_w = paper_noise_637_local_3_weight.z;
  // This numeric value has no quantity annotation.
  float3 paper_hash_638_local_1_scattered = fract((paper_noise_637_local_1_lattice * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_638_local_2_shift = dot(paper_hash_638_local_1_scattered, (paper_hash_638_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_638_local_3_folded = (paper_hash_638_local_1_scattered + float3(paper_hash_638_local_2_shift, paper_hash_638_local_2_shift, paper_hash_638_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_639_local_1_scattered = fract(((paper_noise_637_local_1_lattice + float3(1.0f, 0.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_639_local_2_shift = dot(paper_hash_639_local_1_scattered, (paper_hash_639_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_639_local_3_folded = (paper_hash_639_local_1_scattered + float3(paper_hash_639_local_2_shift, paper_hash_639_local_2_shift, paper_hash_639_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_637_local_7_near_low = mix(fract(((paper_hash_638_local_3_folded.x + paper_hash_638_local_3_folded.y) * paper_hash_638_local_3_folded.z)), fract(((paper_hash_639_local_3_folded.x + paper_hash_639_local_3_folded.y) * paper_hash_639_local_3_folded.z)), paper_noise_637_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_640_local_1_scattered = fract(((paper_noise_637_local_1_lattice + float3(0.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_640_local_2_shift = dot(paper_hash_640_local_1_scattered, (paper_hash_640_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_640_local_3_folded = (paper_hash_640_local_1_scattered + float3(paper_hash_640_local_2_shift, paper_hash_640_local_2_shift, paper_hash_640_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_641_local_1_scattered = fract(((paper_noise_637_local_1_lattice + float3(1.0f, 1.0f, 0.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_641_local_2_shift = dot(paper_hash_641_local_1_scattered, (paper_hash_641_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_641_local_3_folded = (paper_hash_641_local_1_scattered + float3(paper_hash_641_local_2_shift, paper_hash_641_local_2_shift, paper_hash_641_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_637_local_8_near_high = mix(fract(((paper_hash_640_local_3_folded.x + paper_hash_640_local_3_folded.y) * paper_hash_640_local_3_folded.z)), fract(((paper_hash_641_local_3_folded.x + paper_hash_641_local_3_folded.y) * paper_hash_641_local_3_folded.z)), paper_noise_637_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_642_local_1_scattered = fract(((paper_noise_637_local_1_lattice + float3(0.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_642_local_2_shift = dot(paper_hash_642_local_1_scattered, (paper_hash_642_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_642_local_3_folded = (paper_hash_642_local_1_scattered + float3(paper_hash_642_local_2_shift, paper_hash_642_local_2_shift, paper_hash_642_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_643_local_1_scattered = fract(((paper_noise_637_local_1_lattice + float3(1.0f, 0.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_643_local_2_shift = dot(paper_hash_643_local_1_scattered, (paper_hash_643_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_643_local_3_folded = (paper_hash_643_local_1_scattered + float3(paper_hash_643_local_2_shift, paper_hash_643_local_2_shift, paper_hash_643_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_637_local_9_far_low = mix(fract(((paper_hash_642_local_3_folded.x + paper_hash_642_local_3_folded.y) * paper_hash_642_local_3_folded.z)), fract(((paper_hash_643_local_3_folded.x + paper_hash_643_local_3_folded.y) * paper_hash_643_local_3_folded.z)), paper_noise_637_local_4_u);
  // This numeric value has no quantity annotation.
  float3 paper_hash_644_local_1_scattered = fract(((paper_noise_637_local_1_lattice + float3(0.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_644_local_2_shift = dot(paper_hash_644_local_1_scattered, (paper_hash_644_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_644_local_3_folded = (paper_hash_644_local_1_scattered + float3(paper_hash_644_local_2_shift, paper_hash_644_local_2_shift, paper_hash_644_local_2_shift));
  // This numeric value has no quantity annotation.
  float3 paper_hash_645_local_1_scattered = fract(((paper_noise_637_local_1_lattice + float3(1.0f, 1.0f, 1.0f)) * 0.1031f));
  // This numeric value has no quantity annotation.
  float paper_hash_645_local_2_shift = dot(paper_hash_645_local_1_scattered, (paper_hash_645_local_1_scattered.zyx + float3(31.32f, 31.32f, 31.32f)));
  // This numeric value has no quantity annotation.
  float3 paper_hash_645_local_3_folded = (paper_hash_645_local_1_scattered + float3(paper_hash_645_local_2_shift, paper_hash_645_local_2_shift, paper_hash_645_local_2_shift));
  // This numeric value has no quantity annotation.
  float paper_noise_637_local_10_far_high = mix(fract(((paper_hash_644_local_3_folded.x + paper_hash_644_local_3_folded.y) * paper_hash_644_local_3_folded.z)), fract(((paper_hash_645_local_3_folded.x + paper_hash_645_local_3_folded.y) * paper_hash_645_local_3_folded.z)), paper_noise_637_local_4_u);
  // This numeric value has no quantity annotation.
  float paper_surface_radiance_626_local_8_patch = (mix(mix(paper_noise_637_local_7_near_low, paper_noise_637_local_8_near_high, paper_noise_637_local_5_v), mix(paper_noise_637_local_9_far_low, paper_noise_637_local_10_far_high, paper_noise_637_local_5_v), paper_noise_637_local_6_w) - 0.5f);
  // This numeric value has no quantity annotation.
  float3 paper_surface_radiance_626_local_9_patch_tint = (float3(1.0f, 1.0f, 1.0f) + (float3(0.22f, 0.14f, -0.06f) * paper_surface_radiance_626_local_8_patch));
  // This numeric value has no quantity annotation.
  float3 paper_surface_radiance_626_local_10_albedo = (((tone * (1.0f - (metal_ * 0.9f))) * paper_surface_radiance_626_local_9_patch_tint) * ((1.0f + (0.06f * paper_surface_radiance_626_local_6_facet)) + (0.08f * paper_surface_radiance_626_local_7_fibre)));
  // This numeric value has no quantity annotation.
  float3 material_specular_646_local_1_halfway = normalize((view + sun));
  // This numeric value has no quantity annotation.
  float material_specular_646_local_2_x = max(0.0f, dot(bent, material_specular_646_local_1_halfway));
  // This numeric value has no quantity annotation.
  float material_specular_646_local_3_x2 = (material_specular_646_local_2_x * material_specular_646_local_2_x);
  // This numeric value has no quantity annotation.
  float material_specular_646_local_4_x4 = (material_specular_646_local_3_x2 * material_specular_646_local_3_x2);
  // This numeric value has no quantity annotation.
  float material_specular_646_local_5_x8 = (material_specular_646_local_4_x4 * material_specular_646_local_4_x4);
  // This numeric value has no quantity annotation.
  float material_specular_646_local_6_x16 = (material_specular_646_local_5_x8 * material_specular_646_local_5_x8);
  // This numeric value has no quantity annotation.
  float material_specular_646_local_7_x64 = ((material_specular_646_local_6_x16 * material_specular_646_local_6_x16) * (material_specular_646_local_6_x16 * material_specular_646_local_6_x16));
  // This numeric value has no quantity annotation.
  float material_specular_646_local_8_smooth = (1.0f - roughness);
  // This numeric value has no quantity annotation.
  float face_pattern_glow_647_local_1_shape = stage_in.material_pattern.x;
  // This numeric value has no quantity annotation.
  float face_pattern_glow_647_local_2_lit = ((face_pattern_glow_647_local_1_shape > 8.5f) ? ((face_pattern_glow_647_local_1_shape < 9.5f) ? laid.y : ((face_pattern_glow_647_local_1_shape > 12.5f) ? laid.y : 0.0f)) : ((face_pattern_glow_647_local_1_shape > 5.5f) ? ((face_pattern_glow_647_local_1_shape < 6.5f) ? ((abs(normal.z) < 0.7f) ? 1.0f : 0.0f) : 0.0f) : 0.0f));
  // This numeric value has no quantity annotation.
  float3 radiance = (((((paper_surface_radiance_626_local_10_albedo * (paper_surface_radiance_626_local_4_ambient + paper_surface_radiance_626_local_3_direct)) + ((metal_ * tone) * (1.8f * environment))) + ((sun_color * mix(float3(1.0f, 1.0f, 1.0f), (float3(0.2f, 0.2f, 0.2f) + (tone * 5.0f)), metal_)) * (visibility * ((((material_specular_646_local_8_smooth * material_specular_646_local_8_smooth) * 0.5f) * mix(material_specular_646_local_5_x8, material_specular_646_local_7_x64, material_specular_646_local_8_smooth)) * max(0.0f, dot(bent, sun)))))) + (stage_in.material_accent.xyz * ((face_pattern_glow_647_local_2_lit * stage_in.material_accent.w) * mix(0.5f, ((1.0f - laid.z) * (0.15f + (1.1f * laid.y))), fade)))) + (tone * (0.7f * (stage_in.voxel_light.xyz * stage_in.voxel_light.xyz))));
  // This numeric value has no quantity annotation.
  float3 luvcraft_atmospheric_surface_648_local_1_viewer = mix(camera_state.character_parameters.xyz, camera_state.camera_position.xyz, camera_state.render_parameters.z);
  // This numeric value has no quantity annotation.
  float3 luvcraft_atmospheric_surface_648_local_2_delta = (world - luvcraft_atmospheric_surface_648_local_1_viewer);
  // This numeric value has no quantity annotation.
  float luvcraft_atmospheric_surface_648_local_3_distance = sqrt(dot(luvcraft_atmospheric_surface_648_local_2_delta, luvcraft_atmospheric_surface_648_local_2_delta));
  // This numeric value has no quantity annotation.
  float3 luvcraft_atmospheric_surface_648_local_4_direction = (luvcraft_atmospheric_surface_648_local_2_delta / max(luvcraft_atmospheric_surface_648_local_3_distance, 0.001f));
  // This numeric value has no quantity annotation.
  float luvcraft_surface_haze_649_local_1_depth = (max(0.0f, dot((world - luvcraft_atmospheric_surface_648_local_1_viewer), forward)) * (camera_state.fog_color_vector.w / 0.007f));
  // View distance is a difference-valued scalar in the lattice coordinate kind, measured in cell units, and dimensionless.
  float fog_amount_at_view_distance_650_local_1_fog_span = (180.0f - 0.0f);
  // This value is a difference-valued scalar, unitless and dimensionless.
  float fog_amount_at_view_distance_650_local_2_fog_progress = clamp(((luvcraft_surface_haze_649_local_1_depth - 0.0f) / fog_amount_at_view_distance_650_local_1_fog_span), 0.0f, 1.0f);
  // This numeric value has no quantity annotation.
  float luvcraft_atmospheric_surface_648_local_5_haze = (fog_amount_at_view_distance_650_local_2_fog_progress * fog_amount_at_view_distance_650_local_2_fog_progress);
  // This numeric value has no quantity annotation.
  float luvcraft_atmospheric_surface_648_local_6_edge = (camera_state.render_parameters.z * smoothstep(180.0f, 310.0f, luvcraft_atmospheric_surface_648_local_3_distance));
  // This numeric value has no quantity annotation.
  float aerial_perspective_color_651_local_1_alignment = dot(luvcraft_atmospheric_surface_648_local_4_direction, sun);
  // This numeric value has no quantity annotation.
  float aerial_perspective_color_651_local_2_toward = max(0.0f, aerial_perspective_color_651_local_1_alignment);
  // This numeric value has no quantity annotation.
  float aerial_perspective_color_651_local_3_low_sun = (camera_state.zenith_color_vector.w * (1.0f - smoothstep(0.02f, 0.45f, sun.z)));
  // This numeric value has no quantity annotation.
  float henyey_greenstein_652_local_1_squared = (0.66f * 0.66f);
  // This numeric value has no quantity annotation.
  float henyey_greenstein_652_local_2_denominator = max(1.0e-4f, ((1.0f + henyey_greenstein_652_local_1_squared) - (2.0f * (0.66f * aerial_perspective_color_651_local_1_alignment))));
  // This numeric value has no quantity annotation.
  float aerial_perspective_color_651_local_4_glow = ((1.0f - henyey_greenstein_652_local_1_squared) / (12.566371f * (henyey_greenstein_652_local_2_denominator * sqrt(henyey_greenstein_652_local_2_denominator))));
  // This numeric value has no quantity annotation.
  float3 aerial_perspective_color_651_local_5_warm = mix(float3(1.08f, 0.8f, 0.56f), float3(1.25f, 0.56f, 0.3f), aerial_perspective_color_651_local_3_low_sun);
  // This numeric value has no quantity annotation.
  float3 luvcraft_atmospheric_surface_648_local_7_air = ((camera_state.fog_color_vector.xyz * (1.0f - (0.18f * (aerial_perspective_color_651_local_3_low_sun * aerial_perspective_color_651_local_2_toward)))) + (aerial_perspective_color_651_local_5_warm * (camera_state.zenith_color_vector.w * ((aerial_perspective_color_651_local_4_glow * 0.07f) + ((0.04f + (0.22f * aerial_perspective_color_651_local_3_low_sun)) * (aerial_perspective_color_651_local_2_toward * aerial_perspective_color_651_local_2_toward))))));
  // This numeric value has no quantity annotation.
  float3 final = mix(radiance, luvcraft_atmospheric_surface_648_local_7_air, max(luvcraft_atmospheric_surface_648_local_5_haze, luvcraft_atmospheric_surface_648_local_6_edge));
  result.color_output = float4(final, 1.0f);
  result.motion_output = ((((stage_in.previous_clip.xy / stage_in.previous_clip.w) * 0.5f) + float2(0.5f, 0.5f)) - (((stage_in.current_clip.xy / stage_in.current_clip.w) * 0.5f) + float2(0.5f, 0.5f)));
  return result;
}
